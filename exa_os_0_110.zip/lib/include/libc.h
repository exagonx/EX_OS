/* =============================================================================
 * lib/include/libc.h
 * EX-OS — Extensible Operating System
 *
 * Copyright (C) 2025 Graziano Falcone <exagonx@hotmail.com>
 *
 * SPDX-License-Identifier: GPL-2.0-or-later
 * This file is part of EX-OS, distributed under the GNU GPL v2.
 * See the LICENSE file in the project root for the full license text.
 * ============================================================================= */

#ifndef LIBC_H
#define LIBC_H

typedef unsigned int    size_t;
typedef int             ssize_t;
typedef unsigned int    uintptr_t;
typedef int             intptr_t;
#define NULL ((void*)0)

/* Stringa */
size_t  strlen(const char *s);
char   *strcpy(char *dst, const char *src);
char   *strncpy(char *dst, const char *src, size_t n);
int     strcmp(const char *a, const char *b);
int     strncmp(const char *a, const char *b, size_t n);
char   *strcat(char *dst, const char *src);
char   *strchr(const char *s, int c);
char   *strrchr(const char *s, int c);

/* Memoria */
void   *memset(void *dst, int c, size_t n);
void   *memcpy(void *dst, const void *src, size_t n);
void   *memmove(void *dst, const void *src, size_t n);
int     memcmp(const void *a, const void *b, size_t n);

/* Stdio */
int     putchar(int c);
int     puts(const char *s);
int     getchar(void);
char   *gets(char *buf, int max);
int     printf(const char *fmt, ...);

/* Stdlib */
int     atoi(const char *s);
void    exit(int code);
void    abort(void);
void   *malloc(size_t size);
void    free(void *ptr);
void   *calloc(size_t nmemb, size_t size);
void   *realloc(void *ptr, size_t size);

/* Syscall wrapper */
int     open(const char *path, int flags);
int     close(int fd);
ssize_t read(int fd, void *buf, size_t n);
ssize_t write(int fd, const void *buf, size_t n);
int     getpid(void);
int     chdir(const char *path);

/* Crea una directory. Nessun parametro 'mode': FAT12 non ha permessi.
 * Ritorna 0, o un errno negativo — in particolare -17 (EEXIST) se il nome
 * e' gia' occupato e -38 (ENOSYS) se il percorso richiederebbe piu' di un
 * livello di annidamento, che questo FAT12 non risolve. */
int     mkdir(const char *path);
char   *getcwd(char *buf, size_t size);
void    sched_yield(void);
void    usleep(unsigned int us);
void    sleep(unsigned int sec);

/* Flag open */
#define O_RDONLY    0
#define O_WRONLY    1
#define O_RDWR      2
#define O_CREAT     0x40
#define O_TRUNC     0x200
#define O_APPEND    0x400

/* Voce di directory (vedi SYS_READDIR in kernel/include/syscall.h —
 * struct identica, deve restare sincronizzata a mano: stessa convenzione
 * usata altrove nel progetto, es. i numeri di syscall duplicati in
 * bin/sh/shell.c invece di includere gli header del kernel). */
#define DIRENT_NAME_MAX 13
typedef struct {
    char           name[DIRENT_NAME_MAX];
    unsigned int   size;
    unsigned char  is_dir;
} DirEntry;

/* listdir — elenca una directory in un colpo solo (non e' la classica
 * tripletta POSIX opendir/readdir/closedir, qui non serve un handle).
 * path: NULL/""/"/" per la root, "/NOME" per una subdirectory.
 * Ritorna il numero di entry scritte in buf (>=0), o <0 in caso di errore. */
int     listdir(const char *path, DirEntry *buf, int max);

/* Programmi che usano la libc implementano main() invece di _start().
 * La libc fornisce _start (naked, weak): legge argc/argv dallo stack
 * iniziale costruito da sys_spawn e chiama _libc_start → main().
 * I programmi che definiscono _start() propria (es. hello, shell)
 * la sovrascrivono al link senza includere _libc_start. */
int     main(int argc, char **argv);
void    _libc_start(int argc, char **argv);  /* richiamata da _start naked */

/* =============================================================================
 * IPC — comunicazione kernel-mediata tra task ring3.
 *
 * Un driver o servizio registra un nome all'avvio (ipc_register), poi
 * resta in attesa di messaggi con ipc_recv. Un client cerca il PID del
 * servizio con ipc_lookup e gli invia richieste con ipc_send — senza mai
 * conoscere direttamente la memoria del destinatario: il kernel copia i
 * dati attraverso un buffer intermedio (vedi kernel/ipc/ipc.c).
 * ============================================================================= */
#define IPC_MSG_MAX_DATA    512
#define IPC_NAME_LEN        16

typedef struct {
    unsigned int  sender_pid;
    unsigned int  type;
    unsigned int  len;
    unsigned char data[IPC_MSG_MAX_DATA];
} IpcMessage;

/* Invia un messaggio a dest_pid. data può essere NULL se len=0.
 * Ritorna 0 su successo, <0 su errore (-ESRCH se dest_pid non esiste,
 * -EBUSY se la mailbox del destinatario resta piena troppo a lungo). */
int     ipc_send(unsigned int dest_pid, unsigned int type,
                  const void *data, unsigned int len);

/* Riceve il prossimo messaggio nella propria mailbox, bloccando se
 * vuota. out_meta (opzionale) riceve sender_pid/type/len; buf riceve il
 * payload fino a buf_len byte. Ritorna 0 su successo. */
int     ipc_recv(IpcMessage *out_meta, void *buf, unsigned int buf_len);

/* Registra il chiamante come fornitore del servizio 'name' (es. "tty",
 * "floppy"). Ritorna 0 su successo, <0 se il nome è già in uso. */
int     ipc_register(const char *name);

/* Cerca il PID del processo che fornisce 'name'.
 * Ritorna il PID (>0) su successo, <0 se non trovato. */
int     ipc_lookup(const char *name);

/* =============================================================================
 * Hardware kernel-mediato — accesso a IRQ e porte I/O per driver ring3.
 *
 * Un driver ring3 non può eseguire in/out o gestire direttamente un IDT
 * gate (istruzioni privilegiate, CPL=3 le rifiuta con #GP). Il kernel
 * media entrambi gli accessi: irq_bind() fa arrivare gli interrupt
 * hardware come messaggi IPC (vedi IpcMessage — sender_pid=0 e
 * type=0xFFFFFFFF segnalano una notifica IRQ, il payload è l'uint32_t
 * col numero IRQ); ioport_bind() dichiara quali porte il processo può
 * toccare, verificate ad ogni ioport_in/ioport_out dal kernel.
 * ============================================================================= */
#define IPC_SENDER_KERNEL    0
#define IPC_TYPE_IRQ_NOTIFY  0xFFFFFFFFu

/* Rivendica un IRQ hardware (0-15). Ritorna 0 su successo, -EEXIST se
 * già rivendicato da un altro processo vivo. */
int     irq_bind(unsigned int irq);

/* Richiede accesso a un range di porte I/O [base, base+count).
 * Sovrascrive un'eventuale bind precedente. Ritorna 0 su successo. */
int     ioport_bind(unsigned int base, unsigned int count);

/* Legge/scrive un byte su una porta nel proprio range. Ritorna -EPERM
 * se la porta non è stata dichiarata con ioport_bind(). */
int     ioport_in(unsigned int port);
int     ioport_out(unsigned int port, unsigned int value);

/* =============================================================================
 * Configurazione e identità del sistema
 * ============================================================================= */

/* Legge un'opzione di /boot/kernel.cfg: sia le variabili di [env]
 * (PATH, HOME, TERM, OSNAME, ...) sia le opzioni scalari fuori da [env]
 * come 'verboseboot'. Copia il valore in buf.
 * Ritorna la lunghezza del valore (>=0), <0 se assente o buffer piccolo.
 *
 * Non si chiama getenv() di proposito: la firma è diversa da quella
 * standard (nessun puntatore a memoria statica del sistema, il chiamante
 * fornisce il buffer) e un nome identico con semantica diversa sarebbe
 * una trappola. */
int     getconf(const char *key, char *buf, size_t size);

/* Copia l'identità del sistema — nome, copyright, licenza, versione — dalla
 * variabile globale del kernel (g_os_version). Ritorna la lunghezza, <0
 * se il buffer è troppo piccolo (nessuna copia parziale). */
int     osversion(char *buf, size_t size);

/* Comodità: 1 se il boot verboso è attivo, 0 se il sistema deve restare
 * silenzioso. In caso di errore di lettura ritorna 1 — un programma muto
 * per un problema di configurazione è indistinguibile da uno bloccato. */
int     verboseboot(void);

#endif /* LIBC_H */
