/* =============================================================================
 * kernel/include/fat12.h
 * EX-OS — Extensible Operating System
 *
 * Copyright (C) 2025 Graziano Falcone <exagonx@hotmail.com>
 *
 * SPDX-License-Identifier: GPL-2.0-or-later
 * This file is part of EX-OS, distributed under the GNU GPL v2.
 * See the LICENSE file in the project root for the full license text.
 * ============================================================================= */

#ifndef FAT12_H
#define FAT12_H

#include "kernel.h"

/* Entry directory FAT12 (32 byte, layout hardware) */
typedef struct PACKED {
    uint8_t  name[8];
    uint8_t  ext[3];
    uint8_t  attr;
    uint8_t  reserved[10];
    uint16_t time;
    uint16_t date;
    uint16_t first_cluster;
    uint32_t file_size;
} Fat12DirEntry;

/* Attributi FAT12 */
#define FAT12_ATTR_READONLY  0x01
#define FAT12_ATTR_HIDDEN    0x02
#define FAT12_ATTR_SYSTEM    0x04
#define FAT12_ATTR_VOLUME    0x08
#define FAT12_ATTR_DIRECTORY 0x10
#define FAT12_ATTR_ARCHIVE   0x20

/* Stat risultante da fat12_stat() */
typedef struct {
    uint32_t size;
    uint16_t first_cluster;
    uint8_t  attr;
    uint16_t date;
    uint16_t time;
} Fat12Stat;

/* Interfaccia pubblica */
int  fat12_init(uint8_t drive);
int  fat12_open(const char *path, uint32_t flags);
int  fat12_read(int handle, void *buf, uint32_t size, uint32_t offset);
int  fat12_write(int handle, const void *buf, uint32_t size);
int  fat12_close(int handle);
int  fat12_stat(const char *path, Fat12Stat *st);
int  fat12_readdir_path(const char *path, Fat12DirEntry *out_buf,
                         uint32_t max_entries, uint32_t *count_out);
void fat12_format_name(const Fat12DirEntry *entry, char *out /* >= 13 byte */);
int  fat12_delete(const char *path);

/* Crea una directory. Solo nella root: il driver risolve i percorsi a un
 * solo livello, quindi una directory più in profondità sarebbe corretta
 * sul supporto ma irraggiungibile. Ritorna 0, -17 se esiste già. */
int  fat12_mkdir(const char *path);

/* Riversa su disco FAT, root directory e settori in cache modificati.
 * Da chiamare prima di spegnere o riavviare. Richiede interrupt
 * abilitati (il driver FDC usa attese su g_ticks e IRQ6). */
int  fat12_sync(void);

#endif /* FAT12_H */
