/* =============================================================================
 * kernel/block/mbr.c
 * EX-OS — Extensible Operating System
 *
 * Copyright (C) 2025 Graziano Falcone <exagonx@hotmail.com>
 *
 * SPDX-License-Identifier: GPL-2.0-or-later
 * This file is part of EX-OS, distributed under the GNU GPL v2.
 * =============================================================================
 *
 * Vedi kernel/include/mbr.h per l'elenco dei controlli e il razionale.
 * ============================================================================= */

#include "kernel.h"
#include "mbr.h"
#include "ata.h"

/* Voce della tabella, 16 byte, come sta sul disco.
 *
 * I campi CHS non vengono usati per calcolare nulla, e non e' pigrizia:
 * su qualunque disco oltre 8,4 GB sono aritmeticamente incapaci di
 * esprimere la posizione e vengono riempiti con il valore di saturazione
 * 0xFE 0xFF 0xFF. Gli unici campi affidabili sono lba_inizio e n_settori.
 * Usare i CHS "quando ci sono" e' una fonte classica di tabelle
 * incoerenti. */
typedef struct PACKED {
    uint8_t  attiva;        /* 0x80 avviabile, 0x00 no, altro = corrotta */
    uint8_t  chs_inizio[3];
    uint8_t  tipo;
    uint8_t  chs_fine[3];
    uint32_t lba_inizio;    /* relativo: assoluto per le primarie */
    uint32_t n_settori;
} VoceMbr;

#define MBR_OFF_TABELLA     446
#define MBR_OFF_FIRMA       510

/* Tipi che indicano una partizione ESTESA (contenitore di logiche) */
static int tipo_esteso(uint8_t t)
{
    return (t == 0x05)   /* estesa CHS */
        || (t == 0x0F)   /* estesa LBA */
        || (t == 0x85);  /* estesa Linux */
}

/* Legge un uint32 little-endian senza assumere l'allineamento: il buffer
 * arriva da disco e le voci non sono allineate a 4 byte dentro il
 * settore. Su x86 un accesso disallineato funziona, ma dipenderci e' una
 * cattiva abitudine che si paga altrove. */
static uint32_t le32(const uint8_t *p)
{
    return (uint32_t)p[0]
         | ((uint32_t)p[1] << 8)
         | ((uint32_t)p[2] << 16)
         | ((uint32_t)p[3] << 24);
}

/* Aggiunge una partizione al risultato, se c'e' posto. */
static void aggiungi(TabellaPartizioni *t, uint8_t attiva, uint8_t tipo,
                     uint64_t inizio, uint64_t settori, int logica,
                     int numero)
{
    Partizione *p;

    if (t->n >= MBR_MAX_PART) {
        t->problemi |= PT_PROB_TRONCATA;
        return;
    }

    p = &t->p[t->n++];
    p->attiva  = attiva;
    p->tipo    = tipo;
    p->logica  = (uint8_t)logica;
    p->numero  = (uint8_t)numero;
    p->inizio  = inizio;
    p->settori = settori;
}

/* =============================================================================
 * Percorre la catena degli EBR delle partizioni logiche.
 *
 * COME E' FATTA, perche' e' la parte in cui e' piu' facile sbagliare.
 * Ogni EBR e' un settore con due voci utili:
 *   voce 0 = la partizione logica, con lba_inizio RELATIVO all'EBR stesso;
 *   voce 1 = il prossimo EBR, con lba_inizio RELATIVO all'INIZIO DELLA
 *            PARTIZIONE ESTESA, non all'EBR corrente.
 * I due riferimenti sono diversi, e confonderli produce una catena che
 * sembra funzionare sul primo elemento e sbaglia da li' in poi.
 *
 * PROTEZIONE DAL CICLO: un puntatore che rimanda a un EBR gia' visitato
 * rende la lista circolare. Senza difesa il kernel ci gira dentro per
 * sempre, cioe' si blocca a ogni avvio con quel disco collegato. Qui si
 * tengono gli LBA gia' visti e si esce segnalando l'anomalia.
 * ============================================================================= */
static void percorri_estesa(int indice, TabellaPartizioni *t,
                            uint64_t ext_inizio, uint64_t ext_settori,
                            uint64_t disco_settori)
{
    uint64_t visti[MBR_MAX_PART + 1];
    int      n_visti = 0;
    uint64_t ebr = ext_inizio;
    uint8_t  sett[512];
    int      giri;

    for (giri = 0; giri < MBR_MAX_PART + 1; giri++) {
        const uint8_t *v0, *v1;
        uint32_t r0_lba, r0_n, r1_lba, r1_n;
        uint8_t  t0, t1, a0;
        int      i;

        /* Il puntatore deve stare dentro il disco E dentro l'estesa. */
        if (ebr >= disco_settori ||
            ebr <  ext_inizio    ||
            ebr >= ext_inizio + ext_settori) {
            t->problemi |= PT_PROB_CATENA;
            return;
        }

        for (i = 0; i < n_visti; i++) {
            if (visti[i] == ebr) {           /* gia' passato di qui */
                t->problemi |= PT_PROB_CATENA;
                return;
            }
        }
        visti[n_visti++] = ebr;

        if (ata_read(indice, ebr, 1, sett) != 0) {
            t->problemi |= PT_PROB_CATENA;
            return;
        }

        if (sett[MBR_OFF_FIRMA] != 0x55 || sett[MBR_OFF_FIRMA + 1] != 0xAA) {
            t->problemi |= PT_PROB_CATENA;
            return;
        }

        v0 = sett + MBR_OFF_TABELLA;
        v1 = sett + MBR_OFF_TABELLA + 16;

        a0     = v0[0];
        t0     = v0[4];
        r0_lba = le32(v0 + 8);
        r0_n   = le32(v0 + 12);

        t1     = v1[4];
        r1_lba = le32(v1 + 8);
        r1_n   = le32(v1 + 12);
        (void)r1_n;

        if (t0 != 0x00 && r0_n > 0) {
            /* RELATIVO ALL'EBR CORRENTE */
            aggiungi(t, a0, t0, ebr + (uint64_t)r0_lba, (uint64_t)r0_n, 1,
                     5 + giri);   /* le logiche partono da 5 */
        } else if (t0 != 0x00) {
            t->problemi |= PT_PROB_VUOTA;
        }

        if (t1 == 0x00 || r1_lba == 0) return;   /* fine della catena */

        if (!tipo_esteso(t1)) {
            /* La seconda voce, se presente, deve essere un puntatore a
             * un altro EBR: qualunque altro tipo indica una tabella
             * malformata, non una partizione in piu'. */
            t->problemi |= PT_PROB_CATENA;
            return;
        }

        /* RELATIVO ALL'INIZIO DELL'ESTESA, non all'EBR corrente. */
        ebr = ext_inizio + (uint64_t)r1_lba;
    }

    /* Usciti per numero massimo di giri: la catena e' piu' lunga di
     * quanto sia ragionevole, oppure e' circolare in un modo che
     * l'elenco dei visitati non ha colto. */
    t->problemi |= PT_PROB_CATENA;
}

int mbr_leggi(int indice, TabellaPartizioni *out)
{
    const AtaDevice *d;
    uint8_t   sett[512];
    uint64_t  disco;
    uint64_t  ext_inizio = 0, ext_settori = 0;
    int       n_estese = 0;
    int       i, j;

    out->schema   = PT_SCHEMA_NESSUNO;
    out->problemi = 0;
    out->n        = 0;

    d = ata_get_device(indice);
    if (d == NULL || !d->presente || d->tipo != ATA_TYPE_ATA) return -1;
    disco = d->settori;

    if (ata_read(indice, 0, 1, sett) != 0) return -1;

    if (sett[MBR_OFF_FIRMA] != 0x55 || sett[MBR_OFF_FIRMA + 1] != 0xAA) {
        out->problemi |= PT_PROB_FIRMA;
        return 0;    /* letto, ma non e' un MBR */
    }

    /* MBR PROTETTIVO = disco GPT. Va riconosciuto PRIMA di leggere le
     * voci come partizioni vere: un disco GPT ha una sola voce di tipo
     * 0xEE che copre l'intero disco, e trattarla come una partizione
     * normale — peggio, riscriverla — distrugge la mappa GPT. */
    for (i = 0; i < 4; i++) {
        if (sett[MBR_OFF_TABELLA + i * 16 + 4] == 0xEE) {
            out->schema    = PT_SCHEMA_GPT;
            out->problemi |= PT_PROB_GPT;
            return 0;
        }
    }

    out->schema = PT_SCHEMA_MBR;

    for (i = 0; i < 4; i++) {
        const uint8_t *v = sett + MBR_OFF_TABELLA + i * 16;
        uint8_t   attiva = v[0];
        uint8_t   tipo   = v[4];
        uint32_t  lba    = le32(v + 8);
        uint32_t  n      = le32(v + 12);

        if (tipo == 0x00) continue;           /* voce libera */

        if (attiva != 0x00 && attiva != 0x80) {
            out->problemi |= PT_PROB_BOOTFLAG;
        }

        if (n == 0) {
            out->problemi |= PT_PROB_VUOTA;
            continue;
        }

        if (tipo_esteso(tipo)) {
            n_estese++;
            if (n_estese > 1) {
                /* Piu' di una estesa fra le primarie e' fuori specifica:
                 * quale delle due contiene le logiche e' indeterminato. */
                out->problemi |= PT_PROB_TROPPE_EXT;
            } else {
                ext_inizio  = (uint64_t)lba;
                ext_settori = (uint64_t)n;
            }
            /* L'estesa viene comunque elencata: e' un contenitore, e
             * nasconderla renderebbe incomprensibile la mappa del disco. */
        }

        aggiungi(out, attiva, tipo, (uint64_t)lba, (uint64_t)n, 0, i + 1);
    }

    if (n_estese == 1 && ext_settori > 0) {
        percorri_estesa(indice, out, ext_inizio, ext_settori, disco);
    }

    /* -------------------------------------------------------------------
     * Controlli sull'insieme, non piu' sulla singola voce.
     * ------------------------------------------------------------------- */
    for (i = 0; i < out->n; i++) {
        Partizione *a = &out->p[i];

        /* Oltre la fine del disco. L'overflow va controllato prima della
         * somma: inizio + settori puo' traboccare e far sembrare valida
         * una voce assurda. */
        if (a->inizio >= disco ||
            a->inizio + a->settori > disco ||
            a->inizio + a->settori < a->inizio) {
            out->problemi |= PT_PROB_OLTRE_FINE;
        }

        for (j = i + 1; j < out->n; j++) {
            Partizione *b = &out->p[j];
            uint64_t a_fine, b_fine;

            /* Un'estesa CONTIENE le proprie logiche: quella non e' una
             * sovrapposizione ma la struttura normale del formato, e
             * segnalarla sarebbe un falso allarme a ogni disco con
             * partizioni logiche. */
            if (tipo_esteso(a->tipo) && b->logica) continue;
            if (tipo_esteso(b->tipo) && a->logica) continue;

            a_fine = a->inizio + a->settori;
            b_fine = b->inizio + b->settori;

            if (a->inizio < b_fine && b->inizio < a_fine) {
                out->problemi |= PT_PROB_SOVRAPP;
            }
        }
    }

    return 0;
}
