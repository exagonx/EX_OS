/* =============================================================================
 * kernel/block/blk.c
 * EX-OS — Extensible Operating System
 *
 * Copyright (C) 2025 Graziano Falcone <exagonx@hotmail.com>
 * SPDX-License-Identifier: GPL-2.0-or-later
 * =============================================================================
 *
 * Vedi kernel/include/blk.h per il razionale e per la proprieta' della
 * finestra, che e' la ragione principale per cui questo file esiste.
 * ============================================================================= */

#include "kernel.h"
#include "blk.h"
#include "ata.h"
#include "mbr.h"
#include "fat12.h"

static BlkDev g_dev[BLK_MAX_DEV];
static int    g_n = 0;

/* Copia un nome corto senza dipendere da una libreria di stringhe. */
static void nome_copia(char *dst, const char *src)
{
    int i = 0;
    while (src[i] && i < BLK_NOME_MAX - 1) { dst[i] = src[i]; i++; }
    dst[i] = '\0';
}

/* Compone "hd0p12" senza printf: il kernel non ha uno sprintf. */
static void nome_componi(char *dst, const char *pre, int a, char sep, int b)
{
    int i = 0, j;
    char num[4];

    while (pre[i] && i < BLK_NOME_MAX - 1) { dst[i] = pre[i]; i++; }

    if (a >= 0 && i < BLK_NOME_MAX - 1) dst[i++] = (char)('0' + (a % 10));

    if (sep && i < BLK_NOME_MAX - 1) {
        dst[i++] = sep;
        j = 0;
        if (b == 0) num[j++] = '0';
        while (b > 0 && j < 3) { num[j++] = (char)('0' + (b % 10)); b /= 10; }
        while (j > 0 && i < BLK_NOME_MAX - 1) dst[i++] = num[--j];
    }

    dst[i] = '\0';
}

static BlkDev *nuovo(void)
{
    if (g_n >= BLK_MAX_DEV) return NULL;
    return &g_dev[g_n++];
}

int blk_init(void)
{
    int d, p;

    g_n = 0;

    /* --- Il floppy. Resta un dispositivo come gli altri anche se il suo
     * filesystem continua a usare la strada diretta: serve per poterlo
     * nominare (fd0) e, in prospettiva, per montarlo dal VFS. --- */
    {
        BlkDev *b = nuovo();
        if (b) {
            nome_copia(b->nome, "fd0");
            b->usato        = 1;
            b->tipo         = BLK_TIPO_FLOPPY;
            b->disco        = 0;
            b->sola_lettura = 0;
            b->primo        = 0;
            b->settori      = 2880;    /* 1.44 MB */
        }
    }

    /* --- Dischi ATA e loro partizioni --- */
    for (d = 0; d < ATA_MAX_DEVICES; d++) {
        const AtaDevice  *a = ata_get_device(d);
        TabellaPartizioni tab;
        BlkDev           *b;

        if (a == NULL || !a->presente || a->tipo != ATA_TYPE_ATA) continue;

        b = nuovo();
        if (b == NULL) break;
        nome_componi(b->nome, "hd", d, 0, 0);
        b->usato        = 1;
        b->tipo         = BLK_TIPO_DISCO;
        b->disco        = (uint8_t)d;
        b->sola_lettura = 0;
        b->primo        = 0;
        b->settori      = a->settori;

        if (mbr_leggi(d, &tab) != 0) continue;

        /* Un disco GPT non ha partizioni MBR utilizzabili: registrare
         * finestre ricavate dall'MBR protettivo significherebbe offrire
         * un dispositivo che copre l'intero disco spacciandolo per una
         * partizione. */
        if (tab.schema != PT_SCHEMA_MBR) continue;

        for (p = 0; p < tab.n; p++) {
            /* Le ESTESE sono contenitori, non spazio utilizzabile:
             * registrarle darebbe un dispositivo che si sovrappone alle
             * proprie logiche, cioe' esattamente la situazione che la
             * finestra serve a impedire. */
            if (tab.p[p].tipo == 0x05 || tab.p[p].tipo == 0x0F ||
                tab.p[p].tipo == 0x85) continue;

            /* Una partizione che esce dal disco non diventa un
             * dispositivo: sarebbe una finestra che promette settori
             * inesistenti. Meglio non offrirla affatto. */
            if (tab.p[p].inizio >= a->settori ||
                tab.p[p].inizio + tab.p[p].settori > a->settori) {
                klog(LOG_WARN, "BLK: partizione %u di hd%d fuori dal disco, ignorata",
                     tab.p[p].numero, d);
                continue;
            }

            b = nuovo();
            if (b == NULL) break;

            nome_componi(b->nome, "hd", d, 'p', tab.p[p].numero);
            b->usato        = 1;
            b->tipo         = BLK_TIPO_PART;
            b->disco        = (uint8_t)d;
            b->sola_lettura = 0;
            b->primo        = tab.p[p].inizio;
            b->settori      = tab.p[p].settori;
        }
    }

    klog(LOG_INFO, "BLK: %d dispositivi a blocchi registrati", g_n);
    return g_n;
}

int blk_conta(void) { return g_n; }

const BlkDev *blk_get(int i)
{
    if (i < 0 || i >= g_n) return NULL;
    return &g_dev[i];
}

int blk_trova(const char *nome)
{
    int i, j;

    if (nome == NULL) return -1;

    for (i = 0; i < g_n; i++) {
        for (j = 0; ; j++) {
            if (g_dev[i].nome[j] != nome[j]) break;
            if (nome[j] == '\0') return i;
        }
    }
    return -1;
}

int blk_per_partizione(int disco, int numero)
{
    char cerca[BLK_NOME_MAX];

    nome_componi(cerca, "hd", disco, 'p', numero);
    return blk_trova(cerca);
}

/* =============================================================================
 * Traduzione e CONTROLLO DELLA FINESTRA
 *
 * Unico punto in cui un LBA relativo diventa assoluto. Il controllo di
 * limite e' qui e non nei chiamanti proprio perche' i chiamanti saranno
 * molti — un driver FAT, un formattatore, un installatore — e ognuno di
 * loro puo' avere un bug nei calcoli o ricevere metadati corrotti da un
 * disco malformato. Nessuno di quei bug deve poter uscire dalla propria
 * partizione.
 * ============================================================================= */
static int traduci(int i, uint64_t lba, uint32_t n, uint64_t *assoluto)
{
    const BlkDev *b = blk_get(i);

    if (b == NULL || !b->usato) return -1;
    if (n == 0) return -1;

    /* L'overflow va controllato PRIMA della somma: lba+n puo' traboccare
     * e far sembrare interna una richiesta assurda. */
    if (lba + n < lba)      return -1;
    if (lba + n > b->settori) {
        klog(LOG_ERROR, "BLK: %s: accesso fuori finestra (lba=%u n=%u, settori=%u)",
             b->nome, (uint32_t)lba, n, (uint32_t)b->settori);
        return -1;
    }

    *assoluto = b->primo + lba;
    return 0;
}

int blk_read(int i, uint64_t lba, uint32_t n, void *buf)
{
    const BlkDev *b = blk_get(i);
    uint64_t      abs;
    uint32_t      k;

    if (traduci(i, lba, n, &abs) != 0) return -1;

    if (b->tipo == BLK_TIPO_FLOPPY) {
        uint8_t *p = (uint8_t *)buf;
        for (k = 0; k < n; k++) {
            if (fat12_dev_read((uint32_t)(abs + k), p + k * 512) != 0) return -1;
        }
        return 0;
    }

    return ata_read(b->disco, abs, n, buf);
}

int blk_write(int i, uint64_t lba, uint32_t n, const void *buf)
{
    const BlkDev *b = blk_get(i);
    uint64_t      abs;
    uint32_t      k;

    if (traduci(i, lba, n, &abs) != 0) return -1;

    if (b->sola_lettura) {
        klog(LOG_ERROR, "BLK: %s e' in sola lettura", b->nome);
        return -1;
    }

    if (b->tipo == BLK_TIPO_FLOPPY) {
        const uint8_t *p = (const uint8_t *)buf;
        for (k = 0; k < n; k++) {
            if (fat12_dev_write((uint32_t)(abs + k), p + k * 512) != 0) return -1;
        }
        return 0;
    }

    return ata_write(b->disco, abs, n, buf);
}

int blk_flush(int i)
{
    const BlkDev *b = blk_get(i);

    if (b == NULL || !b->usato) return -1;
    if (b->tipo == BLK_TIPO_FLOPPY) return fat12_sync();
    return ata_flush(b->disco);
}
