/* =============================================================================
 * kernel/include/blk.h
 * EX-OS — Extensible Operating System
 *
 * Copyright (C) 2025 Graziano Falcone <exagonx@hotmail.com>
 * SPDX-License-Identifier: GPL-2.0-or-later
 * =============================================================================
 *
 * Astrazione a blocchi: un'interfaccia unica per il floppy, i dischi ATA
 * interi e le singole partizioni.
 *
 * PERCHE' ESISTE. Oggi kernel/fs/fat12.c parla direttamente all'FDC, con
 * LBA a 16 bit e la geometria del floppy compilata dentro. Un driver FAT
 * che debba funzionare su una partizione da 1 GB non puo' nascere sopra
 * quel modello: gli serve qualcuno a cui chiedere "dammi il settore N di
 * QUESTO dispositivo", senza sapere se sotto c'e' un motore, un disco o
 * una fetta di disco.
 *
 * LA FINESTRA — la proprieta' di sicurezza piu' importante di questo file.
 *
 * Un dispositivo di tipo partizione e' una FINESTRA sul disco: ha un primo
 * settore e una lunghezza. Ogni lettura e scrittura viene tradotta
 * (lba -> primo + lba) e RIFIUTATA se esce dalla finestra.
 *
 * E' cio' che rende impossibile a un filesystem montato su hd0p1 di
 * toccare hd0p2, o il settore 0 con la tabella delle partizioni, anche
 * se ha un bug nei calcoli o legge metadati corrotti da un disco
 * malformato. Il controllo sta QUI, in un punto solo, dove passano
 * tutti: metterlo nei filesystem significherebbe riscriverlo per ognuno
 * e sbagliarlo prima o poi.
 * ============================================================================= */

#ifndef BLK_H
#define BLK_H

#include "kernel.h"

#define BLK_MAX_DEV     16
#define BLK_NOME_MAX    12

#define BLK_TIPO_NESSUNO    0
#define BLK_TIPO_FLOPPY     1
#define BLK_TIPO_DISCO      2   /* disco ATA intero */
#define BLK_TIPO_PART       3   /* partizione: finestra su un disco ATA */

typedef struct {
    char     nome[BLK_NOME_MAX];  /* "fd0", "hd0", "hd0p1" */
    uint8_t  usato;
    uint8_t  tipo;                /* BLK_TIPO_* */
    uint8_t  disco;               /* indice ATA (per DISCO e PART) */
    uint8_t  sola_lettura;
    uint64_t primo;               /* LBA di partenza nel supporto sottostante */
    uint64_t settori;             /* lunghezza della finestra */
} BlkDev;

/* Registra i dispositivi trovati. Va chiamata DOPO ata_init() e dopo
 * fat12_init(), perche' interroga entrambi. Ritorna quanti ne ha
 * registrati. */
int  blk_init(void);

int  blk_conta(void);
const BlkDev *blk_get(int i);

/* Cerca per nome ("hd0p1"). Ritorna l'indice, o -1. */
int  blk_trova(const char *nome);

/* lba e' RELATIVO al dispositivo. Ritorna 0, <0 su errore o se la
 * richiesta esce dalla finestra. */
int  blk_read (int i, uint64_t lba, uint32_t n, void *buf);
int  blk_write(int i, uint64_t lba, uint32_t n, const void *buf);
int  blk_flush(int i);

/* Indice del dispositivo che rappresenta la partizione `numero` del disco
 * ATA `disco`. Ritorna -1 se non registrata (per esempio perche' era
 * fuori dal disco, o perche' e' un contenitore esteso). */
int  blk_per_partizione(int disco, int numero);

#endif /* BLK_H */
