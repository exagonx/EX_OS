/* =============================================================================
 * kernel/include/mbr.h
 * EX-OS — Extensible Operating System
 *
 * Copyright (C) 2025 Graziano Falcone <exagonx@hotmail.com>
 *
 * SPDX-License-Identifier: GPL-2.0-or-later
 * This file is part of EX-OS, distributed under the GNU GPL v2.
 * =============================================================================
 *
 * Lettura e VALIDAZIONE della tabella delle partizioni MBR.
 *
 * Questo modulo, per ora, non scrive nulla. E' deliberato: prima si
 * dimostra di saper leggere e criticare correttamente una tabella
 * esistente, poi si acquisisce il diritto di modificarne una. Un errore
 * in lettura fa vedere numeri sbagliati; lo stesso errore in scrittura
 * rende irraggiungibili i dati di un disco.
 *
 * COSA VIENE CONTROLLATO, e perche' ognuno di questi e' un guasto reale:
 *
 *   firma 0x55AA        la sua assenza significa che il settore 0 non e'
 *                       un MBR: interpretarlo come tale produce partizioni
 *                       inventate da byte casuali.
 *   MBR protettivo      un disco GPT ha una finta tabella MBR con una sola
 *                       voce di tipo 0xEE che copre tutto. Trattarla come
 *                       una vera partizione e' il modo classico per
 *                       distruggere un disco GPT.
 *   oltre la fine       una partizione che dichiara di finire dopo
 *                       l'ultimo settore del disco. Capita davvero quando
 *                       la tabella e' stata scritta con una capacita'
 *                       diversa da quella attuale — per esempio con una
 *                       HPA attiva, poi rimossa, o viceversa.
 *   sovrapposizioni     due partizioni che condividono settori. Scriverci
 *                       dentro corrompe l'altra, in silenzio.
 *   flag di avvio       deve essere 0x00 o 0x80. Qualunque altro valore
 *                       indica una tabella danneggiata, non una scelta.
 *   catena estesa       gli EBR formano una lista concatenata. Un puntatore
 *                       che torna indietro la rende CIRCOLARE, e un
 *                       parser ingenuo ci gira dentro per sempre.
 *   somma nulla         una voce con dimensione 0 ma tipo non nullo.
 *
 * Il modulo NON corregge nulla di tutto questo: lo segnala. Correggere
 * automaticamente una tabella sospetta significherebbe decidere al posto
 * dell'utente su dati che potrebbero essere recuperabili.
 * ============================================================================= */

#ifndef MBR_H
#define MBR_H

#include "kernel.h"

#define MBR_MAX_PART        16   /* 4 primarie + logiche, tetto pratico */

/* Schema rilevato sul settore 0 */
#define PT_SCHEMA_NESSUNO   0    /* niente di riconoscibile */
#define PT_SCHEMA_MBR       1    /* tabella MBR valida */
#define PT_SCHEMA_GPT       2    /* MBR protettivo: il disco e' GPT */

/* Anomalie (maschera di bit) */
#define PT_PROB_FIRMA       0x0001  /* manca 0x55AA */
#define PT_PROB_OLTRE_FINE  0x0002  /* partizione oltre l'ultimo settore */
#define PT_PROB_SOVRAPP     0x0004  /* partizioni sovrapposte */
#define PT_PROB_CATENA      0x0008  /* catena estesa ciclica o rotta */
#define PT_PROB_BOOTFLAG    0x0010  /* flag di avvio diverso da 0x00/0x80 */
#define PT_PROB_GPT         0x0020  /* MBR protettivo: non modificabile qui */
#define PT_PROB_VUOTA       0x0040  /* tipo non nullo ma dimensione zero */
#define PT_PROB_TROPPE_EXT  0x0080  /* piu' di una estesa fra le primarie */
#define PT_PROB_TRONCATA    0x0100  /* piu' partizioni di quante ne stiano */

typedef struct {
    uint8_t  attiva;        /* 0x80 = avviabile */
    uint8_t  tipo;          /* byte di tipo (0x06 FAT16, 0x0C FAT32, ...) */
    uint8_t  logica;        /* 1 se dentro la partizione estesa */
    /* Numero della partizione nella convenzione universale: 1-4 sono gli
     * SLOT delle primarie (anche se qualcuno e' vuoto), le logiche
     * partono da 5 in ordine di catena. NON e' l'indice nell'array: se
     * sul disco sono usati gli slot 1 e 3, questo campo vale 1 e 3, non
     * 1 e 2. Serve a far coincidere i nomi dei dispositivi (hd0p3) con
     * cio' che dicono fdisk e Linux — altrimenti chi partiziona con uno
     * strumento esterno e poi monta qui monterebbe la partizione
     * sbagliata credendo di aver capito il nome. */
    uint8_t  numero;
    uint64_t inizio;        /* LBA assoluto del primo settore */
    uint64_t settori;       /* lunghezza in settori */
} Partizione;

typedef struct {
    int         schema;                  /* PT_SCHEMA_* */
    uint32_t    problemi;                /* maschera PT_PROB_* */
    int         n;                       /* partizioni trovate */
    Partizione  p[MBR_MAX_PART];
} TabellaPartizioni;

/* Legge e valida la tabella del disco `indice` (indice ATA).
 * Ritorna 0 se il settore 0 e' stato letto, <0 se nemmeno quello.
 * Lo schema e le anomalie stanno dentro `out` — un ritorno 0 NON
 * significa "tabella sana", significa "sono riuscito a guardarla". */
int mbr_leggi(int indice, TabellaPartizioni *out);

#endif /* MBR_H */
