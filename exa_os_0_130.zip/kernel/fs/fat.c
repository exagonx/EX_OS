/* =============================================================================
 * kernel/fs/fat.c
 * EX-OS — Extensible Operating System
 *
 * Copyright (C) 2025 Graziano Falcone <exagonx@hotmail.com>
 * SPDX-License-Identifier: GPL-2.0-or-later
 * =============================================================================
 *
 * Driver FAT12/16/32 guidato dal BPB, sopra il livello a blocchi.
 *
 * Le scelte qui sotto non sono state prese "come fanno tutti": sono
 * dedotte, e ognuna e' motivata. Diverse nascono da bug documentati di
 * implementazioni reali, che vale la pena non ripetere.
 *
 * -----------------------------------------------------------------------
 * 1. LA FAT NON STA IN RAM. NON E' UNA PREFERENZA, E' UN VINCOLO.
 *
 * kernel/fs/fat12.c tiene l'intera FAT in un array statico: 4608 byte per
 * un floppy. La FAT di un volume FAT32 misura 4 byte per cluster: una
 * partizione da 1 GB con cluster da 4 KB ne ha ~262000, cioe' 1 MB di
 * FAT; una da 64 GB arriva a ~64 MB. L'heap del kernel e' 4 MB. Non e'
 * "meno efficiente" tenerla in RAM: e' impossibile.
 *
 * Da qui discende tutto il resto: le voci della FAT si leggono a richiesta
 * da una cache di settori, e questo obbliga ad affrontare il punto 2.
 *
 * -----------------------------------------------------------------------
 * 2. LA VOCE FAT12 PUO' ATTRAVERSARE IL CONFINE FRA DUE SETTORI.
 *
 * E' il classico documentato. Le voci FAT12 sono a 12 bit, quindi due
 * voci stanno in tre byte e la voce N comincia al byte N + N/2. Quando
 * quell'offset e' l'ULTIMO byte del settore, il nibble alto della voce
 * vive nel settore SUCCESSIVO. Un driver che legge un settore e fa
 * `buf[off] | buf[off+1] << 8` legge fuori dal proprio buffer, e ottiene
 * un numero di cluster arbitrario.
 *
 * Due procedure possibili:
 *   (a) leggere sempre DUE settori consecutivi;
 *   (b) leggere un settore, riconoscere il caso a cavallo e leggere il
 *       successivo solo per quel byte.
 *
 * (b) e' migliore, e non per abitudine: su settori da 512 byte solo 1
 * offset su 512 sta a cavallo, quindi (a) raddoppierebbe l'I/O per il
 * 99,8% degli accessi che non ne hanno bisogno. A parita' di correttezza,
 * si sceglie quella che non paga sempre un costo che serve quasi mai. Con
 * la cache dei settori, per giunta, la lettura in piu' di (b) e' quasi
 * sempre un colpo in cache. Qui si usa (b).
 *
 * -----------------------------------------------------------------------
 * 3. FINE CATENA: ESSERE "PRUDENTI" QUI SIGNIFICA TRONCARE I FILE.
 *
 * Nel 1986 una implementazione molto diffusa comincio' a trattare il
 * valore 0xFF0 come fine catena, per uniformita' con il descrittore di
 * media 0xF0. Ma 0xFF0 era un numero di cluster legittimo: i file scritti
 * prima, la cui catena passava di li', diventarono leggibili solo fino a
 * quel punto. La voce di directory continuava a dichiarare 35821 byte e
 * il file ne restituiva 8192, senza alcun errore.
 * (brutman.com, "The FAT12 File Truncation Bug")
 *
 * Regola dedotta, e la si applica alla lettera:
 *   - fine catena e' ESATTAMENTE >= 0xFF8 / 0xFFF8 / 0x0FFFFFF8;
 *   - il valore "cluster danneggiato" 0xFF7 / 0xFFF7 / 0x0FFFFFF7 e' un
 *     ERRORE, non una fine;
 *   - i valori riservati sotto quella soglia NON sono fine catena.
 *
 * Regola dedotta ancora piu' utile: **se la catena finisce prima di
 * quanto dichiari la dimensione del file, e' un errore da segnalare, non
 * una fine da accettare in silenzio.** Quel bug del 1986 sarebbe stato
 * visibile subito con questo controllo, che costa un confronto.
 *
 * -----------------------------------------------------------------------
 * 4. FAT32 USA 28 BIT: I 4 ALTI NON SONO NOSTRI.
 *
 * In lettura si maschera con 0x0FFFFFFF. In scrittura si PRESERVANO.
 * Motivo logico: quei bit sono riservati, cioe' appartengono a qualcun
 * altro; azzerarli distrugge informazione che non si e' in grado di
 * interpretare. E il costo di preservarli e' nullo, perche' per
 * modificare una voce il settore va letto comunque.
 *
 * -----------------------------------------------------------------------
 * 5. FINE DIRECTORY: 0x00 E 0xE5 NON SONO LA STESSA COSA.
 *
 * 0xE5 = voce libera, si continua. 0x00 = voce libera E nessuna voce
 * allocata dopo, si puo' smettere.
 * Fermarsi su 0xE5 fa sparire ogni file che segue il primo cancellato:
 * errore di CORRETTEZZA. Non fermarsi su 0x00 costa una scansione inutile
 * di voci vuote: errore di PRESTAZIONE. Le due direzioni di sbaglio non
 * sono simmetriche, e la scelta va fatta sapendolo.
 *
 * Inoltre 0x05 come primo byte significa che il primo carattere vero e'
 * 0xE5 (era necessario perche' 0xE5 marca le voci libere). Va sostituito
 * in lettura, o quel file risulta con il nome sbagliato.
 *
 * -----------------------------------------------------------------------
 * 6. I CONFINI DEL TIPO: SEVERI IN LETTURA, PRUDENTI IN SCRITTURA.
 *
 * La regola e' <4085 FAT12, <65525 FAT16, altrimenti FAT32. Ma la
 * documentazione nota che le implementazioni reali non concordano di
 * ±1 sui confini, e che la specifica stessa differisce da altra
 * documentazione dello stesso produttore e dal comportamento dei suoi
 * strumenti (elm-chan.org/docs/fat_e.html).
 *
 * Ne discende un'asimmetria, che vale la pena enunciare:
 *   - LEGGENDO si segue la regola alla lettera. Qualunque scostamento
 *     farebbe interpretare male volumi creati da strumenti conformi.
 *   - FORMATTANDO (in futuro, mkfs) si dovra' EVITARE di produrre volumi
 *     con un numero di cluster vicino ai confini, perche' li' gli altri
 *     sistemi non sono d'accordo fra loro e il volume risulterebbe
 *     leggibile da alcuni e non da altri.
 *
 * -----------------------------------------------------------------------
 * 7. LA FIRMA STA A 510, NON "IN FONDO AL SETTORE".
 *
 * Coincidono solo con settori da 512 byte. Scrivere "in fondo" e' un bug
 * latente che si manifesta solo su supporti a settore grande.
 * ============================================================================= */

#include "kernel.h"
#include "fat.h"
#include "blk.h"

/* =============================================================================
 * Cache dei settori
 *
 * Condivisa fra i montaggi e indicizzata da (dispositivo, settore): un
 * solo insieme di slot da spartirsi e' meglio di N cache separate che si
 * dividono la memoria a priori senza sapere chi ne avra' bisogno.
 * ============================================================================= */
#define FAT_CACHE_SLOT   24

typedef struct {
    int      dev;        /* -1 = slot libero */
    uint32_t lba;
    uint32_t uso;        /* per LRU */
    uint8_t  dati[512];
} CacheSettore;

static CacheSettore g_cache[FAT_CACHE_SLOT];
static uint32_t     g_uso = 0;

static void cache_init(void)
{
    int i;
    for (i = 0; i < FAT_CACHE_SLOT; i++) g_cache[i].dev = -1;
}

/* Ritorna un puntatore ai dati del settore, o NULL su errore di lettura.
 * Il puntatore resta valido finche' non si chiede un altro settore. */
static const uint8_t *settore(int dev, uint32_t lba)
{
    int i, vittima = 0;
    uint32_t piu_vecchio = 0xFFFFFFFFu;

    for (i = 0; i < FAT_CACHE_SLOT; i++) {
        if (g_cache[i].dev == dev && g_cache[i].lba == lba) {
            g_cache[i].uso = ++g_uso;
            return g_cache[i].dati;
        }
        if (g_cache[i].dev < 0) { vittima = i; piu_vecchio = 0; }
        else if (g_cache[i].uso < piu_vecchio) {
            piu_vecchio = g_cache[i].uso;
            vittima = i;
        }
    }

    if (blk_read(dev, lba, 1, g_cache[vittima].dati) != 0) {
        g_cache[vittima].dev = -1;      /* contenuto non attendibile */
        return NULL;
    }

    g_cache[vittima].dev = dev;
    g_cache[vittima].lba = lba;
    g_cache[vittima].uso = ++g_uso;
    return g_cache[vittima].dati;
}

/* Invalida ogni slot di un dispositivo: serve allo smontaggio, altrimenti
 * un montaggio successivo dello stesso indice vedrebbe i settori del
 * volume precedente. */
static void cache_invalida(int dev)
{
    int i;
    for (i = 0; i < FAT_CACHE_SLOT; i++) {
        if (g_cache[i].dev == dev) g_cache[i].dev = -1;
    }
}

/* =============================================================================
 * Stato di un montaggio
 * ============================================================================= */
typedef struct {
    uint8_t  usato;
    int      dev;
    uint32_t tipo;            /* 12, 16, 32 */

    uint32_t byts_per_sec;
    uint32_t sec_per_clus;
    uint32_t n_fat;

    uint32_t fat_inizio;      /* settore relativo della prima FAT */
    uint32_t fat_sett;        /* settori di UNA FAT */
    uint32_t fat_attiva;      /* indice della FAT da leggere */

    uint32_t root_inizio;     /* FAT12/16: settore relativo della root */
    uint32_t root_sett;       /* FAT12/16 */
    uint32_t root_clus;       /* FAT32 */

    uint32_t dati_inizio;     /* primo settore dell'area dati */
    uint32_t n_cluster;       /* cluster dell'area dati */

    char     etichetta[12];
} FatMount;

static FatMount g_mnt[FAT_MAX_MOUNT];
static int      g_init = 0;

/* --- letture non allineate --- */
static uint16_t le16(const uint8_t *p) { return (uint16_t)p[0] | ((uint16_t)p[1] << 8); }
static uint32_t le32(const uint8_t *p)
{
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8)
         | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

/* =============================================================================
 * Valori speciali, per tipo.
 *
 * Vedi il punto 3 in testa al file: questi confronti sono il punto in cui
 * un errore diventa "file troncato senza errore".
 * ============================================================================= */
static uint32_t eoc_min(uint32_t tipo)
{
    if (tipo == 12) return 0x0FF8;
    if (tipo == 16) return 0xFFF8;
    return 0x0FFFFFF8u;
}

static uint32_t bad_clus(uint32_t tipo)
{
    if (tipo == 12) return 0x0FF7;
    if (tipo == 16) return 0xFFF7;
    return 0x0FFFFFF7u;
}

/* =============================================================================
 * fat_voce — legge la voce `clus` della FAT
 *
 * Ritorna il valore, oppure 0xFFFFFFFF se non e' stato possibile leggere
 * (che e' distinguibile da qualunque valore valido perche' i 4 bit alti
 * sono sempre azzerati anche su FAT32).
 *
 * Qui vive il caso a cavallo del settore descritto al punto 2.
 * ============================================================================= */
#define FAT_ERR   0xFFFFFFFFu

static uint32_t fat_voce(const FatMount *m, uint32_t clus)
{
    uint32_t off, sett, dentro;
    const uint8_t *s;

    if (clus < 2 || clus >= m->n_cluster + 2) return FAT_ERR;

    if (m->tipo == 12) {
        off = clus + (clus / 2);          /* due voci in tre byte */
    } else if (m->tipo == 16) {
        off = clus * 2;
    } else {
        off = clus * 4;
    }

    sett   = m->fat_inizio + m->fat_attiva * m->fat_sett + off / m->byts_per_sec;
    dentro = off % m->byts_per_sec;

    s = settore(m->dev, sett);
    if (s == NULL) return FAT_ERR;

    if (m->tipo == 16) return le16(s + dentro);
    if (m->tipo == 32) return le32(s + dentro) & 0x0FFFFFFFu;

    /* --- FAT12 ---
     * Il secondo byte puo' stare nel settore successivo. Leggerlo dal
     * buffer corrente significherebbe prendere un byte che non appartiene
     * a questa voce — e ottenere un numero di cluster arbitrario. */
    {
        uint8_t  b0 = s[dentro];
        uint8_t  b1;

        if (dentro + 1 < m->byts_per_sec) {
            b1 = s[dentro + 1];
        } else {
            const uint8_t *s2 = settore(m->dev, sett + 1);
            if (s2 == NULL) return FAT_ERR;
            b1 = s2[0];
            /* Attenzione: `s` ora puo' essere stato sfrattato dalla cache
             * per fare posto a `s2`. b0 e' gia' stato copiato, quindi non
             * si rilegge nulla da `s` dopo questo punto. */
        }

        {
            uint16_t v = (uint16_t)b0 | ((uint16_t)b1 << 8);
            return (clus & 1) ? (uint32_t)(v >> 4) : (uint32_t)(v & 0x0FFF);
        }
    }
}

/* Primo settore di un cluster dati. */
static uint32_t clus_lba(const FatMount *m, uint32_t clus)
{
    return m->dati_inizio + (clus - 2) * m->sec_per_clus;
}

/* =============================================================================
 * Montaggio
 * ============================================================================= */
int fat_mount(int blkdev)
{
    const uint8_t *s;
    FatMount m;
    int      i, slot = -1;
    uint16_t bps, resvd, root_ent, tot16, fatsz16;
    uint32_t tot32, fatsz32, tot, fatsz, root_dir_sec, meta, dati;
    uint8_t  spc, n_fat;

    if (!g_init) { cache_init(); g_init = 1; }

    for (i = 0; i < FAT_MAX_MOUNT; i++) {
        if (!g_mnt[i].usato) { slot = i; break; }
    }
    if (slot < 0) return -1;

    s = settore(blkdev, 0);
    if (s == NULL) return -1;

    /* La firma sta a 510 SEMPRE, non "in fondo al settore" (punto 7). */
    if (s[510] != 0x55 || s[511] != 0xAA) return -1;

    bps      = le16(s + 11);
    spc      = s[13];
    resvd    = le16(s + 14);
    n_fat    = s[16];
    root_ent = le16(s + 17);
    tot16    = le16(s + 19);
    fatsz16  = le16(s + 22);
    tot32    = le32(s + 32);
    fatsz32  = le32(s + 36);

    /* Questo driver lavora su settori da 512: il livello a blocchi
     * trasferisce settori di quella dimensione. Un volume con settori
     * diversi va rifiutato, non letto male. */
    if (bps != 512)                    return -1;
    if (spc == 0 || (spc & (spc - 1))) return -1;   /* potenza di due */
    if (spc > 128)                     return -1;
    if (resvd == 0)                    return -1;
    if (n_fat == 0 || n_fat > 4)       return -1;

    tot   = (tot16   != 0) ? (uint32_t)tot16   : tot32;
    fatsz = (fatsz16 != 0) ? (uint32_t)fatsz16 : fatsz32;
    if (tot == 0 || fatsz == 0) return -1;

    root_dir_sec = ((uint32_t)root_ent * 32 + (bps - 1)) / bps;
    meta         = resvd + (uint32_t)n_fat * fatsz + root_dir_sec;
    if (meta >= tot) return -1;
    dati = tot - meta;

    m.n_cluster = dati / spc;
    if (m.n_cluster == 0) return -1;

    /* LA REGOLA, alla lettera (punto 6). */
    if (m.n_cluster < 4085)       m.tipo = 12;
    else if (m.n_cluster < 65525) m.tipo = 16;
    else                          m.tipo = 32;

    m.usato        = 1;
    m.dev          = blkdev;
    m.byts_per_sec = bps;
    m.sec_per_clus = spc;
    m.n_fat        = n_fat;
    m.fat_inizio   = resvd;
    m.fat_sett     = fatsz;
    m.fat_attiva   = 0;
    m.root_sett    = root_dir_sec;
    m.root_inizio  = resvd + (uint32_t)n_fat * fatsz;
    m.root_clus    = 0;
    m.dati_inizio  = m.root_inizio + root_dir_sec;

    if (m.tipo == 32) {
        /* BPB_ExtFlags: bit 7 = mirroring DISATTIVO, bit 0-3 = FAT attiva.
         * Va onorato: leggere (e domani scrivere) la FAT sbagliata su un
         * volume con mirroring disattivo significa usare una copia che il
         * sistema che l'ha creato non aggiorna. */
        uint16_t ext = le16(s + 40);
        if (ext & 0x0080) {
            m.fat_attiva = ext & 0x000F;
            if (m.fat_attiva >= n_fat) m.fat_attiva = 0;
        }
        m.root_clus = le32(s + 44) & 0x0FFFFFFFu;
        if (m.root_clus < 2 || m.root_clus >= m.n_cluster + 2) return -1;

        for (i = 0; i < 11; i++) m.etichetta[i] = (char)s[71 + i];
    } else {
        if (root_ent == 0) return -1;   /* incoerente col tipo dedotto */
        for (i = 0; i < 11; i++) m.etichetta[i] = (char)s[43 + i];
    }
    m.etichetta[11] = '\0';
    for (i = 10; i >= 0 && (m.etichetta[i] == ' ' || m.etichetta[i] == 0); i--) {
        m.etichetta[i] = '\0';
    }

    g_mnt[slot] = m;

    klog(LOG_INFO, "FAT: montato dispositivo %d: FAT%u, %u cluster da %u settori, '%s'",
         blkdev, m.tipo, m.n_cluster, m.sec_per_clus, m.etichetta);

    return slot;
}

int fat_umount(int mnt)
{
    if (mnt < 0 || mnt >= FAT_MAX_MOUNT || !g_mnt[mnt].usato) return -1;
    cache_invalida(g_mnt[mnt].dev);
    g_mnt[mnt].usato = 0;
    return 0;
}

int fat_tipo(int mnt)
{
    if (mnt < 0 || mnt >= FAT_MAX_MOUNT || !g_mnt[mnt].usato) return -1;
    return (int)g_mnt[mnt].tipo;
}

uint32_t fat_n_cluster(int mnt)
{
    if (mnt < 0 || mnt >= FAT_MAX_MOUNT || !g_mnt[mnt].usato) return 0;
    return g_mnt[mnt].n_cluster;
}

const char *fat_etichetta(int mnt)
{
    if (mnt < 0 || mnt >= FAT_MAX_MOUNT || !g_mnt[mnt].usato) return "";
    return g_mnt[mnt].etichetta;
}

/* =============================================================================
 * Percorrenza di una directory
 *
 * Una directory e' o l'area root fissa (FAT12/16) o una catena di cluster
 * (FAT32, e ogni sottodirectory di qualunque tipo). Le due cose si
 * percorrono diversamente, e questo iteratore nasconde la differenza.
 * ============================================================================= */
typedef struct {
    const FatMount *m;
    uint32_t clus;        /* 0 = area root fissa */
    uint32_t lba;         /* settore corrente */
    uint32_t rimasti;     /* settori rimasti nell'area root fissa */
    uint32_t in_clus;     /* settori gia' consumati del cluster corrente */
    uint32_t idx;         /* indice della voce dentro il settore */
    int      fine;
} DirIter;

static void dir_apri(DirIter *it, const FatMount *m, uint32_t clus)
{
    it->m       = m;
    it->clus    = clus;
    it->idx     = 0;
    it->in_clus = 0;
    it->fine    = 0;

    if (clus == 0) {
        it->lba     = m->root_inizio;
        it->rimasti = m->root_sett;
        if (it->rimasti == 0) it->fine = 1;
    } else {
        it->lba     = clus_lba(m, clus);
        it->rimasti = 0;
    }
}

/* Avanza al settore successivo. Ritorna 0 se c'e', -1 se finita. */
static int dir_prossimo_settore(DirIter *it)
{
    const FatMount *m = it->m;

    if (it->clus == 0) {
        if (it->rimasti <= 1) return -1;
        it->rimasti--;
        it->lba++;
        return 0;
    }

    it->in_clus++;
    if (it->in_clus < m->sec_per_clus) {
        it->lba++;
        return 0;
    }

    {
        uint32_t p = fat_voce(m, it->clus);

        if (p == FAT_ERR) return -1;
        if (p == bad_clus(m->tipo)) {
            klog(LOG_ERROR, "FAT: cluster danneggiato nella catena di una directory");
            return -1;
        }
        if (p >= eoc_min(m->tipo)) return -1;      /* fine, regolare */
        if (p < 2 || p >= m->n_cluster + 2) {
            klog(LOG_ERROR, "FAT: cluster %u fuori range in una directory", p);
            return -1;
        }

        it->clus    = p;
        it->in_clus = 0;
        it->lba     = clus_lba(m, p);
        return 0;
    }
}

/* Legge la prossima voce grezza da 32 byte. Ritorna:
 *   1 = voce restituita in `dst`
 *   0 = directory finita
 *  -1 = errore di lettura                                              */
static int dir_prossima(DirIter *it, uint8_t *dst)
{
    const FatMount *m = it->m;

    while (!it->fine) {
        const uint8_t *s = settore(m->dev, it->lba);
        uint32_t per_sett = m->byts_per_sec / 32;
        uint32_t k;

        if (s == NULL) return -1;

        while (it->idx < per_sett) {
            const uint8_t *v = s + it->idx * 32;

            it->idx++;

            /* 0x00: libera E nessuna voce allocata dopo. Ci si puo'
             * fermare. Vedi il punto 5 in testa al file. */
            if (v[0] == 0x00) { it->fine = 1; return 0; }

            /* 0xE5: libera, ma si CONTINUA. Fermarsi qui farebbe sparire
             * ogni file che segue il primo cancellato. */
            if (v[0] == 0xE5) continue;

            for (k = 0; k < 32; k++) dst[k] = v[k];
            return 1;
        }

        it->idx = 0;
        if (dir_prossimo_settore(it) != 0) { it->fine = 1; return 0; }
    }

    return 0;
}

/* =============================================================================
 * Nomi
 * ============================================================================= */

/* Converte il nome 8.3 grezzo in stringa leggibile. */
static void nome_da_83(const uint8_t *v, char *out)
{
    int i, j = 0;

    for (i = 0; i < 8 && v[i] != ' '; i++) out[j++] = (char)v[i];

    /* 0x05 al primo byte significa che il primo carattere vero e' 0xE5:
     * la sostituzione esiste perche' 0xE5 marca le voci libere. Senza
     * questo, quel file avrebbe il nome sbagliato. */
    if (j > 0 && (uint8_t)out[0] == 0x05) out[0] = (char)0xE5;

    if (v[8] != ' ') {
        out[j++] = '.';
        for (i = 8; i < 11 && v[i] != ' '; i++) out[j++] = (char)v[i];
    }
    out[j] = '\0';
}

static char su_maiuscolo(char c)
{
    return (c >= 'a' && c <= 'z') ? (char)(c - 32) : c;
}

/* Confronta un nome utente con il nome 8.3 di una voce, senza distinguere
 * maiuscole e minuscole. */
static int nome_uguale(const char *utente, const uint8_t *v)
{
    char n[FAT_NOME_MAX];
    int  i;

    nome_da_83(v, n);

    for (i = 0; ; i++) {
        char a = su_maiuscolo(utente[i]);
        char b = su_maiuscolo(n[i]);
        if (a != b) return 0;
        if (a == '\0') return 1;
    }
}

/* =============================================================================
 * Risoluzione di un percorso
 *
 * Percorre i componenti separati da '/'. Non c'e' un limite di
 * profondita' come nel vecchio FAT12: una sottodirectory e' una catena di
 * cluster come un'altra, quindi non c'e' ragione di fermarsi al primo
 * livello.
 * ============================================================================= */
static int risolvi(const FatMount *m, const char *percorso,
                   uint8_t *voce_out, uint32_t *clus_dir_out)
{
    uint32_t clus = 0;              /* 0 = root (FAT12/16) */
    const char *p = percorso;
    uint8_t voce[32];
    int     trovato_qualcosa = 0;

    if (m->tipo == 32) clus = m->root_clus;

    if (clus_dir_out) *clus_dir_out = clus;

    while (*p == '/') p++;

    while (*p) {
        char comp[FAT_NOME_MAX];
        int  n = 0;
        DirIter it;
        int     esito;
        int     trovato = 0;

        while (*p && *p != '/' && n < FAT_NOME_MAX - 1) comp[n++] = *p++;
        comp[n] = '\0';
        while (*p == '/') p++;

        if (n == 0) break;

        dir_apri(&it, m, clus);

        while ((esito = dir_prossima(&it, voce)) == 1) {
            /* Le voci di nome lungo sono frammenti, non file: vanno
             * saltate o comparirebbero come nomi spazzatura. */
            if ((voce[11] & FAT_ATTR_LFN) == FAT_ATTR_LFN) continue;
            if (voce[11] & FAT_ATTR_VOLID) continue;

            if (nome_uguale(comp, voce)) { trovato = 1; break; }
        }

        if (esito < 0) return -1;
        if (!trovato)  return -1;

        trovato_qualcosa = 1;

        {
            uint32_t primo = (uint32_t)le16(voce + 26);
            if (m->tipo == 32) primo |= ((uint32_t)le16(voce + 20)) << 16;

            if (*p == '\0') {
                if (voce_out) {
                    int k;
                    for (k = 0; k < 32; k++) voce_out[k] = voce[k];
                }
                if (clus_dir_out) *clus_dir_out = primo;
                return 0;
            }

            /* Non e' l'ultimo componente: deve essere una directory. */
            if (!(voce[11] & FAT_ATTR_DIR)) return -1;

            /* ".." della root punta a cluster 0: e' la convenzione, e va
             * riportato alla root vera del volume. */
            clus = primo;
            if (m->tipo == 32 && clus == 0) clus = m->root_clus;
        }
    }

    /* Percorso vuoto o solo "/": e' la root. */
    if (!trovato_qualcosa) {
        if (clus_dir_out) *clus_dir_out = (m->tipo == 32) ? m->root_clus : 0;
        if (voce_out) voce_out[0] = 0;
        return 0;
    }

    return -1;
}

/* =============================================================================
 * API pubblica
 * ============================================================================= */
static void riempi(FatDirEntry *o, const FatMount *m, const uint8_t *v)
{
    nome_da_83(v, o->nome);
    o->attributi     = v[11];
    o->is_dir        = (v[11] & FAT_ATTR_DIR) ? 1 : 0;
    o->dimensione    = le32(v + 28);
    o->primo_cluster = (uint32_t)le16(v + 26);
    if (m->tipo == 32) o->primo_cluster |= ((uint32_t)le16(v + 20)) << 16;
}

int fat_readdir(int mnt, const char *percorso, FatDirEntry *out,
                uint32_t max, uint32_t start)
{
    FatMount *m;
    uint32_t  clus;
    DirIter   it;
    uint8_t   voce[32];
    uint32_t  visti = 0, scritti = 0;
    int       esito;

    if (mnt < 0 || mnt >= FAT_MAX_MOUNT || !g_mnt[mnt].usato) return -1;
    if (out == NULL || max == 0) return -1;
    m = &g_mnt[mnt];

    if (risolvi(m, percorso, NULL, &clus) != 0) return -1;
    if (m->tipo != 32 && clus == m->root_clus) clus = 0;

    dir_apri(&it, m, clus);

    while (scritti < max && (esito = dir_prossima(&it, voce)) == 1) {
        if ((voce[11] & FAT_ATTR_LFN) == FAT_ATTR_LFN) continue;
        if (voce[11] & FAT_ATTR_VOLID) continue;

        if (visti++ < start) continue;

        riempi(&out[scritti], m, voce);
        scritti++;
    }

    if (esito < 0 && scritti == 0) return -1;
    return (int)scritti;
}

int fat_stat(int mnt, const char *percorso, FatDirEntry *out)
{
    FatMount *m;
    uint8_t   voce[32];

    if (mnt < 0 || mnt >= FAT_MAX_MOUNT || !g_mnt[mnt].usato) return -1;
    m = &g_mnt[mnt];

    if (risolvi(m, percorso, voce, NULL) != 0) return -1;
    if (voce[0] == 0) return -1;    /* era la root, non un file */

    if (out) riempi(out, m, voce);
    return 0;
}

int fat_read(int mnt, const char *percorso, void *buf,
             uint32_t size, uint32_t offset)
{
    FatMount    *m;
    FatDirEntry  e;
    uint32_t     clus, salti, i;
    uint32_t     letti = 0;
    uint8_t     *dst = (uint8_t *)buf;
    uint32_t     clus_byte;

    if (mnt < 0 || mnt >= FAT_MAX_MOUNT || !g_mnt[mnt].usato) return -1;
    if (buf == NULL) return -1;
    m = &g_mnt[mnt];

    if (fat_stat(mnt, percorso, &e) != 0) return -1;
    if (e.is_dir) return -1;

    if (offset >= e.dimensione) return 0;
    if (size > e.dimensione - offset) size = e.dimensione - offset;
    if (size == 0) return 0;

    clus_byte = m->sec_per_clus * m->byts_per_sec;
    clus      = e.primo_cluster;
    salti     = offset / clus_byte;

    /* Salto fino al cluster che contiene l'offset richiesto. */
    for (i = 0; i < salti; i++) {
        uint32_t p;

        if (clus < 2 || clus >= m->n_cluster + 2) return -1;
        p = fat_voce(m, clus);
        if (p == FAT_ERR) return -1;
        if (p == bad_clus(m->tipo)) return -1;

        /* LA CATENA FINISCE PRIMA DI QUANTO DICA LA DIMENSIONE.
         * Questo e' un errore, non una fine: e' esattamente il caso in
         * cui il bug del 1986 restituiva silenziosamente un file
         * troncato. Vedi il punto 3 in testa al file. */
        if (p >= eoc_min(m->tipo)) {
            klog(LOG_ERROR, "FAT: '%s' dichiara %u byte ma la catena finisce prima",
                 percorso, e.dimensione);
            return -1;
        }
        clus = p;
    }

    {
        uint32_t dentro = offset % clus_byte;

        while (letti < size) {
            uint32_t base, s, primo_s, off_s, quanti;

            if (clus < 2 || clus >= m->n_cluster + 2) return -1;

            base    = clus_lba(m, clus);
            primo_s = dentro / m->byts_per_sec;
            off_s   = dentro % m->byts_per_sec;

            for (s = primo_s; s < m->sec_per_clus && letti < size; s++) {
                const uint8_t *sd = settore(m->dev, base + s);
                if (sd == NULL) return -1;

                quanti = m->byts_per_sec - off_s;
                if (quanti > size - letti) quanti = size - letti;

                for (i = 0; i < quanti; i++) dst[letti + i] = sd[off_s + i];

                letti += quanti;
                off_s  = 0;
            }

            if (letti >= size) break;

            {
                uint32_t p = fat_voce(m, clus);
                if (p == FAT_ERR || p == bad_clus(m->tipo)) return -1;
                if (p >= eoc_min(m->tipo)) {
                    klog(LOG_ERROR, "FAT: '%s': catena finita a %u byte su %u attesi",
                         percorso, offset + letti, e.dimensione);
                    return -1;
                }
                clus = p;
            }
            dentro = 0;
        }
    }

    return (int)letti;
}
