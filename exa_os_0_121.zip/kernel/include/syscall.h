/* =============================================================================
 * kernel/include/syscall.h
 * EX-OS — Extensible Operating System
 *
 * Copyright (C) 2025 Graziano Falcone <exagonx@hotmail.com>
 *
 * SPDX-License-Identifier: GPL-2.0-or-later
 * This file is part of EX-OS, distributed under the GNU GPL v2.
 * See the LICENSE file in the project root for the full license text.
 * ============================================================================= */

#ifndef SYSCALL_H
#define SYSCALL_H

#include "kernel.h"
#include "idt.h"

/* =============================================================================
 * Numeri di syscall (stile Linux x86)
 * ============================================================================= */
#define SYS_EXIT        1
#define SYS_SPAWN       2      /* crea processo figlio autonomo (vedi sys_spawn) */
#define SYS_READ        3
#define SYS_WRITE       4
#define SYS_OPEN        5
#define SYS_CLOSE       6
#define SYS_WAITPID     7
#define SYS_GETPID      20
#define SYS_GETPPID     64
#define SYS_MMAP        90
#define SYS_MUNMAP      91
#define SYS_IOCTL       54
#define SYS_EXEC        11
#define SYS_SCHED_YIELD 158
#define SYS_SLEEP       162
#define SYS_SBRK        45
#define SYS_GETCWD      183
#define SYS_CHDIR       12
#define SYS_STAT        106
#define SYS_LSEEK       19
#define SYS_READDIR     141    /* elenca una directory (vedi sys_readdir) */
#define SYS_GETENV      184    /* legge una variabile [env] di /boot/kernel.cfg */
#define SYS_MKDIR        39    /* crea una directory */
#define SYS_RMDIR        40    /* cancella una directory vuota */
#define SYS_UNLINK       10    /* cancella un file */
#define SYS_VERSION     185    /* copia g_os_version (identità del sistema) */
#define SYS_UPTIME      186    /* millisecondi dall'avvio (vedi sys_uptime) */
#define SYS_REBOOT       88    /* spegne, riavvia o ferma il sistema */

/* Numero totale syscall supportate */
#define SYSCALL_COUNT   228     /* deve coprire il numero syscall più alto (SYS_IOPORT_OUT=227) + 1 */

/* =============================================================================
 * Codici errno
 * ============================================================================= */
#define EOK         0
#define EPERM       1
#define ENOENT      2
#define EINTR       4
#define EIO         5
#define EBADF       9
#define ENOMEM      12
#define EACCES      13
#define EFAULT      14
#define EBUSY       16
#define EEXIST      17
#define EINVAL      22
#define EMFILE      24
#define ENOSPC      28
#define EPIPE       32
#define ENOSYS      38
#define ESRCH       3       /* processo destinatario non esiste */
#define ENOTDIR     20      /* atteso una directory, trovato altro */
#define ENOTEMPTY   39      /* directory non vuota (rmdir) */
#define EISDIR      21      /* atteso un file, trovata una directory */

/* Syscall IPC — comunicazione kernel-mediata tra task ring3 */
#define SYS_IPC_SEND     220
#define SYS_IPC_RECV     221
#define SYS_IPC_REGISTER 222
#define SYS_IPC_LOOKUP   223

/* Syscall hardware kernel-mediato — driver ring3 */
#define SYS_IRQ_BIND      224   /* rivendica un IRQ hardware, notifiche via IPC */
#define SYS_IOPORT_BIND   225   /* richiede un range di porte I/O in whitelist */
#define SYS_IOPORT_IN     226   /* legge un byte da una porta nel proprio range */
#define SYS_IOPORT_OUT    227   /* scrive un byte su una porta nel proprio range */

/* Converti errno in valore di ritorno negativo */
#define ERR(e)      (-(int32_t)(e))

/* =============================================================================
 * Flag per sys_open
 * ============================================================================= */
#define O_RDONLY    0x0000
#define O_WRONLY    0x0001
#define O_RDWR      0x0002
#define O_CREAT     0x0040
#define O_TRUNC     0x0200
#define O_APPEND    0x0400
#define O_NONBLOCK  0x0800

/* =============================================================================
 * Flag per sys_mmap
 * ============================================================================= */
#define PROT_NONE   0x0
#define PROT_READ   0x1
#define PROT_WRITE  0x2
#define PROT_EXEC   0x4

#define MAP_SHARED      0x01
#define MAP_PRIVATE     0x02
#define MAP_ANONYMOUS   0x20
#define MAP_FIXED       0x10

/* =============================================================================
 * Struttura stat (per sys_stat)
 * ============================================================================= */
typedef struct {
    uint32_t    st_size;        /* Dimensione file */
    uint32_t    st_first_clus;  /* Primo cluster FAT12 */
    uint16_t    st_attr;        /* Attributi FAT12 */
    uint16_t    st_date;        /* Data modifica */
    uint16_t    st_time;        /* Ora modifica */
} Stat;

/* =============================================================================
 * Struttura voce di directory (per sys_readdir)
 * ============================================================================= */
#define DIRENT_NAME_MAX 13   /* "NOME8.EXT3" + NUL, formato 8.3 */

typedef struct {
    char     name[DIRENT_NAME_MAX];
    uint32_t size;
    uint8_t  is_dir;
} DirEntry;

/* =============================================================================
 * Struttura parametri mmap (passata come puntatore in EBX)
 * ============================================================================= */
typedef struct {
    uint32_t    addr;
    uint32_t    length;
    uint32_t    prot;
    uint32_t    flags;
    int32_t     fd;
    uint32_t    offset;
} MmapParams;

/* =============================================================================
 * Tipo handler syscall
 * Ogni syscall riceve l'InterruptFrame e ritorna int32_t
 * (valore positivo = successo, negativo = errore)
 * ============================================================================= */
typedef int32_t (*SyscallFn)(InterruptFrame *frame);

/* =============================================================================
 * Interfaccia pubblica
 * ============================================================================= */
void    syscall_init(void);
void    syscall_handler(InterruptFrame *frame);

/* Implementazioni singole syscall (definite in syscall_impl.c) */
int32_t sys_exit(InterruptFrame *f);
int32_t sys_spawn(InterruptFrame *f);
int32_t sys_read(InterruptFrame *f);
int32_t sys_write(InterruptFrame *f);
int32_t sys_open(InterruptFrame *f);
int32_t sys_close(InterruptFrame *f);
int32_t sys_waitpid(InterruptFrame *f);
int32_t sys_getpid(InterruptFrame *f);
int32_t sys_getppid(InterruptFrame *f);
int32_t sys_mmap(InterruptFrame *f);
int32_t sys_munmap(InterruptFrame *f);
int32_t sys_ioctl(InterruptFrame *f);
int32_t sys_exec(InterruptFrame *f);
int32_t sys_sched_yield(InterruptFrame *f);
int32_t sys_sleep(InterruptFrame *f);
int32_t sys_sbrk(InterruptFrame *f);
int32_t sys_getcwd(InterruptFrame *f);
int32_t sys_chdir(InterruptFrame *f);
int32_t sys_stat(InterruptFrame *f);
int32_t sys_lseek(InterruptFrame *f);
int32_t sys_readdir(InterruptFrame *f);
int32_t sys_getenv(InterruptFrame *f);
int32_t sys_mkdir(InterruptFrame *f);
int32_t sys_rmdir(InterruptFrame *f);
int32_t sys_unlink(InterruptFrame *f);
int32_t sys_version(InterruptFrame *f);
int32_t sys_uptime(InterruptFrame *f);
int32_t sys_reboot(InterruptFrame *f);
int32_t sys_ipc_send(InterruptFrame *f);
int32_t sys_ipc_recv(InterruptFrame *f);
int32_t sys_ipc_register(InterruptFrame *f);
int32_t sys_ipc_lookup(InterruptFrame *f);
int32_t sys_irq_bind(InterruptFrame *f);
int32_t sys_ioport_bind(InterruptFrame *f);
int32_t sys_ioport_in(InterruptFrame *f);
int32_t sys_ioport_out(InterruptFrame *f);

/* Verifica indirizzo utente (evita accessi kernel da ring3) */
int     syscall_verify_ptr(const void *ptr, uint32_t size);
int     syscall_verify_str(const char *str, uint32_t max_len);

#endif /* SYSCALL_H */
