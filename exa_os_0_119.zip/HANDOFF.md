# EX-OS — Handoff

---

# SESSIONE 2026-07-30 (m) — La shell non parte su hardware reale + scrittura del floppy da WSL

Segnalazione: su macchina reale la shell non si avvia. Il floppy è **USB**,
visto da Windows come A:, e l'ambiente di sviluppo è WSL. Kernel a **0.115**.

## Trovato un difetto che da solo può spiegare tutto

`fdc_motor_on()` aspettava **300 ms a ogni chiamata**, cioè a ogni accesso a
un settore, nonostante il commento dicesse "no-op se il motore è già in moto".
I 300 ms sono il tempo di stabilizzazione del motore: servono **una volta**,
non per operazione.

Il conto per un avvio: FAT (9 settori) + root directory (14) + `/dev/kbd.drv`
(~27) + `/bin/sh` (~27), più le ricerche nelle directory — oltre 80 accessi.
**Più di 24 secondi di sola attesa del motore**, a cui su hardware vero si
sommano i tempi reali di seek e di lettura. Un avvio così sembra un sistema
bloccato, ed è facilissimo spegnere prima che la shell compaia.

**Misurato in QEMU: da 19,7 s a 0,8 s.** Un fattore 24. Su hardware reale il
guadagno assoluto è ancora maggiore, perché lì i 300 ms sono veri.

Il flag `g_motor_running` viene azzerato dal reset del controller e da
`fdc_motor_off`, così l'attesa torna a farsi quando serve davvero.

## Rete di sicurezza: se l'IRQ6 non arriva

Dalla sessione (f) il driver aspetta l'IRQ6 per sapere che il comando è
finito. È il modo corretto, ma dipende da come il chipset instrada
l'interrupt: se su una macchina sconosciuta non arriva, **ogni lettura
fallirebbe** e il sistema non caricherebbe nemmeno la shell.

Ora, se `fdc_wait_irq` va in timeout, si prova a leggere la fase di risultato
sondando MSR — che è esattamente ciò che il driver faceva prima di usare
l'IRQ6. Il trasferimento lo fa il DMA, non l'interrupt: se i dati sono
arrivati, il controller è comunque in fase di risultato.

Il warning resta e dice cosa controllare: un sistema che funziona solo grazie
al ripiego deve dirlo, altrimenti il problema vero non si scopre mai.

## ⚠️ Il floppy USB: un problema che nessuna correzione del driver risolve

Questo va capito prima di continuare a cercare bug.

| Fase | Come accede al disco | Funziona con floppy USB? |
|---|---|---|
| Stage1/Stage2 (bootloader) | **BIOS INT 13h** | ✅ sì, il BIOS emula |
| Kernel (`kernel/fs/fat12.c`) | **hardware diretto**: porte 0x3F0-0x3F7, DMA canale 2, IRQ6 | ❌ **no** |

Un floppy USB **non è** collegato al controller floppy ISA. Il BIOS lo fa
sembrare un'unità A: avviabile finché si è in real mode, ma appena il kernel
passa in protected mode e parla al controller 82077, quel controller o non
esiste o non ha nessun disco dentro.

Il sintomo previsto è esattamente quello riportato: **il bootloader carica il
kernel, il kernel parte, e poi non riesce a leggere `/bin/sh`.**

Le tre strade possibili, nessuna gratuita:

1. **Usare un drive floppy interno vero** (connettore FDC sulla scheda madre).
   È l'unica che funziona subito, senza scrivere codice.
2. **Caricare `/bin/sh` come initrd**: far leggere a Stage2, che è ancora in
   real mode e può usare INT 13h, anche la shell oltre al kernel, passandola
   in memoria. Il sistema arriverebbe al prompt anche senza un driver FDC
   funzionante. Fattibile e circoscritto.
3. **Scrivere un driver USB** (UHCI/EHCI + mass storage + BOT). Enormemente
   più grande di tutto il resto del sistema messo insieme.

## Come distinguere le cause: la console seriale

Non serve indovinare. Il kernel specchia tutto su COM1, e i messaggi
introdotti nelle ultime sessioni separano i casi:

```bash
qemu-system-i386 ... -serial file:/tmp/serial.txt      # in emulazione
# su hardware reale: cavo null-modem su COM1, 38400 8N1
```

| Cosa si legge | Cosa significa |
|---|---|
| `[PASSO 13] FAT12 OK` poi `[PASSO 15] Shell ... caricata` | il disco si legge: il problema è altrove |
| `FAT12: timeout IRQ6 su READ ... proseguo con il polling` | l'IRQ6 non arriva ma il DMA sì: sistema funzionante col ripiego, da indagare |
| `timeout IRQ6 ... e nessuna fase di risultato` | il controller non risponde affatto → **compatibile con il floppy USB** |
| `FAT12: SEEK non confermato` | il controller c'è ma la testina non si posiziona |
| `[PASSO 15] '/bin/sh' non trovata — avvio senza shell` | la lettura fallisce o restituisce dati sbagliati |
| nessun `[PASSO 13]` | il kernel non arriva nemmeno lì: problema a monte |

**Prima di tutto: riprovare con questa versione e aspettare.** Se prima il
sistema veniva spento dopo pochi secondi, il difetto del motore da solo
spiegherebbe il sintomo.

## Scrivere il floppy: tre modi, un solo motore

| Da dove | Comando |
|---|---|
| WSL | `./tools/write_floppy.sh` |
| PowerShell | `.\tools\write_floppy.ps1` |
| cmd.exe / doppio clic | `tools\write-floppy.cmd` |

Tutti finiscono in `write_floppy.ps1`, che **si rieleva da solo** (UAC) in una
finestra che resta aperta per mostrare l'esito: non serve aprire una console
come Amministratore. Senza argomenti prende `..\dist\floppy.img` rispetto alla
posizione dello script e scrive su A:.

I controlli che non richiedono privilegi (immagine esistente, lettera di unità
valida) sono fatti **prima** di elevare: un refuso non deve costare una
richiesta UAC per poi scoprire che era solo un refuso.

### ⚠️ Trappola trovata: PowerShell, UTF-8 e i trattini lunghi

Il file `.ps1` va tenuto in **puro ASCII**, e c'è un motivo preciso.

PowerShell 5.1 legge uno script privo di BOM come **Windows-1252**, non come
UTF-8. Un trattino lungo `—` (U+2014, byte `E2 80 94`) diventa quindi tre
caratteri, e l'ultimo è `”` — U+201D, la virgoletta doppia tipografica di
chiusura, che il parser di PowerShell **accetta come delimitatore di stringa**.

Bastavano sei trattini lunghi nei commenti perché le virgolette del resto del
file non tornassero più: il blocco `Add-Type` smetteva di essere riconosciuto
come here-string e il parser segnalava
`Un'istruzione 'using' deve precedere tutte le altre istruzioni` su una riga
che non c'entrava nulla. Un errore che manda fuori strada, perché indica un
punto lontano dalla causa.

Diagnosticato bisezionando il file e confermato per esperimento: sostituendo i
sei trattini con `-`, lo stesso file parsa senza errori. Ora c'è un avviso in
testa allo script.

### Trappola in cui sono caduto io, durante la correzione

Uno script Python di conversione faceva `p.write_text(s, encoding="ascii")` su
un testo che conteneva ancora un carattere non-ASCII. `write_text` **apre il
file in scrittura (troncandolo) e solo dopo codifica**: l'eccezione ha lasciato
il file a **zero byte**. I controlli successivi continuavano a rispondere
"sintassi OK" — perché un file vuoto è sintatticamente valido. Il file è stato
riscritto da capo.

Lezione buona anche altrove: quando una verifica passa su un file che si è
appena scritto, vale la pena controllare che quel file non sia vuoto.

## Dettagli dell'implementazione

```bash
./tools/write_floppy.sh              # dist/floppy.img su A:
./tools/write_floppy.sh -d B: -y
```

**Perché non basta `dd`**: WSL2 gira in una VM leggera e non vede i dischi
fisici di Windows — non esiste `/dev/fd0`, e `wsl --mount` non gestisce i
floppy USB. L'unica strada è passare da Windows. Lo script converte il
percorso con `wslpath`, poi lancia `tools/write_floppy.ps1` tramite l'interop,
chiedendo l'elevazione (serve per aprire il volume grezzo `\\.\A:`).

Cosa fa lo script PowerShell, e perché:

- **blocca e smonta il volume** (`FSCTL_LOCK_VOLUME`, `FSCTL_DISMOUNT_VOLUME`)
  prima di scrivere: altrimenti il filesystem montato può riscrivere i propri
  metadati sopra l'immagine, e la cache di Windows restituire dati vecchi alla
  verifica;
- apre con `NO_BUFFERING | WRITE_THROUGH`: si va sul supporto, non in cache;
- **rifiuta le unità non rimovibili** (`DriveType != 2`) salvo `-Force`. Non è
  una formalità: lo stesso codice puntato su C: lo renderebbe non avviabile;
- chiede conferma esplicita (`SI` in maiuscolo) salvo `-y`;
- **rilegge e confronta** byte per byte, e indica il primo settore diverso.
  Un floppy con un settore difettoso è una causa perfettamente plausibile di
  "non si avvia", e senza verifica non lo si scoprirebbe.

**Non testato su hardware**: sintassi di entrambi gli script verificata e
percorsi di errore provati (immagine assente, interop mancante), ma la
scrittura vera richiede un disco inserito e l'UAC.

---

# SESSIONE 2026-07-30 (l) — "delete cancella solo le prime 128 voci?": era peggio, 64

Domanda dell'utente sul limite di `/bin/delete`. Kernel a **0.114**.

## Il limite vero era 64, e nessuno lo diceva

`sys_readdir` ha un tetto interno di **64 voci per chiamata**
(`READDIR_MAX_BATCH`), applicato *indipendentemente da quanto chiede il
chiamante*. Quindi:

- `delete` chiedeva 128 voci e ne riceveva al massimo 64;
- il suo avviso "esaminate solo le prime 128" **non poteva scattare mai**:
  `n` non poteva raggiungere 128. Codice morto che dava una falsa sicurezza;
- `/bin/ls` aveva lo stesso identico problema: buffer da 64, una sola
  chiamata. Una directory più grande veniva mostrata **incompleta senza il
  minimo avviso** — sembrava semplicemente che quei file non esistessero.

Il troncamento silenzioso è la parte peggiore: `delete /big/tmp*` avrebbe
riportato "cancellati N file" lasciandone indietro decine, e l'utente non
avrebbe avuto modo di accorgersene se non contando a mano.

## Correzione: paginazione, non un tetto più alto

Alzare il limite avrebbe solo spostato il problema. `sys_readdir` accetta ora
un **indice di partenza** (`esi`), così il chiamante può percorrere l'intera
directory a blocchi. Il tetto per singola chiamata resta — protegge lo stack
del kernel — ma non è più un tetto sul totale.

- kernel: `fat12_readdir_path(..., start)` salta le prime `start` voci valide;
- libc: nuova `listdir_from(path, buf, max, start)`; `listdir()` resta com'era
  (`start = 0`), quindi nessun programma esistente si rompe;
- `ls` e `delete` percorrono a blocchi da 32 fino alla fine.

## Perché `delete` ora lavora in DUE fasi

Prima raccoglie **tutti** i nomi corrispondenti percorrendo la directory, poi
cancella. Non è una complicazione gratuita: **non si può cancellare mentre si
elenca**. La cancellazione marca la entry come libera e `readdir` salta le
entry libere, quindi le voci successive scalerebbero all'indietro rispetto
all'indice di paginazione, e a ogni blocco si perderebbero tanti file quanti
ne sono stati cancellati nel blocco precedente.

Raccogliere prima serve anche alla richiesta di conferma, che così può dire un
numero esatto. Il limite di 256 nomi selezionati resta, ma ora **è dichiarato**:
se viene superato il programma dice di ripetere il comando.

## Secondo problema, emerso solo provando su 80 file: era inutilizzabile

Al primo test con 80 file ne sono stati cancellati **10 in 60 secondi**.
`fat12_delete` chiamava `fat12_sync()` per ogni singolo file — 32 settori
riscritti (18 di FAT + 14 di root) per ogni cancellazione. È la stessa trappola
già corretta in `fat12_write` nella sessione (g), ricomparsa in una funzione
nuova.

Correzione: la sincronizzazione si sposta **all'uscita del processo**
(`sys_exit`). È il punto giusto — un comando finisce e a quel punto tutto il
suo lavoro va su disco in una volta sola — e non costa nulla a chi non ha
modificato niente, perché `fat12_sync()` controlla i flag e i settori sporchi
prima di fare qualsiasi cosa. `ls` non paga alcun costo.

Va **prima** di `proc_exit()`, che non ritorna: lì siamo ancora in un normale
contesto di processo con gli interrupt abilitati, che è ciò che il driver FDC
richiede per le sue attese su `g_ticks` e IRQ6.

> Nota: un processo terminato da un fault non passa da `sys_exit`, quindi le
> sue modifiche possono andare perse. È il comportamento atteso — un programma
> che si schianta non ha garantito nulla.

## Verificato con una directory da 100 file

| Prova | Prima | Dopo |
|---|---|---|
| `ls /big` (100 file) | 64 voci in tutto, senza avviso | **100 file elencati** |
| `delete /big/tmp*` (80 su 100) | 10 cancellati in 60 s | **80 cancellati**, in una sola passata |
| `keep*` (20 file non corrispondenti) | — | **tutti intatti** |

---

# SESSIONE 2026-07-30 (k) — /bin/delete con caratteri jolly

Richiesta: `delete` per cancellare uno o più file, con `?` (un carattere) e `*`
(tutti i caratteri rimanenti). Kernel a **0.112**.

## `fat12_delete` esisteva ma era irraggiungibile — e rotta

Nessuna syscall la esponeva, quindi non era mai stata usata da nulla. Aveva
tre problemi:

1. **Cercava solo nella root** (`fat12_find_in_root`), quindi non poteva
   cancellare nulla dentro una sottodirectory.
2. **Non controllava l'attributo DIRECTORY.** Cancellare una directory con
   questa funzione ne avrebbe liberato il cluster lasciando i file contenuti
   irraggiungibili, con i loro cluster occupati per sempre. Ora ritorna
   `-EISDIR`: per le directory c'è `rmdir`, che verifica che siano vuote.
3. **Non sincronizzava la cache dei settori**: dopo il passaggio a write-back
   la cancellazione sarebbe rimasta in RAM.

Aggiunta `SYS_UNLINK` (10, come su Linux) e l'errno `EISDIR` (21), che mancava.

## L'espansione dei jolly sta nel programma, non nel kernel

Tre posti possibili, uno solo sensato:

- **non nel kernel**: una syscall che cancella "tutto ciò che assomiglia a X" è
  molto più difficile da rendere sicura di una che cancella un nome preciso.
  `sys_unlink` prende un nome e basta;
- **non nella shell**: la shell di EX-OS non fa espansione, e aggiungerla
  cambierebbe il comportamento di *tutti* i comandi;
- **nel programma**, come faceva MS-DOS. Con un vantaggio pratico: `delete` sa
  quali file ha selezionato e può dirlo prima di cancellarli.

### Il matcher ha bisogno di tornare indietro

`*` può assorbire una sequenza di lunghezza qualsiasi, quindi non basta
consumare avidamente: se il resto del modello non si aggancia, bisogna
riprovare facendo assorbire al `*` un carattere in più. Senza backtracking
`*.txt` fallirebbe su `NOTA.TXT` — il `*` si mangerebbe tutto e non
resterebbe nulla per `.txt`.

L'implementazione è iterativa (ricorda l'ultimo `*` e dove riprendere nel
nome): niente ricorsione, niente allocazioni. Il confronto è insensibile al
caso perché FAT12 conserva i nomi in maiuscolo, e chi digita `tmp*` si aspetta
di trovare `TMP1.TXT`.

## Conferma per le cancellazioni di massa

`delete *` su `/bin` renderebbe il sistema inservibile. Il programma chiede
conferma **solo** quando il modello è esattamente `*` e i file sono più di uno,
dicendo quanti sono e da dove:

```
delete: stai per cancellare 4 file da '/temp'. Procedere? (s/n)
```

Un modello mirato come `tmp*` non la chiede: sa già cosa sta facendo. È lo
stesso criterio del `del *.*` di MS-DOS.

Altre scelte: le directory vengono saltate nell'espansione (per quelle c'è
`rmdir`); un nome senza jolly non richiede di elencare la directory, così
funziona anche se questa contiene più voci del limite di lettura; e se il
limite viene raggiunto il programma **lo dice**, invece di far credere di aver
esaminato tutto.

## Verificato

| Comando | Esito |
|---|---|
| `delete /temp/tmp*` | cancella TMP1.TXT, TMP2.TXT, TMPA.LOG; lascia ALTRO.TXT, DATI1.LOG, DATI2.LOG |
| `delete /temp/dati?.log` | cancella DATI1.LOG e DATI2.LOG, non tocca ALTRO.TXT |
| `delete /p/*.txt` | cancella UNO.TXT e DUE.TXT, lascia TRE.DAT e QUATTRO.LOG — **il backtracking funziona** |
| `delete /p/tre.dat` | nome preciso, senza elencare la directory |
| `cd /temp` + `delete *` + `n` | chiede conferma, **annulla**, tutti e 4 i file intatti |
| `cd /temp` + `delete *` + `s` | cancella tutto; la directory resta e diventa vuota |
| `delete /temp` (directory) | `e' una directory — usa rmdir` |
| `delete /nonesiste` | `non esiste` |
| `delete /temp/zzz*` | `nessun file corrisponde` |
| `delete` senza argomenti | stampa l'uso |
| `rmdir /temp` dopo `delete *` | riesce — la catena delete → rmdir funziona |

## Nota sullo strumento di test

`tools/qemu_drive.py` non sapeva digitare `*` e `?`: aggiunti alla mappa dei
tasti (`kp_multiply` e `shift-slash`). Senza, ogni prova dei jolly sarebbe
stata impossibile — e il comando arrivava troncato a `delete /temp/tmp`, che
avrebbe potuto trarre in inganno.

---

# SESSIONE 2026-07-30 (j) — /bin/rmdir

Richiesta: `rmdir` per cancellare una directory vuota; se contiene file non
deve funzionare. Kernel a **0.111**.

`fat12_rmdir()` + `SYS_RMDIR` (40, come su Linux) + wrapper libc + `/bin/rmdir`.
Aggiunti anche gli errno `ENOTDIR` (20) e `ENOTEMPTY` (39), che mancavano.

## Il rifiuto sulle directory non vuote non è una limitazione

È l'unico comportamento sicuro. Senza una cancellazione ricorsiva, i file
rimasti dentro diventerebbero **irraggiungibili** — nessuna funzione saprebbe
più arrivarci — e i loro cluster resterebbero marcati occupati nella FAT per
sempre. Spazio perso in silenzio, recuperabile solo da un controllo del
filesystem che qui non esiste.

`fat12_dir_vuota()` scorre la catena di cluster ignorando `.`, `..` e le entry
cancellate (`0xE5`), e si ferma al primo `0x00` — che nella convenzione FAT
significa "da qui in poi non c'è più nulla". Nota: `0xE5` va **saltato** ma non
interrompe la scansione, perché dopo una entry cancellata possono esserci
ancora file vivi.

## Ordine delle operazioni, che conta

Prima si liberano i cluster, poi si marca la entry come cancellata. Se il
sistema si fermasse a metà:

- con questo ordine resta un cluster libero con una entry ancora viva →
  recuperabile;
- con l'ordine opposto resterebbe una entry cancellata e i cluster ancora
  occupati → spazio perso senza modo di ritrovarlo.

Come `mkdir`, sincronizza subito: con la cache write-back una cancellazione
solo in RAM verrebbe annullata a metà da uno spegnimento improvviso.

La root è protetta esplicitamente (`rmdir /` rifiutato), e si rifiuta di
cancellare qualcosa che non sia una directory — `rmdir` su un file sarebbe una
sorpresa sgradevole.

## Verificato

| Caso | Esito |
|---|---|
| `mkdir /vuota` poi `rmdir /vuota` | cancellata; sparita anche dall'host |
| `rmdir /piena` (contiene un file) | **rifiutato**; directory e file intatti, verificati dall'host |
| `rmdir /kernel.bin` (un file) | `non e' una directory`; KERNEL.BIN intatto, 82212 byte |
| `rmdir /nonesiste` | `non esiste` |
| `rmdir /` | rifiutato, radice protetta |
| `rmdir` senza argomenti | stampa l'uso |
| `rmdir rel` (percorso relativo) | funziona |
| `mkdir` → `rmdir` → `mkdir` | lo spazio liberato viene riusato |
| riavvio dopo i tentativi falliti | sistema integro, versione corretta |

Il test più importante è il terzo: un tentativo fallito **non deve danneggiare
nulla**. KERNEL.BIN è ancora lì con la dimensione giusta e il sistema riavvia.

---

# SESSIONE 2026-07-30 (i) — /bin/mkdir e creazione di directory

Richiesta: un programma `mkdir` che crea una directory. Kernel a **0.110**.

Non esisteva nulla a nessun livello: né `fat12_mkdir`, né una syscall, né il
programma. Aggiunti tutti e tre.

## Cosa serve per creare una directory in FAT12

Una directory è un file come gli altri con l'attributo `DIRECTORY`, e un
contenuto convenzionale: le prime due entry sono `.` (punta a sé stessa) e `..`
(punta al genitore, con **cluster 0 quando il genitore è la root**). Il resto
del cluster va azzerato — un `name[0]` a `0x00` significa "da qui in poi la
directory è vuota", ed è ciò che ferma tutte le scansioni.

`fat12_mkdir()` alloca il cluster, ci scrive `.`/`..`, crea la entry nella root
e **sincronizza subito**. Quest'ultimo punto non è pignoleria: con la cache
write-back introdotta nella sessione (g), una directory con il cluster scritto
ma la entry solo in RAM lascerebbe un cluster occupato e invisibile se il
sistema venisse spento in quel momento.

Su ogni percorso di fallimento il cluster appena allocato viene restituito
(`fat12_free_chain`), altrimenti resterebbe occupato senza appartenere a nulla.

## Limite deliberato: solo directory nella root

Il driver risolve i percorsi a **un solo livello** — `fat12_find_path` cerca la
directory genitore esclusivamente nella root. Creare `/dati/sub` produrrebbe
una entry corretta sul supporto ma **irraggiungibile**: non ci si potrebbe
entrare con `cd`, né aprirci file.

`mkdir` lo rifiuta con un messaggio esplicito invece di creare qualcosa di
inutilizzabile:

```
ex-os:/> mkdir /dati/sub
mkdir: '/dati/sub' — EX-OS supporta directory solo nella root;
       un percorso annidato non sarebbe raggiungibile
```

Chi in futuro estenderà `fat12_find_path` a più livelli toglierà anche questo
controllo — è segnato nel commento della funzione.

## Il programma

`SYS_MKDIR` è il numero 39, come su Linux. Nessun parametro `mode`: FAT12 non
ha permessi. Il programma accetta più nomi in una volta e **traduce l'errno in
una spiegazione** invece di stampare un numero:

| Errore | Messaggio |
|---|---|
| -17 EEXIST | `'X' esiste gia'` |
| -38 ENOSYS | percorso annidato non supportato (sopra) |
| -28 ENOSPC | spazio esaurito (disco o root directory piena) |

Esce con stato diverso da zero se almeno una directory non è stata creata.

## Verificato

| Caso | Esito |
|---|---|
| `mkdir /dati` | creata; `ls` mostra `DATI/`; mtools la vede come `<DIR>` |
| `cd /dati` + `pwd` | funziona, prompt `ex-os:/dati>` |
| `textline nota.txt` dentro `/dati` | file creato **nella directory giusta**, 17 byte, contenuto corretto letto dall'host |
| `ls` dentro `/dati` | mostra `./`, `../`, `NOTA.TXT` |
| `mkdir relativa` (percorso relativo) | creata, grazie a `resolve_path()` della sessione (g) |
| `mkdir /uno /due` | entrambe create |
| `mkdir /dati` già esistente | rifiutato con messaggio |
| `mkdir /dati/sub` | rifiutato con spiegazione |
| `mkdir` senza argomenti | stampa l'uso |
| riavvio | directory e file persistono |

Le directory create dentro EX-OS sono leggibili dall'host con mtools, e il file
scritto dentro `/dati` sopravvive ai riavvii — cioè la struttura su disco è
davvero conforme a FAT12, non solo coerente con sé stessa.

---

# SESSIONE 2026-07-30 (h) — verboseboot: il default era 1 solo sulla carta

Richiesta: `verboseboot` deve valere 1, e se la voce è assente deve comunque
diventare 1. Kernel a **0.109**.

## Cosa era già corretto

Il default `verbose_boot = 1` è impostato in `cfg_load()` **prima** di aprire il
file, quindi sopravvive sia alla voce assente sia a un file mancante o
illeggibile. Il file e il generatore del Makefile scrivono entrambi
`verboseboot=1`.

## Cosa NON lo era

Verificando il caso "valore non valido" ho trovato che il codice non faceva
quello che il suo stesso commento prometteva:

```c
/* Qualunque valore diverso da 0 vale 1: "verboseboot = si"
 * o un refuso danno comunque un boot verboso... */
cfg->verbose_boot = (cfg_atoi(value) != 0) ? 1u : 0u;
```

`cfg_atoi()` si ferma al primo carattere non numerico e ritorna **0**. Quindi
`verboseboot = si`, un valore vuoto o un qualunque errore di battitura
**zittivano** il sistema — l'esatto contrario del comportamento sicuro
dichiarato nel commento. Un utente che sbaglia a scrivere il valore si ritrova
un boot muto senza capire perché.

Ora il valore è considerato zero solo se è **davvero un numero** e quel numero
è zero.

## Verificato, tutti e cinque i casi

| Configurazione | Risultato |
|---|---|
| `verboseboot = 1` | `verbose = 1` ✅ |
| voce **assente** dal file | `verbose = 1` ✅ |
| `verboseboot = si` | `verbose = 1` ✅ |
| `verboseboot =` (vuoto) | `verbose = 1` ✅ |
| `verboseboot = 0` | `verbose = 0` ✅ |

Ogni riga è un boot reale con l'immagine floppy modificata, non una
deduzione dal codice: i primi tre casi non erano mai stati provati, ed è
proprio lì che si nascondeva il difetto.

---

# SESSIONE 2026-07-30 (g) — "premendo l mi dice documento vuoto": sei difetti dietro un sintomo

Segnalazione dell'utente: aprendo `/boot/kernel.cfg` con textline, il comando
`l` risponde "documento vuoto". Kernel da **0.103 a 0.107**.

Il sintomo era reale ma era solo il primo di una catena: modificare un file in
una sottodirectory toccava sei difetti diversi, ognuno dei quali nascondeva il
successivo.

## 1. ⛔ Nessuna syscall risolveva i percorsi relativi

`g_cwd` era impostata da `chdir()` e letta da `getcwd()`. **Nient'altro la
usava**: `open`, `exec`, `spawn` e `readdir` passavano la stringa ricevuta
direttamente a `fat12_*`, che la interpreta sempre a partire dalla root.

Quindi dopo `cd /boot`, `textline kernel.cfg` cercava `/kernel.cfg`, non lo
trovava, e l'editor apriva — correttamente, per la sua semantica — un documento
nuovo e vuoto. Da cui "documento vuoto".

Nuova `resolve_path()`, applicata a open/exec/spawn/readdir/chdir. Gestisce
anche `.` e `..`, perché `cd ..` è la prima cosa che si prova.

**In più**: `chdir()` non verificava nulla — `cd /inesistente` "riusciva" e da
quel momento ogni percorso relativo puntava in un posto che non c'è. Ora
controlla che la destinazione esista e sia una directory.

## 2. ⛔ `root_index` calcolato da un puntatore allo STACK

Per un file **già esistente** nella root, `fat12_open` faceva:

```c
entry = fat12_find_path(path, &path_entry);
if (entry) entry = &path_entry;              /* ← copia sullo stack */
...
uint32_t idx = ((uint8_t *)entry - g_root_dir) / sizeof(Fat12DirEntry);
```

La differenza fra un indirizzo di stack e un array statico dà un indice fuori
scala, che `fat12_write` usava poi per `g_root_dir[indice_assurdo] = entry`:
**una scrittura fuori dai limiti nella memoria del kernel**.

Non era mai emerso perché l'unico percorso esercitato era quello di
*creazione*, che imposta l'indice correttamente. Bastava salvare due volte lo
stesso file per attivarlo.

Ora la entry viene localizzata esplicitamente — indice nella root, oppure
settore e posizione nella sottodirectory — invece di essere dedotta da un
puntatore.

## 3. ⛔ Scrivere in una sottodirectory non lasciava traccia

Due difetti in uno:

- la **creazione** avveniva sempre nella ROOT, ignorando la directory
  richiesta: `/boot/test.txt` creava `TEST.TXT` in root;
- per un file esistente in sottodirectory la entry non veniva **mai**
  riscritta, quindi dimensione e primo cluster restavano quelli vecchi. Il
  codice lo chiamava "limitazione nota".

L'editor diceva "salvato" e il file non esisteva. Aggiunti
`fat12_split_path()`, `fat12_dir_scan()` e `fat12_writeback_entry()`.

## 4. ⛔ `O_TRUNC` non era implementato da nessuno

Definito negli header, ignorato da `fat12_open`. Siccome `fat12_write` si
accoda a `entry->file_size`, salvare su un file esistente **appendeva** il
nuovo contenuto al vecchio: kernel.cfg passava da 79 a 88 righe, con l'inizio
del vecchio contenuto ricomparso in coda.

Truncare significa anche liberare la catena di cluster, altrimenti la FAT
continua a dichiarare occupati cluster che non appartengono più a nessuno.

## 5. 🐢 Salvare richiedeva minuti

Con i difetti precedenti risolti, il salvataggio *funzionava* ma era
inutilizzabile. Due cause, entrambe misurate:

- **`fat12_write` riversava FAT e root directory su disco a ogni chiamata.** Un
  editor salva riga per riga: 79 righe = 158 `write()`, ognuna delle quali
  scriveva 18 settori di FAT (due copie) più 14 di root. Oltre 5000 scritture
  di settore per 3,6KB. Ora il flush avviene in `fat12_close()` e
  `fat12_sync()` — una volta sola, a lavoro finito.
- **La cache dei settori era write-through**, quindi ogni riga toccava
  davvero il floppy. Resa **write-back**, e portata da 4 a 16 slot: scrivere un
  file tocca ciclicamente il settore dati, quello della directory e quelli
  della FAT, e con 4 slot si sfrattavano a vicenda.

Il compromesso del write-back — dati non ancora sul supporto se si toglie
corrente — è accettabile proprio perché esiste la procedura di arresto della
sessione (e) che chiama `fat12_sync()`. Le due cose si tengono.

Misurato: da "24 righe in 25 secondi" a **79 righe salvate ben dentro i 20
secondi di attesa del test**.

## 6. ⛔ Il Makefile non ricompilava al cambiare di un header

Scoperto per caso durante le verifiche: dopo aver incrementato `EXOS_VERSION`
il sistema continuava a mostrare la versione precedente. Nessuna regola
dipendeva dagli header, quindi `version.h` poteva cambiare senza che nulla
venisse ricompilato.

È **la stessa classe di trappola già documentata a luglio per `LIBC_SRC`** —
"un fix sembra non avere effetto". Aggiunti `-MMD -MP` e l'inclusione dei file
`.d` generati: ora ogni `.o` dipende dagli header che include.

## Verifica finale: il caso dell'utente, dall'inizio alla fine

```
ex-os:/> cd /boot
ex-os:/boot> textline kernel.cfg
textline: 'kernel.cfg' caricato, 79 righe
*m14
   14: timer_hz  = 100
   14> timer_hz  = 100
*e
textline: 'kernel.cfg' salvato, 79 righe
```

Confronto del file dall'host prima e dopo: **79 righe entrambi, byte
identici**. E il sistema **riavvia dall'immagine riscritta dall'editor**,
leggendo correttamente la configurazione (`loglevel = 3`, `verbose = 1`,
`modules = kbd`).

## Nota di rischio

Il write-back sposta il momento in cui i dati toccano davvero il floppy. Chi
spegne la macchina senza `halt` o `poweroff` può perdere l'ultimo lavoro. È il
comportamento normale di qualunque sistema con cache in scrittura, ma qui è
nuovo: prima ogni scrittura andava subito sul supporto (al prezzo di essere
inutilizzabile). `fat12_close()` riversa comunque tutto alla chiusura del file,
quindi la finestra reale è stretta.

---

# SESSIONE 2026-07-30 (f) — /bin/textline, e la scoperta che scrivere su disco non aveva mai funzionato

Richiesta: un editor di testo lineare stile edlin (`textline`), con opzioni
`-v`/`-vp`/`-c:`, comandi `h m n d c l lp`, ESC per annullare; e — requisito
sottolineato — **tutte le librerie devono essere dinamiche**.

Kernel a **0.103**, Text Line a **0.001**.

## Riepilogo onesto di cosa è stato consegnato

| Parte | Stato |
|---|---|
| `/bin/textline` completo e funzionante | ✅ fatto e testato |
| Tre bug del kernel che impedivano all'editor di salvare | ✅ trovati e corretti |
| Librerie dinamiche | ❌ **non implementato** — fattibilità validata, piano concreto in fondo |

## Il muro: scrivere un file non aveva MAI funzionato

`textline` è il primo programma di EX-OS che scrive su disco. Appena ha
provato a salvare sono emersi **tre difetti indipendenti**, tutti nella stessa
condizione: codice mai esercitato da nessuno.

### 1. ⛔ Il comando FDC di scrittura chiedeva un'intera traccia

`fat12_write_sector` inviava `0xC5` con `EOT = SECTORS_PER_TRACK`. Il bit 7 di
0xC5 è **MT (Multi-Track)** e EOT=18 significa "scrivi da questo settore fino
al 18° della traccia, poi passa all'altra testina": il controller si aspettava
decine di migliaia di byte, il ciclo gliene mandava 512. Restava in fase di
esecuzione (`MSR=0xb0`) e la fase di risultato non arrivava mai.

Il commento nel codice diceva già `MT=0` — era il valore a non corrispondere.
La lettura era corretta (`0x46`, MT=0, EOT=sec) perché era l'unica esercitata.

### 2. ⛔ QEMU non completa le scritture non-DMA — misurato, non supposto

Corretto il comando, la scrittura è passata da `MSR=0xb0` a `MSR=0x30` e
comunque non finiva. Invece di continuare a ipotizzare ho **misurato quanti
byte il controller accetta davvero**, con un ciclo strumentato:

```
DIAG: byte accettati=512 MSR finale=0x30
```

Esattamente 512, poi `RQM=0, EXM=1, CMD BSY=1` per sempre — nessuna fase di
risultato. E i dati **arrivavano sul disco**: confrontando l'immagine floppy
prima e dopo, il settore 379 passava da tutti zeri a `ZZZTEST12345`. QEMU
scrive il settore ma non conclude il comando; `-d guest_errors` non registra
nulla.

Escluse per esperimento: il filesystem host (provato anche su `/tmp`), lo stato
degli interrupt (provato con IF=1 durante l'attesa).

**Correzione: passaggio al DMA (canale 2)** per lettura e scrittura. È la strada
corretta a prescindere, e risolve tre problemi in uno:

- il trasferimento non passa più dalla CPU, quindi **cade il `cli`** che
  proteggeva il ciclo PIO;
- la fine del comando è segnalata dall'**IRQ6**, che dalla sessione (b) sappiamo
  già attendere con `fdc_wait_irq()`;
- **toglie l'ostacolo principale al driver floppy in ring3**, documentato nella
  sessione (b): senza DMA un processo utente verrebbe preemptato in mezzo al
  trasferimento causando un overrun, e non può fare `cli`. Ora quella strada è
  aperta.

Lettura e scrittura sono state unificate in un solo `fdc_rw_sector()`: prima
erano due copie quasi identiche della stessa sequenza, ed è **il motivo per cui
il baco è sopravvissuto tanto** — la correzione applicata alla lettura non si
era propagata all'altra copia. La fase di risultato ora legge i **sette** byte
previsti, non tre: leggerne meno lasciava il controller a metà risultato, e il
comando successivo falliva con "FDC non in modalita' write".

Il `cli` resta sulla sola fase di **comando**: il controller ha un timeout
interno di ~500 µs fra un byte e il successivo, e un IRQ0 in mezzo ai 9 byte
glielo farebbe abbandonare. La fase di attesa non può averlo — aspettiamo
proprio un interrupt.

### 3. ⛔ `fat12_write` sovrascriveva invece di accodare

Scriveva **sempre dall'inizio dell'ultimo cluster**, ignorando la posizione
raggiunta nel file. Con le quattro `write()` che textline fa per salvare due
righe:

| chiamata | effetto reale |
|---|---|
| `write("prima riga", 10)` | scrive a offset 0 |
| `write("\n", 1)` | scrive a offset 0 — sovrascrive la 'p' |
| `write("seconda riga", 12)` | scrive a offset 0 |
| `write("\n", 1)` | scrive a offset 0 |

Risultato sul disco: `\neconda riga`, con dimensione dichiarata 24 byte —
la `file_size` era l'unica cosa che si accumulava correttamente. È esattamente
ciò che si vedeva.

Ora è un vero append: parte da `entry->file_size`, percorre la catena dei
cluster fino a quello che contiene quella posizione (estendendola quando
serve) e usa read-modify-write sui settori riempiti in parte, azzerando i
cluster appena allocati invece di ereditarne la spazzatura.

**Verificato dall'esterno**: il file scritto da dentro EX-OS, letto dall'host
con `mtype`, è byte-esatto.

## `/bin/textline`

Modello edlin: si opera per numero di riga, non con un cursore. È la scelta
obbligata — il TTY consegna il testo una riga alla volta e non esiste una
modalità raw, quindi un editor a schermo pieno non potrebbe leggere i tasti
mentre vengono premuti.

Tutte le opzioni e i comandi richiesti sono implementati e testati:
`-v`, `-vp`, `-c:file2`, `h/help`, `l`, `lNN`, `lNN,MM`, `lpNN,MM`, `m`, `mNN`,
`n`, `dNN`, `cNN,MM`, ESC.

### Tre decisioni da conoscere

**Righe in un array statico, non allocate.** La `free()` della libc è un no-op
dichiarato (allocatore a bump su `sbrk`): un editor modifica le righe molte
volte e ogni modifica perderebbe per sempre la memoria precedente. 512 righe ×
128 caratteri = 64KB di BSS, costo noto e costante, zero sul floppy.

**ESC si rileva dentro la riga, non come tasto immediato.** Il servizio kbd
consegna la riga solo su Invio, quindi un ESC premuto arriva come byte `0x1B`
insieme al resto: si considera annullata qualunque riga che ne contenga uno. Un
ESC che interrompe all'istante richiederebbe una modalità raw nel protocollo
IPC della tastiera, oggi assente.

**`-vp` chiede INVIO, non "un tasto qualunque"**, per lo stesso motivo.

### Comandi aggiunti rispetto alla specifica

`w` (salva), `e` (salva ed esce), `q` (esce senza salvare, con conferma se ci
sono modifiche). Senza un modo di salvare e uscire l'editor non sarebbe
utilizzabile; i nomi vengono da edlin (E = end, Q = quit).

## Due correzioni di supporto

- **`getchar()` della libc era rotto sul TTY a righe**: faceva `read(0,&c,1)`,
  e il servizio kbd consumava l'INTERA riga per consegnarne un solo carattere.
  `gets()`, che lo chiama in ciclo, restituiva quindi il primo carattere di
  ogni riga digitata e ne buttava il resto. Ora la libc tiene un buffer di riga
  interno: comportamento corretto e una syscall per riga invece che per
  carattere. (textline non lo usa — legge con `read()` diretta — ma qualunque
  altro programma sì.)
- **Il driver kbd non ecoa più i caratteri di controllo**: finiscono
  regolarmente nel buffer di riga, ma non a video, dove la VGA li renderebbe
  come glifi casuali della code page 437. Senza questo, premere ESC in textline
  faceva comparire una freccia.

## ❌ Librerie dinamiche — non implementato, ma la strada è verificata

Questo era un requisito esplicito e **non è stato fatto**: `textline` è linkato
staticamente, come `ls`. Non l'ho lasciato per svista — richiede un dynamic
linker nel kernel, che è un lavoro di dimensioni paragonabili all'editor
stesso, e farlo di fretta su un sistema che ora funziona sarebbe stato
imprudente.

**Quello che ho verificato sperimentalmente**, perché il prossimo passo parta
da fatti e non da ipotesi:

1. Il toolchain produce già il binario giusto. Compilando `textline.c` senza
   `libc.c` e linkandolo contro `libc.so` si ottiene un **ET_EXEC dinamico**
   con tutto il necessario:
   ```
   .rel.plt: 9 × R_386_JUMP_SLOT → printf, write, read, strncpy,
                                    _libc_start, strcmp, strlen, open, close
   PLTGOT 0x8003ff4   JMPREL 0x804832c   DT_NEEDED [libc.so]
   ```
2. **`-soname libc.so` è già stato aggiunto** al Makefile: senza, il `DT_NEEDED`
   conteneva il *percorso* passato a ld (`build/lib/libc.so`) invece del nome, e
   il loader avrebbe cercato un file inesistente.
3. Il kernel ha già il meccanismo per scrivere nello spazio di un altro
   processo: `paging_get_physical(proc->page_directory, vaddr)` più l'identità
   di mapping della memoria bassa — è così che `elf_load` copia i segmenti, ed è
   esattamente ciò che serve per applicare le rilocazioni sulla GOT.
4. `kernel/loader/dynlink.c` esiste (761 righe) con `dl_load_so`,
   `dl_apply_relocations`, `dl_lookup_symbol`, e prende già un `Process *`. È
   però scritto per mappare i moduli nello spazio del **kernel** e ha una cache
   globale delle librerie, che per il per-processo va ripensata.

**Cosa resta da fare**, in ordine:

1. Un linker script per eseguibili dinamici: quello attuale ha
   `/DISCARD/ { *(.rel*) *(.gnu*) }` e butterebbe via proprio le sezioni
   necessarie. Serve anche per compattare il layout — il link di prova produce
   6 segmenti LOAD sparsi fra `0x07fff000` e `0x08049000`.
2. In `elf_load`: individuare `PT_DYNAMIC`, leggere `DT_NEEDED`/`DT_JMPREL`/
   `DT_PLTRELSZ`/`DT_SYMTAB`/`DT_STRTAB`.
3. Caricare `/lib/libc.so` nella page directory del processo a una base fissa
   (es. `0x40000000`) e applicare le sue `R_386_RELATIVE`.
4. Per ogni `R_386_JUMP_SLOT` dell'eseguibile: risolvere il nome nella
   `.dynsym` della libreria e scrivere `base + st_value` nello slot GOT.
5. Convertire `textline` e `ls`, e misurare il guadagno reale di spazio (oggi
   `ls` 10784 byte, `textline` 17216, `sh` 13676 — la libc è duplicata in
   ognuno).

Nota di progetto: la condivisione sarà **di codice sul floppy e di pagine
fisiche**, non di indirizzi — ogni processo ha la propria page directory, quindi
la libreria va mappata in ciascuna. Le pagine fisiche però possono essere le
stesse, ed è lì che sta il risparmio di RAM.

## File toccati

`bin/textline/textline.c` e `.ld` (nuovi), `kernel/fs/fat12.c` (DMA + append),
`lib/libc.c` (getchar), `drivers/kbd/kbd.c` (eco), `Makefile` (regola textline,
soname), `kernel/include/version.h`, `tools/qemu_drive.py` (tasto ESC, args
QEMU extra).

---

# SESSIONE 2026-07-30 (e) — `halt` causava un kernel panic: arresto e spegnimento veri

Segnalazione dell'utente: `halt` mostra un kernel panic. Richiesta: un arresto
pulito, sistema pronto per essere spento, e se possibile lo spegnimento hardware
dopo 3 secondi.

Versione portata a **0.102**.

## La causa, che spiegava anche un secondo comando rotto

```c
static void cmd_halt(void)      /* ← girava in RING3 */
{
    println("Sistema fermato. Spegnere il computer.");
    __asm__ volatile ("cli; hlt");     /* cli e' PRIVILEGIATA */
}
```

`cli` in ring3 solleva **#GP (vettore 13)**. Non essendoci un handler registrato
per quel vettore, l'eccezione finiva nel ramo di default di `isr_handler()` —
che faceva `kpanic()` per qualunque eccezione non gestita. Da cui il panic.

**`reboot` era rotto allo stesso identico modo**: faceva `cli`, `inb $0x64` e
`outb $0x64` in ring3. Il panic arrivava un istante dopo, ma arrivava.

## Tre livelli di correzione

### 1. La causa radice: un'eccezione da ring3 non deve abbattere il kernel

`isr_handler()` faceva panic per QUALUNQUE eccezione senza handler, anche se
generata da un processo utente. Bastava che un programma ring3 eseguisse
un'istruzione privilegiata per far cadere tutto il sistema.

L'equivalente per il #PF era già stato sistemato a giugno con lo stesso
ragionamento (`page_fault_handler`): un processo che sbaglia deve morire da
solo. Ora la protezione è estesa a **tutte** le altre eccezioni — #GP, #UD,
divisione per zero. Il discriminante è `(frame->cs & 3) == 3`: i due bit bassi
del CS salvato sono il CPL al momento dell'eccezione.

Il `kpanic()` resta per le eccezioni originate in ring0, dove indicano un bug
reale del kernel e proseguire sarebbe pericoloso.

**Verificato** con un builtin temporaneo che eseguiva `cli` in ring3:

```
[FAULT] PID 4 'shell': eccezione 13 (#GP General Protection Fault)
        a EIP=0x08001813 err=0x00000000 — processo terminato
```

Il kernel è sopravvissuto. (La shell no, ovviamente: il sistema resta vivo ma
senza console. Un init che la riavvii è lavoro futuro — vedi in fondo.)

### 2. `kernel/arch/x86/power.c` — la sequenza di arresto, dove è legale

`power_off()`, `power_halt()`, `power_reboot()`. Tutte:

1. **sincronizzano il filesystem** (`fat12_sync()`, nuova): FAT, root directory e
   settori in cache marcati dirty. Spegnere senza farlo perderebbe le modifiche e
   lascerebbe il floppy con un filesystem incoerente. Dalla shell non era
   comunque possibile;
2. **fermano lo scheduler** (`sched_stop()`, nuova);
3. agiscono.

`power_off()` aggiunge il conto alla rovescia di 3 secondi richiesto, basato su
`g_ticks` e non su cicli di CPU — stesso motivo per cui i ritardi dell'FDC sono
stati convertiti a giugno: un conteggio a NOP durerebbe "3 secondi" solo sulla
macchina su cui è stato tarato.

> **`sched_stop()` NON maschera IRQ0, di proposito.** Mascherarlo fermerebbe
> `g_ticks`, e tutto ciò che serve ancora — il conto alla rovescia e i delay del
> driver FDC durante la sincronizzazione — è basato proprio su `g_ticks`: si
> bloccherebbe per sempre. È lo stesso errore del deadlock del PIC di luglio, in
> forma diversa. Il tick continua a contare, i context switch no.

### 3. `SYS_REBOOT` (88) e i comandi della shell

Numero preso da Linux, con un comando in `ebx`:
`EXOS_RB_POWEROFF` / `EXOS_RB_RESTART` / `EXOS_RB_HALT`.

| Comando shell | Effetto |
|---|---|
| `halt` | sincronizza, ferma, **non** spegne — resta a schermo "è ora sicuro spegnere" |
| `poweroff` / `shutdown` | sincronizza, 3 secondi, spegne l'hardware |
| `reboot` | sincronizza e riavvia |

## Spegnimento hardware: cosa funziona davvero e cosa no

Non esiste un'istruzione x86 "spegni il computer": lo spegnimento è una funzione
del chipset. Ci sono tre strade, e ne è implementata una sola.

| Strada | Stato | Perché |
|---|---|---|
| Porte note degli emulatori | ✅ implementata | QEMU (`0x604`), Bochs/QEMU legacy (`0xB004`), VirtualBox (`0x4004`); si scrive il comando ACPI di sleep S5 direttamente. Provate in sequenza: scrivere su una porta non implementata è innocuo |
| ACPI vero | ❌ | richiede un parser RSDP → RSDT → FADT → DSDT per trovare PM1a_CNT e i valori SLP_TYP. Lavoro a sé |
| APM (INT 15h) | ❌ | funzionerebbe sull'hardware d'epoca, ma INT 15h è una chiamata in **real mode**: da protected mode servirebbe tornare in real mode o un monitor virtual-8086 |

**Conseguenza da tenere presente: in QEMU/Bochs/VirtualBox la macchina si spegne
davvero; su un Pentium II reale, con ogni probabilità no** — resterà nel loop di
halt con il messaggio "è ora sicuro spegnere". Non è un fallimento silenzioso: il
sistema è comunque in uno stato sicuro, filesystem sincronizzato, scheduler fermo
e interrupt disabilitati. È esattamente ciò che facevano i PC pre-ATX.

## Verificato, guardando se QEMU esce davvero

Non basta leggere il messaggio a schermo: la prova dello spegnimento è che il
processo QEMU termini. Script in `/tmp/exos/power_test.py`.

| Comando | Risultato |
|---|---|
| `poweroff` | **QEMU esce dopo 3,5 s** (3 s di countdown + avvio), exit code 0 |
| `halt` | QEMU **ancora vivo dopo 30 s**, schermo su "è ora sicuro spegnere" — corretto, `halt` non deve spegnere |
| `reboot` | QEMU esce dopo 0,4 s (con `-no-reboot` il reset termina la VM) |

Nessun kernel panic in nessuno dei tre casi. Sincronizzazione del filesystem
riuscita ovunque (`Sincronizzazione filesystem... ok`).

Il fallback triple-fault di `power_reboot()` **non è stato esercitato**: il reset
via 8042 funziona in QEMU. Resta non verificato.

## Lavori che questa sessione ha reso evidenti

- **Nessun init che riavvii la shell.** Se la shell muore — per un fault o per
  `exit` — il sistema resta vivo ma senza console. `init_reaper_task()` raccoglie
  gli zombie ma non fa supervisione. Ora che un'eccezione ring3 non abbatte più
  il kernel, questo è il limite che si nota per primo.
- **`SYS_REBOOT` non ha controlli di accesso**: qualunque processo può spegnere
  il sistema. Non c'è ancora un concetto di utente o privilegio in EX-OS su cui
  basare un controllo — da rivedere quando esisteranno gli UID.
- **ACPI**: servirebbe comunque, non solo per lo spegnimento su hardware reale.

---

# SESSIONE 2026-07-30 (d) — Identità di sistema in una globale, `ver`/`version`, verboseboot

Richiesta dell'utente: una variabile globale del kernel con l'identità del
sistema, mostrata all'avvio e recuperabile dai programmi; comandi `ver`/`version`
nella shell; nuova opzione `verboseboot` in kernel.cfg (default 1) che con 0
sopprime le informazioni durante caricamento ed esecuzione.

## Versione: `EXOS_VERSION` in `kernel/include/version.h`

```
0.101   ← incrementare di 0.001 a OGNI modifica del kernel
```

La versione precedente del progetto era `0.1`, che in questo schema si legge
`0.100`: la numerazione prosegue da lì, e questa sessione porta a `0.101`.

**È una stringa, non un numero, di proposito**: un float non rappresenta 0.001 in
modo esatto e stamparlo richiederebbe aritmetica in virgola mobile, che questo
kernel non ha (nessuna FPU inizializzata, nessun softfloat). L'incremento è
un'operazione manuale e deliberata — chi tocca il kernel aggiorna quella riga.

## La globale

`kernel/version.c` definisce due `const char[]`:

- `g_os_version` — blocco completo su 4 righe (nome, copyright+email, licenza,
  versione+architettura). È ciò che stampa il banner di boot e ciò che
  restituisce `ver`/`version`.
- `g_os_version_short` — riga singola, per il boot silenzioso.

Composte per **concatenazione di letterali a compile time**: niente heap, niente
filesystem, niente formattazione a runtime. È il motivo per cui si possono
stampare nel banner iniziale, dove nulla di tutto ciò esiste ancora.

## Nuove syscall

| N. | Nome | Argomenti | Cosa fa |
|---|---|---|---|
| 184 | `getenv` | key\*, buf\*, size | legge `[env]` **e** le opzioni scalari fuori da `[env]` |
| 185 | `version` | buf\*, size | copia `g_os_version` |

Entrambe copiano in un buffer utente, mai puntatori interni: stessa regola di
`sys_getcwd`/`sys_readdir`. `sys_version` rifiuta i buffer troppo piccoli invece
di troncare — un'identità tagliata a metà frase sarebbe peggio di un errore.

Wrapper in libc: `getconf()`, `osversion()`, `verboseboot()`. Il primo **non** si
chiama `getenv()` di proposito: la firma è diversa da quella standard (il
chiamante fornisce il buffer) e un nome identico con semantica diversa sarebbe
una trappola.

## La trappola in cui sono caduto, e come l'ho chiusa

Al primo giro funzionava tutto ma `ver` diceva `0.101` e `uname` diceva `0.1`:
avevo **ricreato la doppia fonte di verità** eliminata poche ore prima nella
sessione (c). `ver` legge la globale del kernel; `uname` ed `env` leggono
l'ambiente, che veniva da `[env]` di kernel.cfg.

Risoluzione: **la globale è l'autorità, `[env]` è derivato**. `cfg_load()` inietta
`OSNAME`/`OSVER`/`AUTHOR` da `version.h` — sia prima di aprire il file (così ci
sono anche se manca) sia dopo il parsing (così vincono su un eventuale valore
scritto nel file). Quelle tre chiavi sono state tolte da `kernel.cfg`, con il
commento che spiega perché non vanno rimesse.

> Sembra un passo indietro rispetto alla sessione (c), dove avevo reso `OSNAME`
> configurabile. Non lo è: lì il problema era che i valori fossero **hardcoded in
> cinque punti**. Ora la fonte è una sola, e non può essere il file di
> configurazione perché la versione si incrementa a ogni modifica del *kernel* —
> il file vive sul floppy e non viene ricompilato. Restano configurabili PATH,
> HOME, TERM: quelle sono davvero scelte dell'utente.

## verboseboot

Opzione in `[kernel]` (non in `[env]`: è una scelta di sistema, non una variabile
d'ambiente). Default **1**, impostato nei valori di default *prima* di leggere il
file: se kernel.cfg manca o è illeggibile il sistema deve parlare — un boot muto
che nasconde un fallimento è peggio di uno rumoroso. Qualunque valore diverso da
`0` vale 1, così un refuso non zittisce il sistema.

Con `verboseboot = 0` il silenzio richiede **tre** interventi distinti, perché il
rumore ha tre sorgenti diverse:

| Sorgente | Come si zittisce |
|---|---|
| messaggi klog **futuri** (PASSI 14+, e `SYSCALL spawn`/`ELF:` a ogni comando) | `klog_set_level(LOG_WARN)`: informativi e debug spariscono, **avvisi ed errori no** |
| messaggi klog **già stampati** (PASSI 1-13) | non sopprimibili a posteriori → `vga_clear()` |
| `printf` del driver kbd (processo ring3) | **non passa da klog**: è una `write()` di userspace, il filtro del kernel non la vede nemmeno. Gated con `verboseboot()` di libc |

Quel terzo punto è il tipo di dettaglio che sfugge: al primo test la riga
`kbd: servizio 'kbd' pronto ...` era l'unica sopravvissuta al silenzio.

## Garanzia: errori ed eventi inattesi restano visibili

Richiesta esplicita dell'utente, e c'era un buco reale.

Il filtro di livello già lasciava passare WARN ed ERROR, e i messaggi di fault
(`page_fault_handler`) usano `kprintf` diretto, quindi non sono nemmeno
filtrabili. **Ma `vga_clear()` al PASSO 13c cancellava lo schermo**, e con esso
qualunque problema segnalato durante i PASSI 1-13 — proprio la finestra in cui
non si può ancora sapere che l'utente voleva silenzio.

Due garanzie, implementate in `kernel/arch/x86/kprintf.c`:

1. **Un `LOG_ERROR` è stampato SEMPRE**, qualunque sia il livello configurato,
   anche con un `loglevel = 0` esplicito. Il livello regola quanto il sistema è
   loquace, non se può nascondere i propri guasti: un errore invisibile non è un
   sistema silenzioso, è un sistema che mente.

2. **Ogni ERROR/WARN è registrato in un ring** (`PROB_SLOTS = 8` × 120 caratteri,
   ~1KB statico) **mentre viene emesso, anche se il filtro lo sta nascondendo**.
   Il PASSO 13c, dopo aver pulito lo schermo, ripropone il registro sotto
   l'intestazione `Avvio silenzioso: N problema/i durante l'inizializzazione`.

Se i problemi sono più degli slot, la ristampa lo **dichiara**
(`(N problemi precedenti non conservati, vedi console seriale)`) invece di
mostrare una lista troncata in silenzio — che sarebbe esattamente il tipo di
bugia che questo meccanismo esiste per evitare.

### Come è stato implementato senza duplicare il formattatore

Tutte le funzioni di `kprintf.c` scrivevano con `vga_putchar`/`vga_puts` sparsi
in 13 punti. Sono stati incanalati in un unico `kout()`, che devia su un buffer
quando `g_capture` è impostato. `klog()` per un problema formatta **una volta
sola** dentro lo slot del ring e poi stampa quel testo già pronto, invece di
eseguire due volte il formattatore sulla stessa `va_list`.

### Verificato in tre scenari

- **Problema prima della pulizia**: `[WARN] PMM: nessuna mappa E820` (presente a
  ogni boot in QEMU) sopravvive al `vga_clear()` e compare sotto l'intestazione.
- **Problema dopo la pulizia**: con `/dev/kbd.drv` rimosso dall'immagine, i tre
  messaggi del PASSO 14b/14c (`[ERROR] ELF: file non trovato`, driver saltato,
  ripiego sulla tastiera in-kernel) vengono stampati dal vivo, e il sistema resta
  usabile.
- **Ring saturo**: iniettati temporaneamente 11 avvisi al boot. Con 12 problemi
  totali il registro ha mostrato gli 8 più recenti **in ordine cronologico**
  (wraparound del ring corretto) e ha dichiarato i 4 scartati.

**Perché serve `vga_clear()`**: i PASSI 1-13 vengono stampati *prima* che
kernel.cfg sia leggibile — serve FAT12, che parte al PASSO 13. Non c'è modo di
sapere prima che l'utente voleva silenzio. Il nuovo **PASSO 13c** esiste apposta
per questo ed è documentato nel codice, così nessuno prova a "sistemarlo"
spostando la lettura della configurazione più in alto (non si può: dipende da
paginazione, heap, interrupt e filesystem).

La console seriale continua a ricevere tutto anche in modalità silenziosa: il
mirroring in `vga.c` è a monte del filtro di livello. Il debug non si perde.

## Cosa si vede, nelle due modalità

`verboseboot = 1` (default): banner iniziale con l'identità completa, ~140 righe
di log, banner finale, dump dello scheduler.

`verboseboot = 0`: schermo pulito, una riga di identità, prompt. Nient'altro.

```
EX OS 0.101 (Extensible Operating System) - Copyright (C) 2025 Graziano Falcone - GPL 2.0

ex-os:/> ver
EX OS (Extensible Operating System)
Copyright (C) 2025 Graziano Falcone <exagonx@hotmail.com>
Licenza: GPL 2.0 (GNU General Public License)
Versione: 0.101 (x86 32-bit)
ex-os:/> hello
Ciao da /bin/hello!
```

L'identità su una riga resta anche in modalità silenziosa: `verboseboot` spegne la
diagnostica, non l'identità di ciò che si è avviato. Scelta deliberata, dato che
la richiesta era sia "mostrata in avvio" sia "silenzioso".

## Nota per gli script di test

`tools/qemu_drive.py` aspettava il marker `sblocco IRQ0` per capire che la shell
era pronta — ma è un `klog` INFO e **sparisce con verboseboot=0**, quindi lo
script andava in timeout senza digitare nulla. Ora accetta anche il prompt
`ex-os`, presente in entrambe le modalità.

## File toccati

`kernel/include/version.h` e `kernel/version.c` (nuovi), `kernel/fs/cfg.c`,
`kernel/include/cfg.h`, `kernel/kernel_main.c`, `kernel/syscall/syscall.c`,
`kernel/syscall/syscall_impl.c`, `kernel/include/syscall.h`, `lib/libc.c`,
`lib/include/libc.h`, `drivers/kbd/kbd.c`, `bin/sh/shell.c`, `boot/kernel.cfg`,
`Makefile`, `tools/qemu_drive.py`.

---

# SESSIONE 2026-07-30 (c) — La sezione [env] di kernel.cfg era decorativa

Segnalazione dell'utente: il nome del sistema è in `/boot/kernel.cfg` ma non
compare né al boot del kernel né nella shell.

## La diagnosi

`cfg_getenv()` **non aveva un solo chiamante in tutto il progetto**. La sezione
`[env]` veniva letta, memorizzata in `KernelConfig`, perfino stampata nel log di
boot (`env[3]: OSNAME = EX-OS`) — e poi ignorata. Il nome mostrato era hardcoded
in quattro punti indipendenti:

| Punto | Cosa mostrava |
|---|---|
| `print_boot_banner()` in kernel_main.c | `"ExOS Kernel v0.1"` — e si noti: **"ExOS"**, l'unico posto in tutto il progetto a scriverlo così invece di "EX-OS" |
| banner finale in kernel_main.c | `"EX-OS — Extensible Operating System v0.1"` |
| `env_init()` in shell.c | ri-hardcodava `OSNAME`/`OSVER`/`AUTHOR`, cioè una seconda copia degli stessi valori |
| `cmd_uname()` in shell.c | stringhe letterali — non usava nemmeno le variabili che `env_init` aveva appena impostato |

Due copie della stessa verità, destinate a divergere al primo che avesse
modificato `kernel.cfg` aspettandosi un effetto. Che è esattamente quello che è
successo.

## Il vincolo che NON è un bug

`print_boot_banner()` **non può** leggere da `kernel.cfg`, e non è una
dimenticanza: gira come primissima cosa in `kernel_main`, mentre la
configurazione è caricata al PASSO 13b — dopo FAT12 (PASSO 13), che a sua volta
richiede paginazione, heap e interrupt. In quel punto non esiste ancora un
filesystem da cui leggere. La stringa lì resta necessariamente nel codice; è
documentato nel commento sopra la funzione perché nessuno ci ritorni sopra.

Il banner *finale*, in fondo a `kernel_main`, gira invece dopo `cfg_load()` e ora
usa i valori del file.

## Cosa è cambiato

- **Nuova syscall `SYS_GETENV` (184)** — `getenv(key, buf, size)`: legge una
  variabile di `[env]`. Copia in un buffer utente, mai un puntatore interno
  esposto: stessa regola già seguita da `sys_getcwd` e `sys_readdir`.
- **Banner finale del kernel**: nome, versione e autore da `cfg_getenv()`, con
  fallback se il file manca o la sezione è incompleta — il kernel deve avviarsi
  comunque.
- **`env_init()` della shell**: i valori arrivano dal kernel via `SYS_GETENV`.
  La tabella `ENV_INHERITED` elenca le chiavi ereditate con un default accanto,
  usato **solo** se il kernel non ha quella chiave. `SHELL=/bin/sh` resta locale:
  è la shell a sapere cosa sta eseguendo, e `[boot] shell=` nel file ha un altro
  scopo (chi lanciare), non è una variabile d'ambiente.
- **`print_banner()` e `cmd_uname()` della shell**: leggono da `env_get()`.
- **`print_boot_banner()`**: allineato a `EX-OS` (era l'unico "ExOS"), e tolto il
  riferimento a "Fase 1b" ormai vecchio di tre fasi.

## Verificato cambiando davvero il file

Non basta che compili: il punto era che modificare `kernel.cfg` avesse un
effetto. Con `OSNAME = PROVA-OS`, `OSVER = 9.9`, `AUTHOR = Test Autore`:

```
   PROVA-OS — Extensible Operating System v9.9      ← banner kernel
   Copyright (C) 2025 Test Autore
PROVA-OS version 9.9 (x86 32-bit) — ... Test Autore ← uname nella shell
```

Tutti e tre i punti seguono il file. Valori originali poi ripristinati.

## Nota per chi aggiungerà variabili

Aggiungere una chiave a `[env]` in `kernel.cfg` **non** la rende visibile alla
shell da sola: va aggiunta anche a `ENV_INHERITED` in `bin/sh/shell.c`. È una
scelta deliberata — la shell decide cosa ereditare invece di assorbire tutto
ciò che il kernel espone — ma è il tipo di dettaglio che si dimentica.

---

# SESSIONE 2026-07-30 (b) — FDC sincronizzato su IRQ6, e tre bug latenti da hardware reale

Seguito diretto della sessione qui sotto. Nato come "punto 2 della lista"
(sincronizzare l'FDC su IRQ6 invece che a polling), ha scoperto tre difetti che
in QEMU non si vedono e su un drive vero causerebbero letture sbagliate
**senza errore I/O segnalato** — la stessa firma del bug del Pentium II di
giugno.

## Perché non si è partiti invece dal driver floppy in ring3

Era il passo previsto, ed è stato accantonato per una ragione trovata leggendo
il codice: `fat12_read_sector` fa il trasferimento PIO byte-per-byte con
`interrupts_disable()` attorno al loop, e **un processo ring3 non può fare
`cli`**. Verrebbe preempato da IRQ0 in mezzo al settore.

In QEMU passerebbe (FDC emulato, nessun timing reale). Su hardware vero no: a
500 kbit/s il FIFO va servito entro microsecondi, un tick da 10 ms è tre ordini
di grandezza oltre il margine, e il risultato è un **overrun** (ST1 bit 4).
Sarebbe stato esattamente il tipo di bug che questo progetto ha già pagato:
funziona in emulazione, si rompe sul ferro.

Le tre strade possibili sono descritte in fondo. Nessuna è stata imboccata:
IRQ6 in-kernel viene prima perché è prerequisito di tutte e tre e non ha
rischi.

## Bug latenti trovati e corretti

### 1. ⛔ L'attesa dopo RECALIBRATE/SEEK era di 15 ms — troppo pochi per un drive vero

`fdc_recalibrate()` e `fdc_seek()` inviavano il comando, aspettavano
`fdc_delay_ms(15)` e poi leggevano ST0/PCN con SENSE INTERRUPT.

15 ms bastano in emulazione, dove il seek è istantaneo. Su un drive reale un
recalibrate a stroke pieno muove la testina di 80 tracce e richiede **centinaia
di millisecondi**. Passati i 15 ms, SENSE INTERRUPT veniva letto con il seek
ancora in corso: `pcn == 0` falliva, e dopo 3 tentativi (45 ms in tutto, ancora
troppo pochi) `fdc_recalibrate` **usciva in silenzio** lasciando la testina dove
capitava.

**Fix**: attesa vera dell'IRQ6 di fine comando (`fdc_wait_irq`), con timeout
1000 ms per recalibrate e 500 ms per seek. Il timeout non è fatale: logga un
warning e prosegue, invece di appendere il boot su hardware senza controller.

Il controllo di esito è anche più severo di prima: non basta `pcn == 0` (è 0
anche se il comando non è mai partito), si verificano ST0 bit 5 (SE, Seek End) e
bit 4 (EC, Equipment Check).

### 2. ⛔ Il comando READ non muoveva la testina — funzionava solo grazie all'emulatore

`fat12_read_sector` inviava il comando READ con i parametri C/H/S **senza mai
fare un SEEK**. `fdc_seek()` esisteva ma non era chiamata da nessuno (era la
causa del warning `fdc_seek defined but not used`, presente da mesi).

Il comando READ non muove la testina da solo se l'implicit seek non è
abilitato — e non lo è, `CONFIGURE` con EIS non viene mai inviato. Il codice si
affidava quindi, implicitamente, al fatto che QEMU facesse il seek per conto
suo. **Un controller reale legge la traccia su cui la testina si trova
fisicamente**, ignorando il cilindro passato nei parametri: se non
corrispondono, escono i dati di un'altra traccia o un errore di ID address
mark. Il commento sopra `fdc_recalibrate` descriveva già esattamente questo
rischio — ma lo gestiva solo all'init, una volta, non a ogni accesso.

**Fix**: `fdc_seek_if_needed(cyl, head)` prima di ogni comando READ/WRITE,
fuori dalla sezione critica (l'attesa dell'IRQ6 richiede interrupt abilitati).

**Ottimizzazione necessaria, non gratuita**: un SEEK + 15 ms di settle per ogni
settore sarebbe stato un costo enorme. `g_fdc_cyl` ricorda il cilindro corrente
e il seek si fa solo quando cambia davvero: su un floppy 1.44MB un cilindro
contiene 36 settori (18 × 2 testine), quindi una lettura sequenziale sposta la
testina una volta ogni 36 settori. La variabile è invalidata (-1) a ogni reset,
seek fallito o errore di trasferimento: meglio un seek in più che leggere la
traccia sbagliata credendo di sapere dove siamo.

**Misurato, non stimato**: boot fino al prompt **19,7 s** con la cache della
posizione, **20,9 s** disattivandola (`if (0 && ...)`). La differenza di 1,2 s
corrisponde a ~80 settori letti al boot che pagherebbero ciascuno i 15 ms di
settle — conferma sia che i seek vengono davvero emessi, sia che la cache li
elimina quasi tutti.

### 3. ⛔ `fat12_write_sector` non aveva la protezione `cli` che la lettura aveva

Il path di lettura ha `interrupts_disable()` attorno a comando+dati+status, con
un commento che ne spiega la necessità; perfino il flush della cache dirty
*dentro* `fat12_read_sector` ce l'ha. **La scrittura era rimasta indietro.**

Stesso identico ragionamento: se IRQ0 scatta fra due `fdc_send_byte()`, il
controller (timeout interno ~500 µs per il byte di comando successivo)
abbandona il comando; da lì `fdc_wait_ready()` non vede più RQM e i 512 byte del
settore vengono scartati uno per uno **senza che nulla lo segnali**. La
scrittura "riesce" ma sul disco non arriva niente. Non si manifesta durante il
boot (scheduler non ancora attivo), si manifesta appena un processo scrive un
file a sistema avviato.

**Fix**: `cli` attorno alla fase comando+dati+status, più il controllo
dell'esito della status phase prima di usare ST0 (stessa correzione già
applicata a giugno alla lettura: su fallimento ST0 restava non inizializzato).

### 4. Residuo della bonifica di giugno: due loop di NOP sopravvissuti

Il reset del controller in `fat12_init` usava ancora
`for (d = 0; d < 100000; d++) nop;` — due volte. Sono sfuggiti alla bonifica di
giugno che aveva sostituito gli altri tre con `fdc_delay_ms()`. Stesso difetto:
durata dipendente dalla velocità della CPU. Ora sono attese in tempo reale, e
l'uscita dal reset attende il proprio IRQ6.

## Perché IRQ6 NON è usato per READ/WRITE — non è una dimenticanza

Il 82077AA genera IRQ6 in due situazioni molto diverse:

- **fine comando senza fase di risultato** (RECALIBRATE, SEEK, reset):
  l'interrupt è l'*unico* segnale di completamento, e va seguito da SENSE
  INTERRUPT per leggere ST0/PCN e disarmare il controller. Questi sono i casi
  in cui aspettare l'IRQ è corretto ed è ciò che ora facciamo.
- **fase di esecuzione di READ/WRITE in PIO** (SPECIFY con NDMA=1, come qui):
  il controller alza INT a **ogni byte pronto**, non a fine comando.
  Aspettare "l'IRQ6" lì non significherebbe "settore trasferito" ma "c'è un
  byte" — inutile, dato che lo stesso segnale è già leggibile da MSR/RQM, che è
  quello che il loop di trasferimento fa.

Per READ/WRITE il polling di MSR **è** il modello giusto in PIO. Chi in futuro
volesse "completare il lavoro" sostituendolo con un'attesa di IRQ6 romperebbe
il driver.

## Verificato

Build a **zero warning** (è sparito anche `fdc_seek defined but not used`, che
c'era da mesi). Boot pulito, nessun timeout IRQ6, nessun
`RECALIBRATE non confermato`. Sequenza di comandi (`ls`, `hello`, `cd /bin`,
`ls`, `pid`, `hello`, `cat /boot/kernel.cfg`) tutta corretta, PIC pulito
(`irr=00 imr=bc isr=00`).

**Non verificato su hardware reale** — è il punto centrale: questi tre bug sono
proprio quelli che l'emulazione non mostra. Il valore del lavoro si misura solo
sul Pentium II. Se lì qualcosa non va, i log da guardare sono i nuovi warning
`timeout IRQ6 su ...` e `SEEK non confermato`, che prima non esistevano e che
distinguono un problema di timing da uno di posizionamento.

## Il driver floppy in ring3: le tre strade, per quando si riprenderà

1. **DMA** — elimina il problema alla radice (la CPU non serve il
   trasferimento, la preemption è innocua). Richiede però: `sys_ioport_bind`
   oggi accetta **un solo range contiguo** e servirebbero anche le porte del
   controller DMA (0x00–0x0F, 0x81); più una syscall nuova per ottenere un
   buffer fisicamente contiguo sotto i 16MB di cui il driver conosca
   l'indirizzo **fisico**. È l'architettura corretta e il lavoro più lungo.
2. **PIO + sezione non-preemptible** — flag nel PCB che `sched_irq0_handler`
   controlla per saltare il context switch, con timeout a tick perché un driver
   buggy non appenda il sistema. Strada più corta, ma concede a un processo
   utente di bloccare lo scheduler: compromesso sulla premessa dell'isolamento.
3. **Lasciare il floppy in-kernel.** Legittima: il kernel deve comunque
   conservare FAT12/FDC per il bootstrap (il driver del floppy va letto *dal*
   floppy), quindi la migrazione aggiunge codice invece di toglierne.

Nota già emersa con kbd e ancora valida: il TTY può fare da client IPC perché
`drv_read()` gira **nel contesto del processo che legge**. `elf_load()` no — è
chiamato anche da `kernel_main` al boot, quando `proc_get_current()` è il task
idle. Prima di partire va deciso se il client del servizio floppy sarà il
kernel o un vero VFS in userspace.

---

# SESSIONE 2026-07-30 (a) — Il driver tastiera gira in ring3

Ambiente di test: identico alla sessione precedente (QEMU 8.2.2
`qemu-system-i386`, SeaBIOS 1.16.3, floppy FAT12 1.44MB, `gcc -m32` nativo).

## TL;DR — stato attuale

**`/dev/kbd.drv` è il primo driver di EX-OS che gira davvero in userspace.**
È un processo ring3 con la propria page directory, che non esegue nessuna
istruzione privilegiata: prende gli scancode con `SYS_IOPORT_IN`, riceve gli
IRQ1 come messaggi IPC grazie a `SYS_IRQ_BIND`, e consegna le righe digitate al
TTY del kernel con `SYS_IPC_SEND`. Il "problema aperto" della sessione
precedente — migrazione dei driver a metà, nessun driver caricato al boot — è
chiuso per la tastiera. Il floppy resta in-kernel (vedi in fondo).

Verificato in QEMU: 12 comandi consecutivi (`uname`, `hello`, `ls`, `pid`,
`echo Ciao Mondo`, `cd /bin`, `cat /boot/kernel.cfg`, …), line editing con
Backspace, type-ahead, maiuscole con Shift, PIC pulito a fine sequenza
(`irr=00 imr=bc isr=00`) e CPU nell'idle loop (`HLT=1`).

## L'architettura, in breve

```
    IRQ1 (hardware)
        |
        v
  irq_handler()  isr.c        ← EOI, poi: nessun handler kernel per IRQ1,
        |                       quindi consegna al proprietario ring3
        v
  ipc_notify_irq(pid_kbd)     ← messaggio in mailbox, sblocca il driver
        |
        v
  ============ ring 3 ==============================================
  /dev/kbd.drv  (drivers/kbd/kbd.c)
     ipc_recv()  ←  unico punto di attesa del driver
     ioport_in(0x64/0x60)     ← drena il KBC finché OBF è alto
     traduzione scancode → ASCII, line discipline, Backspace
     write(1, ...)            ← eco a video (passa dal TTY del kernel)
     ipc_send(pid_client, KBD_MSG_LINE, riga)   ← su Invio
  ==================================================================
        |
        v
  drv_read()  drivers/tty/tty.c   ← gira nel contesto della SHELL:
        |                            ipc_send(READLINE) + ipc_recv()
        v
  sys_read(fd=0) → shell
```

Il punto non ovvio: **il TTY in-kernel non fa da intermediario di dati**.
`drv_read()` è chiamata da `sys_read()`, quindi gira già nel contesto del
processo che legge — `proc_get_current()` è la shell. Le `ipc_send`/`ipc_recv`
che esegue operano sulla mailbox della shell, non su una del kernel: il kernel
presta solo il proprio codice. È per questo che non è servito inventare un
meccanismo nuovo per far parlare un processo ring0-less con un driver ring3.

## File toccati

| File | Cosa |
|---|---|
| `drivers/kbd/kbd_proto.h` | **nuovo** — protocollo IPC condiviso fra le due sponde (`KBD_MSG_READLINE`/`KBD_MSG_LINE`, nome servizio, `KBD_LINE_MAX`). Nessuna dipendenza: né header del kernel né libc. |
| `drivers/kbd/kbd.c` | riscritto: da modulo ET_DYN kernel-space a programma ring3 con `main()` e loop di servizio |
| `drivers/kbd/kbd.ld` | da ET_DYN (ORG 0, `.dynsym`/`.rel.*`, `ENTRY(drv_init)`) a ET_EXEC a `0x08000000` con `ENTRY(_start)` — copia dello schema di `bin/ls/ls.ld` |
| `drivers/tty/tty.c`/`.h` | sorgente input selezionabile (`tty_set_input_source`); `drv_read` è un dispatcher fra `tty_read_ipc` e il percorso storico `tty_read_internal` |
| `kernel/kernel_main.c` | PASSO 14c (scelta della sorgente input); driver adottati da init; helper `str_equal` |
| `boot/kernel.cfg` | `modules = kbd`; rimossi `tty` (mai esistito) e `floppy` (ancora ET_DYN) |
| `Makefile` | regola `kbd.drv` statica ET_EXEC (kbd.c + libc.c + start.S); `LIBC_START`; `-I drivers/kbd` nei CFLAGS del kernel |

## Decisioni di progetto e perché

### 1. La line discipline sta nel driver, non nel kernel

Eco a video, Backspace e assemblaggio della riga sono nel driver ring3. Il TTY
del kernel riceve righe già complete. L'alternativa (driver che consegna
caratteri grezzi, kernel che fa l'editing) avrebbe lasciato metà della logica
di terminale in ring0 senza guadagno: il Backspace deve poter modificare
caratteri **non ancora consegnati** al lettore, quindi deve stare dalla stessa
parte del buffer di riga.

L'eco passa da `write(1, ...)`: il driver ha fd 0/1/2 come qualunque processo
(li imposta `proc_create`), e il suo stdout è il TTY del kernel. Non serve
mappargli la memoria VGA.

### 2. Nel driver non esiste più nessun contesto interrupt

Il vecchio `kbd.c` aveva un `kbd_irq1_handler()` che girava in contesto IRQ e
condivideva ring buffer e `g_waiting_pid` con `drv_read()`. Tutte le race di
quel modello (lost wakeup, necessità di `volatile`, sezioni critiche) sono
**strutturalmente assenti** ora: c'è un unico flusso di esecuzione, il loop di
`main()`. Nessuna variabile del file è toccata da due contesti.

### 3. `kbd_drain()` è un loop, non una lettura singola

La notifica IPC dice "c'è lavoro", non "c'è esattamente un byte". Fra l'IRQ e
il momento in cui lo scheduler fa girare il driver passa tempo indefinito, e
`ipc_notify_irq()` **scarta** la notifica se la mailbox è piena (scelta
deliberata, documentata in `kernel/ipc/ipc.c`). Se il driver leggesse un solo
byte per notifica, una notifica persa lascerebbe un byte in `0x60` per sempre:
con OBF alto il KBC non genera più fronti su IRQ1 e la tastiera morirebbe del
tutto. Il loop drena finché OBF è basso, quindi una notifica persa non ha
conseguenze.

Stessa ragione per la drenata subito dopo `irq_bind()`: un tasto premuto fra
`kbd_hw_init()` e il bind lascerebbe OBF alto senza aver prodotto un fronte
utile.

### 4. Ordine di `ioport_bind` / `kbd_hw_init` / `irq_bind`

`irq_bind()` smaschera l'IRQ nel PIC, quindi va **dopo** `kbd_hw_init()`: l'init
genera traffico sul KBC (ACK del self-test, ACK di enable-scan) che non
vogliamo scambiare per input dell'utente.

### 5. I timeout di polling sono ~50x più corti di prima

Nel vecchio driver kernel-space `while (... ) io_delay()` girava 100000 volte:
erano `in`/`out` dirette. Qui **ogni lettura è una syscall**: gli stessi numeri
significherebbero secondi di CPU bruciati. `KBC_POLL_MAX` è 2000, ampiamente
sufficiente (il KBC risponde in decine di microsecondi) e non appende il boot
se il controller è morto.

### 6. Fallback in-kernel conservato — non è codice morto

`tty.c` conserva tabelle scancode, handler IRQ1 e line discipline sotto
`TTY_INPUT_INTERNAL`. Serve in due casi reali:

- `/dev/kbd.drv` assente o non caricabile → `kernel_main` (PASSO 14c) sceglie
  la sorgente interna e il sistema ha comunque una console;
- il driver muore a runtime → `tty_read_ipc()` se ne accorge (`ipc_send`
  ritorna `-ESRCH`, o `ipc_lookup` non trova più il nome) e chiama
  `tty_set_input_source(TTY_INPUT_INTERNAL)` da sé.

Il fallback è stato **testato**, non solo scritto: cancellando `/dev/kbd.drv`
dall'immagine con `mdel` il boot logga `[PASSO 14c] Tastiera: driver ring3
assente` e la shell resta pienamente usabile.

Nel passaggio al fallback il TTY ri-drena `0x60`: il driver morto può aver
lasciato un byte non letto, e senza quella drenata la tastiera sembrerebbe
rotta anche dopo il ripiego.

### 7. Le due strade si escludono a vicenda — attenzione

`irq_handler()` (`kernel/arch/x86/isr.c`) consulta **prima** `irq_handlers[]`
(handler kernel) e solo se è vuoto consegna la notifica IPC al proprietario
ring3. Quindi registrare l'handler IRQ1 interno "per sicurezza" **affama
completamente** il driver ring3: non vedrebbe un solo scancode.

Per questo `drv_init()` (PASSO 14) non registra più nulla e la scelta è
rimandata al PASSO 14c, quando l'esito del caricamento è noto. Se in futuro
qualcuno "ripristina" la `irq_register_handler(1, ...)` dentro `drv_init()`
pensando di renderlo più robusto, romperà la tastiera ring3 in modo
silenzioso.

### 8. I driver sono adottati da init alla creazione

`proc_create` assegna come `ppid` il processo corrente, che al PASSO 14b è il
task **idle**. Idle non muore mai e non chiama mai `waitpid()`, e `proc_exit()`
ri-genitorializza a init solo gli orfani il cui padre è già morto — condizione
che con idle come padre non si verifica mai. Un driver che si schianta
resterebbe quindi ZOMBIE per sempre.

`kernel_main` ora imposta `drv_proc->ppid = g_init_task->pid` subito dopo la
creazione. Non è solo igiene di memoria: `proc_reap_zombie()` chiama
`irq_unbind_process()` e `ipc_cleanup_process()`, quindi senza l'adozione, dopo
un crash del driver **nessun altro processo potrebbe più registrarsi con quel
nome di servizio né rivendicare IRQ1** — il fallback funzionerebbe ma il driver
non sarebbe mai riavviabile.

## Trappole incontrate (non ripercorrere)

- **Lo script di test che manda `\b` letterale.** Stessa identica trappola già
  documentata per `\n` nella sessione precedente: in bash `"lx\bs"` passa
  backslash + `b`, non un backspace. Serve `$'lx\bs'`. Se un test di line
  editing "non cancella niente", controllare prima questo.
- **Il primo boot di prova sembrava bloccato durante `elf_load('/bin/sh')`**:
  era solo il timeout di 15s dello script, troppo corto ora che al boot si
  carica davvero un driver dal floppy (13KB) *prima* della shell. Con 60s
  arriva regolarmente al prompt. Non è una regressione: il caricamento del
  floppy è lento per via dei delay del FDC, non per il driver.
- **`-I drivers/kbd` va nei CFLAGS come riga propria, non in coda con un
  commento `#`**: make tronca la riga al `#`, e in un assegnamento
  multi-riga il risultato è silenziosamente diverso da quello che si legge.

## Limiti noti di questa implementazione

- **Un solo lettore alla volta.** Il driver tiene un unico `g_reader_pid`: una
  richiesta che arriva mentre un'altra è pendente sostituisce la precedente
  (e il vecchio richiedente resta bloccato in `ipc_recv`). Oggi non capita —
  solo il TTY chiede righe, e in modo sincrono per un processo alla volta — ma
  diventerà reale il giorno in cui ci saranno più terminali.
- **`tty_read_ipc` scarta i messaggi che non sono `KBD_MSG_LINE`.** Se un
  giorno qualcuno manderà IPC alla shell per altri motivi, quei messaggi
  verranno persi (con un `[WARN]`). Servirà una vera demultiplazione per tipo.
- **Nessun `ioctl` sul servizio kbd**: modalità raw, flush e controllo LED
  esistevano come `drv_ioctl` nel vecchio driver e non sono state riportate nel
  protocollo IPC (i LED sono gestiti internamente per il CapsLock). Vanno
  aggiunti come nuovi tipi di messaggio quando serviranno.
- **Il claim I/O è un solo range contiguo per processo** (`0x60..0x64` qui): è
  un limite di `sys_ioport_bind`, non del driver.

## Cosa resta della migrazione — il floppy

`drivers/floppy/floppy.c` è ancora un modulo ET_DYN scritto contro i simboli
del kernel, **non è più elencato in `kernel.cfg`** (prima produceva un `[WARN]`
a ogni boot) e l'accesso al floppy resta fatto dal FAT12/FDC interno al kernel.
Viene ancora compilato e copiato sul floppy da `make all`, come promemoria.

Per migrarlo servono gli stessi passi fatti qui, più uno specifico:

1. riscriverlo contro `SYS_IOPORT_*` / `SYS_IRQ_BIND` / `SYS_IPC_*`;
2. `_start` + link ET_EXEC statico (regola Makefile: copiare quella di `kbd.drv`);
3. loop di servizio IPC al posto delle `drv_*`;
4. **bootstrap**: il driver del floppy va letto *dal* floppy. Il kernel deve
   quindi conservare il proprio FAT12/FDC minimo almeno per caricarlo — la
   migrazione del floppy non elimina codice dal kernel, lo affianca.

Nota progettuale emersa lavorando su kbd: il floppy è un caso più difficile
anche perché il TTY in-kernel legge dal servizio kbd *nel contesto del
chiamante*, e lo stesso trucco non si applica a `elf_load()`, che gira nel
contesto di chi fa `spawn` ma è chiamato anche da `kernel_main` al boot, quando
`proc_get_current()` è il task idle. Prima di partire, decidere se il client
del servizio floppy sarà il kernel (come qui) o un vero VFS in userspace.

## Comandi di build/test

```bash
make all

# Boot con log seriale completo:
qemu-system-i386 -drive file=dist/floppy.img,format=raw,if=floppy \
  -m 32M -boot a -display none -serial file:/tmp/serial.txt -no-reboot

# Marker attesi nel log, in ordine:
#   [PASSO 14] TTY OK (output VGA)
#   [PASSO 14b] Driver 'kbd' (/dev/kbd.drv) avviato: PID=3 entry=0x08000000
#   [PASSO 14c] Tastiera: driver ring3 'kbd'
#   SYSCALL ipc_register('kbd') PID=3 -> 0
#   SYSCALL ioport_bind(base=0x60, count=5) PID=3
#   SYSCALL irq_bind(irq=1) PID=3 -> 0
#   kbd: servizio 'kbd' pronto (IRQ1, porte 0x60-0x64, PID 3)

# Test del fallback in-kernel (driver assente):
cp dist/floppy.img /tmp/nokbd.img && mdel -i /tmp/nokbd.img ::/dev/kbd.drv
EXOS_IMG=/tmp/nokbd.img python3 tools/qemu_drive.py "ls" "pid"
# atteso: [PASSO 14c] Tastiera: driver ring3 assente, ripiego sull'handler IRQ1 in-kernel
```

**`tools/qemu_drive.py` è ora versionato** (le sessioni precedenti tenevano
questi script in `/tmp` e li riscrivevano ogni volta). Pilota la tastiera via
monitor QEMU su socket unix, raccoglie la seriale e stampa `info pic` /
`info registers` alla fine:

```bash
python3 tools/qemu_drive.py "uname" "hello" "cd /bin" "ls"

# Type-ahead: "@0" manda il comando dopo senza aspettare il precedente
python3 tools/qemu_drive.py "hello@0" "pid@0" "pwd"

# Line editing: usare $'...' — vedi la trappola dei backslash qui sopra
python3 tools/qemu_drive.py $'lx\bs'
```

Il boot completo fino al prompt richiede **oltre 15 secondi** in QEMU (motore
FDC emulato + due ELF caricati dal floppy): tarare i timeout degli script di
test di conseguenza.

---

# SESSIONE 2026-07-29 — Deadlock PIC: le applicazioni lanciate dalla shell si bloccavano

Ambiente di test: QEMU 8.2.2 (`qemu-system-i386`), SeaBIOS 1.16.3, floppy FAT12
1.44MB (`dist/floppy.img`), build con `make all` (toolchain: `gcc -m32` nativo,
**non** il cross-compiler `i686-elf-*`, che in questo ambiente non è installato —
il Makefile usa già `CC := gcc` con `-m32`).

## TL;DR — stato attuale

Il sistema **funziona end-to-end**: boot → kernel → shell → esecuzione di
programmi esterni (`hello`, `ls`, `cat`) con ritorno al prompt. Testati 12
comandi consecutivi senza blocchi, PID riciclati correttamente, PIC in stato
pulito (`irr=00 isr=00`).

Il sintomo riportato — "le applicazioni eseguite dalla shell si bloccano" — era
un **deadlock del PIC 8259** causato dall'invio dell'EOI *dopo* il context
switch. Dettagli sotto.

## Bug trovati e corretti in questa sessione

### 1. ⛔ DEADLOCK PRINCIPALE — EOI inviato dopo il context switch

**File**: `kernel/arch/x86/isr.c`, funzione `irq_handler()`.

`irq_handler()` inviava `pic_send_eoi(irq)` come **ultima** istruzione, dopo
aver chiamato l'handler registrato. Ma l'handler di IRQ0
(`sched_irq0_handler` in `kernel/sched/sched.c`) può chiamare
`sched_switch_to()` → `context_switch()`, che **cambia lo stack kernel e non
ritorna**: riprende l'esecuzione di un altro processo. La riga
`pic_send_eoi(irq)` restava quindi non eseguita fino a che il processo
preemptato non veniva rischedulato.

Catena esatta del deadlock:

```
IRQ0 (timer) → irq_handler → sched_irq0_handler → sched_switch_to(shell)
             → context_switch  ✗ NON RITORNA → pic_send_eoi(0) MAI ESEGUITO
                                                (PIC: ISR bit 0 = 1, IRQ0 In-Service)
shell riprende → spawn("/bin/hello") → sys_spawn → elf_load
             → fat12_read_sector → fdc_motor_on → fdc_delay_ms(300)
             → `hlt` in attesa che g_ticks avanzi
                ✗ il PIC non consegna più IRQ0 (in-service blocca IRQ0 e
                  tutti gli IRQ di priorità inferiore) → g_ticks non avanza mai
             → SISTEMA CONGELATO
```

**Prova diagnostica** (QEMU monitor, al momento del blocco):

```
pic0: irr=03 imr=bc isr=01     ← isr=01: IRQ0 In-Service, EOI mai inviato
                                  irr=03: IRQ0 e IRQ1 pendenti ma bloccati
EIP=00106781 EFL=00000287 CPL=0 HLT=1   ← dentro fdc_motor_on, IF=1, halted
```

**Fix**: spostare `pic_send_eoi(irq)` **prima** del dispatch dell'handler. È
sicuro perché gli IRQ entrano da interrupt gate (IF=0 per tutta la durata
dell'handler, vedi `irq_common_stub` in `isr_stubs.asm`), quindi non è
possibile un rientro dello stesso IRQ prima dell'`iret` finale.

> **Regola da ricordare**: in questo kernel qualunque handler di interrupt può
> non ritornare (context switch cooperativo via stack switch). Tutto ciò che
> deve accadere "a fine interrupt" va fatto **prima** di chiamare codice che
> possa schedulare.

### 2. `printf()` di libc ignorava flag e larghezza di campo

**File**: `lib/libc.c`.

Non c'era parsing di `-`, `0` e della larghezza. Su `"%-12s"` il `-` finiva nel
ramo `default`, che stampava `%-` **senza consumare l'argomento variadico**;
`12s` veniva stampato come testo e lo specificatore successivo leggeva
l'argomento sbagliato. Sintomo: `ls` stampava letteralmente
`%-12s 3221219808` (il numero era il *puntatore* al nome del file, letto da
`%u` al posto della dimensione).

**Fix**: riscritta `printf()` con flag `-`/`0`, larghezza minima di campo, e
aggiunti `%o` e `%p`. Helper interni `pf_pad()` e `pf_utoa()`.
Ora `ls` stampa correttamente `LOADER.BIN   583` / `KERNEL.BIN   65824`.

### 3. Makefile: `/bin/ls` non veniva mai ricompilato al cambiare di `libc.c`

**File**: `Makefile`.

`LIBC_SRC := lib/libc.c` era definita **dopo** la regola `$(LS_BIN): ... $(LIBC_SRC) ...`
che la usa come prerequisito. Make espande i prerequisiti nel momento in cui
legge la regola, quindi `$(LIBC_SRC)` si espandeva a **stringa vuota**:
`ls` non dipendeva da `libc.c` e sul floppy finiva un binario vecchio.

Questo bug è insidioso perché fa sembrare che un fix a `libc.c` "non abbia
effetto". **Se un fix a libc sembra non applicarsi, controllare prima l'mtime
di `build/bin/ls`.**

**Fix**: definizioni `LIBC_SRC`/`LIBC_SO`/`LIBC_LD` spostate prima della regola
di `$(LS_BIN)`.

### 4. `kprintf("%s", NULL)` causava un #PF nel kernel

**File**: `kernel/arch/x86/kprintf.c`, `print_str()`.

`const char *p = s;` veniva eseguito **prima** di `if (!s) s = "(null)";`,
quindi il loop di conteggio della lunghezza dereferenziava il puntatore nullo.
**Fix**: controllo NULL prima di qualunque dereferenziazione.

### 5. TTY: race "lost wakeup" in `drv_read()`

**File**: `drivers/tty/tty.c`.

La sequenza era, **a interrupt abilitati**:

```c
g_waiting_pid = proc_get_current()->pid;
sched_block(PROC_BLOCKED);
```

Se IRQ1 arrivava nella finestra fra le due istruzioni, l'handler trovava
`g_waiting_pid` già impostato e chiamava `sched_unblock(pid)` su un processo
ancora RUNNING (no-op), azzerando poi `g_waiting_pid`. Subito dopo
`sched_block()` metteva il processo in BLOCKED: la sveglia era già stata
consumata e nessuno l'avrebbe più emessa → **shell bloccata per sempre al
prompt, con la riga già nel ring buffer**.

**Fix**: test-and-block atomico rispetto all'IRQ (`cli`), con ri-controllo del
buffer a interrupt disabilitati. Inoltre `g_input_buf` è ora `volatile`: è
scritto dall'handler IRQ1 e letto in contesto processo, e con `-O2` il
compilatore poteva tenere `count` in un registro attraverso il loop di attesa.

### 6. Leak: PCB, page directory e stack kernel dei driver non caricati

**File**: `kernel/kernel_main.c` (PASSO 14b e PASSO 15).

Su fallimento di `elf_load()` il codice chiamava solo `proc_kill()`, che porta
il processo a ZOMBIE. Nessuno poteva poi raccoglierlo: `init_reaper_task()`
raccoglie **esclusivamente** gli zombie con `ppid == PID di init`, mentre questi
hanno come `ppid` il task che girava durante il boot (idle), che non chiama mai
`waitpid()`. Ogni driver mancante lasciava così per sempre uno slot del pool
PCB, una page directory e le pagine dello stack kernel.

**Fix**: `proc_kill()` seguito da `proc_reap_zombie()`. Il reap diretto è sicuro
perché il processo è creato BLOCKED e non è mai stato eseguito, quindi non è
`g_current` (precondizione di `proc_reap_zombie`).

> Nota: **non** è stato modificato `proc_kill()` per ri-genitorializzare a init,
> perché `sys_waitpid()` si ri-blocca in loop: se init raccogliesse lo zombie
> prima del genitore in attesa, quel genitore resterebbe bloccato per sempre.
> Il fix è quindi al chiamante, non in `proc_kill()`.

## Strumentazione di debug aggiunta (da riusare, non rifare)

### Console seriale kernel su COM1

**File**: `kernel/arch/x86/vga.c` — `serial_init()` + `serial_putchar()`,
chiamate da `vga_init()` e da `vga_putchar()`.

Tutto l'output che passa da `vga_putchar` (quindi `kprintf`, `klog`, l'eco della
tastiera e l'output dei processi via `write`) viene specchiato su COM1 a 38400
8N1. **Indispensabile**: lo schermo VGA è 80x25 e i log di boot scorrono via,
mentre il file seriale conserva tutto. Ha una guardia di spin (100000 cicli) per
non bloccare il kernel su hardware senza COM1.

Uso:
```bash
qemu-system-i386 -drive file=dist/floppy.img,format=raw,if=floppy \
  -m 32M -boot a -display none -serial file:/tmp/serial.txt -no-reboot
```

### Script di pilotaggio QEMU

Non versionati (stavano in `/tmp/exos/`), ma banali da ricreare — l'approccio è
quello che conta:

- **Pilotare la tastiera senza display**: QEMU monitor su socket unix
  (`-monitor unix:/tmp/mon.sock,server,nowait`), poi `sendkey <nome>` per ogni
  carattere. Mappare i caratteri non alfanumerici ai nomi QEMU (`spc`, `ret`,
  `slash`, `dot`, `minus`, `shift-<x>` per le maiuscole).
- **Leggere lo stato hardware al momento del blocco**: `info pic` (è così che si
  è vista la firma `isr=01`), `info registers` (EIP + flag HLT), campionando
  l'EIP più volte per distinguere un vero blocco da un idle loop.
- **Vedere lo schermo VGA**: `screendump /tmp/scr.ppm` dal monitor, poi
  conversione PPM→PNG (in questo ambiente non ci sono PIL/ImageMagick/netpbm:
  serve un convertitore PPM→PNG in Python puro con `zlib` + `struct`, ~20 righe).

### Riferimenti di simboli utili

Per risalire da un `EIP` al simbolo: `nm build/kernel.elf | sort` e cercare
l'intervallo. `build/kernel.elf` è l'ELF con simboli, `build/kernel.bin` è il
flat binary che finisce sul floppy.

## Piste escluse / falsi allarmi (non riesplorare)

- **Il PIT non si era fermato**: la prima lettura di `info pic` mostrava
  `irr=00 isr=00` con la CPU in `hlt` e sembrava un PIT morto. Era invece un
  **idle loop normale** (`sched_start`, `EIP=0x1043e1`): il test non aveva
  premuto Invio perché lo script passava `hello\n` come *backslash + n*
  letterali. Attenzione a questo errore quando si scrivono gli script di test.
- **Perdita di caratteri da tastiera**: sembra che il primo carattere del
  comando successivo venga perso (a schermo si legge `s /bin` invece di
  `ls /bin`). **Non è un bug**: è solo l'eco del type-ahead che compare *prima*
  che la shell stampi il prompt. La riga arriva integra — verificato con
  `argc=2` nel log di `spawn` e con l'output corretto del comando.
- **`fdc_delay_ms()` non è la causa del blocco**, è solo dove il blocco si
  manifestava. Il suo `sti`/`hlt`/`cli` è corretto; il problema era a monte, nel
  PIC.

## Problema aperto — driver in ring3: migrazione a metà

> **SUPERATO il 2026-07-30 per la tastiera** — vedi la sessione in cima al
> file. `/dev/kbd.drv` è ora un processo ring3 vero e viene caricato al boot;
> la voce `tty` è stata tolta da `kernel.cfg` (quel driver non è mai esistito
> come file) e anche `floppy`, che continuerebbe a fallire. Resta valida
> l'analisi qui sotto **per il solo driver floppy**, che è ancora ET_DYN e
> ancora servito da codice in-kernel.

**Non è un bug da correggere, è una decisione di progetto da prendere.**

Allo stato attuale i driver **non vengono caricati** e il boot logga:

```
[WARN] [PASSO 14b] Driver 'tty': '/dev/tty.drv' non caricato — saltato
[WARN] [PASSO 14b] Driver 'floppy': '/dev/floppy.drv' non caricato — saltato
```

Il sistema funziona comunque perché TTY e floppy sono serviti da codice
**in-kernel** (vedi sotto). Situazione precisa:

| Cosa | Stato reale |
|---|---|
| `boot/kernel.cfg` | dichiara `modules = tty,floppy` → `/dev/tty.drv`, `/dev/floppy.drv` |
| `/dev/tty.drv` | **non viene mai compilato**: `drivers/tty/tty.c` è linkato *dentro* il kernel (`$(BUILD_KERNEL)/tty.o` in `KERNEL_OBJS`) e usato al PASSO 14 via `drv_init()`. La voce in `kernel.cfg` è quindi obsoleta. |
| `/dev/floppy.drv`, `/dev/kbd.drv` | compilati come **ET_DYN** (`-shared -fPIC`) per `drvmgr.c`/`dynlink.c`, cioè come moduli **kernel-space**. `elf_load()` accetta solo ET_EXEC → rifiutati con `tipo non supportato (type=3)`. |
| `kbd.drv` | è sul floppy ma **non** è elencato in `kernel.cfg` |
| accesso al floppy | fatto dal driver FAT12/FDC **interno al kernel** (`kernel/fs/fat12.c`) |

Il punto chiave: **anche se `elf_load()` accettasse ET_DYN, quei driver non
potrebbero girare in ring3 così come sono scritti.** Usano `port_inb`/`port_outb`
diretti (→ #GP in ring3) e chiamano simboli del kernel per linkage diretto
(`klog`, `irq_register_handler`, `pic_unmask_irq`, `sched_unblock`), risolti da
`drvmgr.c` solo perché vengono mappati nello spazio del kernel.

L'API syscall per i driver ring3 **esiste già** ed è quella giusta da usare:
`SYS_IRQ_BIND` (224), `SYS_IOPORT_BIND` (225), `SYS_IOPORT_IN` (226),
`SYS_IOPORT_OUT` (227), `SYS_IPC_*` (220–223), con `irq_bind_process()` e
`ipc_notify_irq()` già implementati in `kernel/arch/x86/isr.c`.

Per completare la migrazione servirebbe, per ciascun driver:
1. riscriverlo contro l'API syscall (niente `port_*` diretti, niente simboli kernel);
2. aggiungere un `_start` e linkarlo **ET_EXEC** statico (come `/bin/*`, non `-shared`);
3. un loop di servizio IPC (`ipc_register(nome)` + `ipc_recv`) al posto delle
   funzioni `drv_*` chiamate direttamente;
4. decidere il **bootstrap**: il driver del floppy va letto *dal* floppy, quindi
   il kernel deve conservare il proprio FAT12/FDC minimo almeno per caricarlo;
5. allineare `boot/kernel.cfg` (rimuovere `tty` o costruire davvero `tty.drv`,
   aggiungere `kbd`).

Vedi anche il punto 5 di "Da fare" in `KERNEL_CORE_NOTES.md`.

## Comandi di build/test

```bash
make all        # compila tutto e crea dist/floppy.img

# Boot con log seriale completo (il log VGA scorre, la seriale no):
qemu-system-i386 -drive file=dist/floppy.img,format=raw,if=floppy \
  -m 32M -boot a -display none -serial file:/tmp/serial.txt -no-reboot

# Marker seriali del bootloader attesi (prima che il kernel prenda COM1): SFKPJK
```

---

# ARCHIVIO — SESSIONE 2026-06-14 (bootloader) — ✅ RISOLTO

> Il fault `#GP` a `IP=0x707` descritto qui sotto **non si verifica più**: il
> bootloader completa il passaggio a Protected Mode e salta al kernel. I marker
> seriali arrivano fino a `SFKPJK` (inclusi `J` = PM32 e `K` = `kernel_entry`),
> che nella tabella qui sotto erano segnati come "MAI raggiunto".
> Il contenuto è conservato per riferimento storico sulle piste esplorate.

Data: 2026-06-14
Ambiente di test: QEMU 8.2.2 (`qemu-system-i386`), SeaBIOS 1.16.3-debian-1.16.3-2,
floppy FAT12 1.44MB (`dist/floppy.img`), build con `make clean && make stage1
stage2 kernel floppy`.

## TL;DR

Il bootloader ora funziona in modo solido fino alla **fine del codice a 16
bit**: Stage1 carica Stage2, Stage2 trova ed carica `KERNEL.BIN` in RAM,
costruisce la struttura `BootInfo`, copia il kernel a 1MB, prepara la GDT e
imposta `CR0.PE=1`. Il marker seriale risultante è **`SFKP`**.

Il **far jump verso Protected Mode 32-bit fallisce** con un `#GP` (poi
`#DF` → triple fault → reset) **immediatamente dopo** il salto, con queste
caratteristiche costanti, riprodotte con `qemu-system-i386 ... -d int`:

```
v=0d e=0000 i=0 cpl=0 IP=0010:00000707 pc=00000707 SP=0000:00007000 EAX=00000000
v=08 e=0000 i=0 cpl=0 IP=0010:00000707 pc=00000707 SP=0000:00007000 EAX=00000000
```

Questo fault si verifica **identico** (stesso `IP=0x707`, stesso `EAX=0`,
stesso `e=0000`) con **almeno 4 varianti diverse** del codice 32-bit in
`pm32_entry` (vedi sotto), il che fa pensare a un evento **asincrono**
(interrupt/SMI) che interviene proprio nella finestra fra `mov cr0,eax`
(set `PE=1`) e l'esecuzione del codice 32-bit, piuttosto che a un bug nel
nostro codice 32-bit stesso.

## Bug risolti in questa sessione (rispetto allo stato precedente)

1. **BPB malformato in `boot.asm`**: i campi erano scritti come `dw
   512,1,1,2,224,2880,...` (tutti a 16 bit), ma `SectorsPerCluster` e
   `NumberOfFATs` devono essere `db` (8 bit). Questo rendeva il filesystem
   non riconoscibile da `mtools`/`mformat` ("non DOS media") e/o produceva
   un salto iniziale (`jmp short`) verso un offset sbagliato. **Fix**: ogni
   campo del BPB è ora `db`/`dw`/`dd` separato con il tipo corretto (vedi
   `bootloader/stage1/boot.asm`).

2. **Overlap Root Dir / FAT in Stage1**: la versione precedente caricava la
   FAT a `0x9000` (9 settori) e DOPO la root dir a `0x7E00` (14 settori =
   7168 byte = `0x7E00..0x9A00`), che **sovrascrive** `0x9000..0xA200`. La
   FAT risultava corrotta per qualsiasi file con più di un cluster. **Fix**:
   ordine invertito — root dir prima (`0x7E00..0x9A00`), FAT dopo a
   `0xA000..0xB200` (nessun overlap).

3. **Doppio incremento di `BX` nel loop di caricamento multi-cluster**:
   `rsect` usa `pusha`/`popa`, quindi **ripristina BX** al ritorno. Il loop
   principale deve quindi avanzare `BX` di 512 esso stesso dopo ogni
   chiamata — questo era già presente ma in una versione precedente era
   stato rimosso per errore, causando che ogni cluster venisse scritto
   sempre allo stesso indirizzo (`0x500`), sovrascrivendo i cluster
   precedenti. **Fix**: `call rsect` seguito da `add bx, 512` nel loop
   `.lp` di `boot.asm`.

4. **Porte COM1 sbagliate (0xF8 invece di 0x3F8)**: in diversi punti il
   codice usava `out 0xF8, al` ecc. — `out imm8, al` accede alla porta I/O
   **0xF8 = 248 decimale**, non `0x3F8 = 1016`. Le porte COM1
   (`0x3F8-0x3FD`) sono **sempre > 255** e richiedono `mov dx, 0x3FX; out
   dx, al`. **Fix**: applicato ovunque in `boot.asm` e `loader.asm`.

5. **Makefile: Stage2 compilato dai vecchi file C** (`fat12.c`, `loader.c`,
   `print.c`, linkati con `stage2.ld`) producendo un ELF a 32 bit di 5742
   byte, **non eseguibile** in Real Mode 16 bit (il primo byte `0xFA`=`cli`
   veniva eseguito come istruzione 16-bit ma il resto del codice presupponeva
   un ambiente 32-bit con paging/GDT già attivi). **Fix**: nuovo target
   `$(STAGE2_BIN)` nel `Makefile` che assembla `bootloader/stage2/loader.asm`
   direttamente con `nasm -f bin` (flat binary 16-bit, ORG `0x0500`).

6. **`loader.asm` riscritto da zero** (vedi sotto) per essere un loader
   monolitico a 16 bit puro che:
   - cerca `KERNEL.BIN` nella root dir (già in RAM a `0x7E00`);
   - lo carica a `0x10000` via INT 13h, seguendo la catena FAT a `0xA000`;
   - costruisce `BootInfo` a `0xC000` (magic, drive, mem_lower/upper via
     INT 15h/88h, kernel_size);
   - copia il kernel da `0x10000` a `0x100000` **in Real Mode**, usando il
     trucco A20 `ES=0xFFFF, DI=0x0010` → fisico `0xFFFF0+0x10 = 0x100000`
     (`rep movsw`, `CX=0x7200` word ≥ dimensione kernel 57632 byte);
   - scrive la GDT a `0x0A00` (null, data flat `0x08`, code flat `0x10`,
     entrambi `base=0 limit=4GB`, flags `00CF`);
   - `lgdt` + `CR0.PE=1` + far jump a `pm32_entry` con selettore `0x10`.

7. **Bug di allineamento cluster scoperto e fixato**: `loader.asm` (≈550-580
   byte) occupa **2 cluster** (1 cluster = 512 byte su FAT12 1.44MB). Stage1
   carica il cluster 1 a `0x500..0x6FF` e il cluster 2 a `0x700..`. Se
   un'istruzione (in particolare l'inizio di `pm32_entry`, target del far
   jump) **attraversa il confine `0x6FF/0x700`**, il codice letto dalla CPU
   in quella zona risulta **diverso dal contenuto del file** (verificato con
   marker seriali: il codice in cluster 2 produceva byte/comportamento
   inconsistenti quando un'istruzione iniziava nell'ultimo byte del cluster
   1). **Fix**: aggiunto `times 512-($-$$) db 0x90` prima di `[BITS 32]` per
   garantire che `pm32_entry` inizi **esattamente** a file-offset 512 =
   fisico `0x700` (inizio del cluster 2), così nessuna istruzione è spezzata
   tra i due cluster. Questo fix è corretto e va mantenuto, ma **non è
   sufficiente** a risolvere il fault residuo descritto sopra (il fault
   `IP=0x707` si riproduce identico anche con `pm32_entry` correttamente
   allineato).

8. **Marker seriale precoce nel kernel**: aggiunta in
   `kernel/arch/x86/entry.asm`, come primissima istruzione di
   `kernel_entry`, una stampa `'K'` su COM1 (porta 0x3FD/0x3F8, `mov dx,...`)
   per confermare in futuro che il salto a `0x100000` sia avvenuto e il
   kernel sia stato copiato correttamente. **Non ancora raggiunta** perché
   il fault avviene prima.

## Stato attuale dei marker seriali

| Marker | Significato                                            | Stato |
|--------|---------------------------------------------------------|-------|
| `S`    | Stage2 (`loader.asm`) avviato, COM1 ok                  | ✅ OK |
| `F`    | `KERNEL.BIN` trovato in root dir                        | ✅ OK |
| `K`    | Kernel caricato in RAM a `0x10000` (BootInfo costruito) | ✅ OK |
| `P`    | GDT scritta a `0x0A00`, pronto per `lgdt`+`CR0.PE=1`    | ✅ OK |
| `J`    | In PM32, segmenti flat impostati, sto per `jmp 0x100000`| ❌ MAI raggiunto |
| `K` (kernel) | `kernel_entry` raggiunto a `0x100000`             | ❌ MAI raggiunto |

## Il fault residuo: dettagli e ipotesi

Sequenza esatta in `loader.asm` prima del fault:

```asm
.pmloop:
    lgdt [0x0A1E]        ; GDTR: limit=23, base=0x0A00
    mov  eax, cr0
    or   al, 1
    mov  cr0, eax        ; CR0.PE = 1
    db   0x66, 0xEA      ; far jmp dword 0x10:0x00000700
    dd   pm32_entry
    dw   0x10
    jmp  .pmloop
```

`pm32_entry` (allineato a fisico `0x700`):

```asm
[BITS 32]
pm32_entry:
    mov  ax, 0x08
    mov  ds, ax
    mov  es, ax
    mov  fs, ax
    mov  gs, ax
    mov  ss, ax
    mov  esp, 0x9F000
    ; ... marker 'J', poi jmp dword 0x100000
```

**Varianti testate, TUTTE con fault identico `IP=0x707 EAX=0 e=0000`:**

- `pm32_entry` con setup segmenti completo + marker `J` + `jmp 0x100000`
  (versione "di produzione").
- `pm32_entry` ridotto a solo `mov ax,0x08; mov ds/es/fs/gs/ss,ax; mov
  esp,...` seguito da spin-loop (`jmp $`).
- `pm32_entry` con **ri-caricamento esplicito della GDTR** all'inizio,
  usando `db 0x2E` (prefisso CS:) + `0F 01 15` (`lgdt`) + `dd 0x0A1E`,
  PRIMA di toccare i segmenti — ipotesi "SMI resetta GDTR tra `lgdt` e il
  far jump" (annotata in una sessione precedente). **Stesso fault**, stesso
  `IP=0x707`.
- `pm32_entry` ridotto a **solo** `.spin: jmp .spin` (2 byte, `EB FE`): in
  questo caso **non** c'è stato il fault entro 4s (il processo va in
  timeout, cioè la VM resta "viva" — ma questo test aveva `pm32_entry` a
  file-offset 511 = fisico `0x6FF`, quindi l'istruzione `EB FE` era spezzata
  tra i due cluster e il risultato non è probante: la CPU potrebbe
  semplicemente eseguire un loop diverso su byte "garbage" che non causa
  `#GP`).

**Osservazione chiave**: `EAX=0x00000000` al momento del fault, e
`e=0000` (selector index 0, GDT, non-external) è la firma classica di un
**"load SS with null selector → #GP(0)"**. Ma nel nostro codice `AX=0x08`
viene caricato esplicitamente PRIMA di `mov ss,ax`. Il fatto che il fault
sia **indipendente dal contenuto effettivo di `pm32_entry`** (4 varianti
diverse, stesso `IP` e stesso `EAX=0`) suggerisce che **il fault non avviene
nel nostro codice**, ma in un **gestore asincrono** (interrupt o SMI) il cui
codice fisico risiede per coincidenza intorno a `0x700` in questa
combinazione QEMU/SeaBIOS, e che viene attivato proprio nella finestra
critica subito dopo `mov cr0,eax` (PE=1) / durante il far jump.

### Piste da investigare nella prossima sessione

1. **Disabilitare gli interrupt mascherabili E non mascherabili** prima
   della sequenza critica: oltre a `cli` (già presente), provare a
   mascherare il PIC (`out 0x21,0xFF` / `out 0xA1,0xFF`) prima di
   `lgdt`/`CR0.PE=1`, per escludere IRQ hardware (timer) come causa.

2. **SMI (System Management Interrupt)**: NON è mascherabile da `cli` né dal
   PIC. Se il chipset PIIX4 emulato genera un SMI per qualche motivo (es.
   accesso a porte ACPI/PM, o periodicamente), il SMM handler di SeaBIOS
   potrebbe girare a un indirizzo fisico basso e fare assunzioni sullo stato
   del processore che non sono più valide con `CR0.PE=1`. Provare:
   - disabilitare SMI generation via i registri SMI_EN del PIIX4 (porta
     I/O base ACPI, tipicamente `0xB2`/`0xB3` per APMC/APMS, oppure i
     registri PMBASE — da determinare con `qemu -d guest_errors` o
     analizzando `hw/i386/` di QEMU);
   - testare con `-machine pc-i440fx-...` vs `-machine q35` e/o con
     `-no-acpi` per vedere se il fault cambia/scompare;
   - testare con un `-bios` diverso (versione SeaBIOS) per isolare se è
     un bug/comportamento specifico di SeaBIOS 1.16.3.

3. **Confrontare `IP=0x707` con la mappa di memoria di SeaBIOS**: con `-d
   cpu` su una run "pulita" (senza il nostro floppy, solo BIOS), verificare
   cosa c'è normalmente a fisico `0x700-0x720` dopo il boot di SeaBIOS — se
   è codice/dati del BIOS stesso (es. un trampoline SMM), questo confermerebbe
   l'ipotesi del punto 2 e indicherebbe di **spostare tutto il nostro Stage2
   a un indirizzo più alto** (es. `0x8000` invece di `0x500`), lontano da
   eventuali aree riservate al BIOS.

4. **Approccio alternativo più robusto**: spostare Stage2 (e quindi
   `pm32_entry`, GDT, ecc.) in un'area di memoria sicuramente libera e ben
   sopra `0x7C00` (es. caricare Stage2 a `0x00008000` invece di `0x0500`).
   Questo richiede modifiche minime a `boot.asm` (buffer destinazione) e
   `loader.asm` (`[ORG 0x8000]`), ma elimina la possibile interferenza con
   aree basse usate dal BIOS/SMM.

## File modificati in questa sessione

- `bootloader/stage1/boot.asm` — riscritto: BPB corretto, root-dir-prima-FAT,
  `rsect` con `pusha`/`popa` + `add bx,512` nel loop principale, COM1 init
  prima del far jump a Stage2.
- `bootloader/stage2/loader.asm` — **nuovo file**, sostituisce
  `entry.asm`/`fat12.c`/`loader.c`/`print.c` come unico sorgente di Stage2.
  I vecchi file C/asm sono ancora presenti nella directory ma **non sono più
  usati dal Makefile** (possono essere rimossi in futuro).
- `Makefile` — target `stage2`/`$(STAGE2_BIN)` riscritto per usare
  `nasm -f bin bootloader/stage2/loader.asm`.
- `kernel/arch/x86/entry.asm` — aggiunto marker seriale `'K'` come prima
  istruzione di `kernel_entry`.

## Comandi di build/test

```bash
cd exos_fixed
make clean && make stage1 stage2 kernel floppy

qemu-system-i386 -drive file=dist/floppy.img,format=raw,if=floppy \
  -m 32M -boot a -display none -serial file:/tmp/out.txt -no-reboot
cat /tmp/out.txt        # atteso: SFKP

# Per il debug del fault PM32:
qemu-system-i386 -drive file=dist/floppy.img,format=raw,if=floppy \
  -m 32M -boot a -display none -d int -D /tmp/int.log -no-reboot
grep "v=0d\|v=08" /tmp/int.log
```
