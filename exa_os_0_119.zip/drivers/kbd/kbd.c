/* =============================================================================
 * drivers/kbd/kbd.c
 * EX-OS — Extensible Operating System
 *
 * Copyright (C) 2025 Graziano Falcone <exagonx@hotmail.com>
 *
 * SPDX-License-Identifier: GPL-2.0-or-later
 * This file is part of EX-OS, distributed under the GNU GPL v2.
 * See the LICENSE file in the project root for the full license text.
 * =============================================================================
 *
 * Driver tastiera PS/2 di EX-OS (/dev/kbd.drv) — PROCESSO RING3.
 *
 * Primo driver della migrazione a userspace. Fino a luglio 2026 questo
 * file era un modulo ELF ET_DYN mappato nello spazio del KERNEL da
 * drvmgr.c/dynlink.c: usava port_inb/port_outb diretti e chiamava
 * simboli del kernel (klog, irq_register_handler, sched_unblock) per
 * linkage diretto. Girava quindi in ring0 a tutti gli effetti: un suo
 * bug poteva corrompere il kernel.
 *
 * Ora è un normale eseguibile ET_EXEC statico, identico nello schema a
 * /bin/ls (start.S + libc, vedi Makefile), caricato al PASSO 14b di
 * kernel_main come processo ring3 con la propria page directory. Non
 * esegue nessuna istruzione privilegiata: tutto l'hardware passa dal
 * kernel, che fa da mediatore e da guardia.
 *
 *   port_inb/port_outb   ->  ioport_in/ioport_out  (SYS_IOPORT_IN/OUT),
 *                            consentite solo dentro il range dichiarato
 *                            una volta con ioport_bind()
 *   irq_register_handler ->  irq_bind(1) (SYS_IRQ_BIND): da quel momento
 *                            ogni IRQ1 arriva come messaggio IPC nella
 *                            mailbox di questo processo
 *   sched_unblock(pid)   ->  ipc_send() al client in attesa
 *   klog()               ->  printf() su stdout (fd 1 = TTY del kernel)
 *
 * Conseguenza di progetto importante: NON esiste più un "handler IRQ1"
 * che gira in contesto interrupt. C'è un solo flusso di esecuzione — il
 * loop di servizio in main() — che alterna il consumo degli scancode e
 * la risposta ai client. Tutte le race del vecchio modello (buffer
 * condiviso fra handler e contesto processo, lost wakeup, necessità di
 * `volatile`) semplicemente non esistono più: nessuna variabile di
 * questo file è toccata da due contesti diversi.
 *
 * Line discipline: resta qui, non nel kernel. Il driver accumula la riga
 * in g_line, gestisce Backspace, fa l'eco a video con write(1, ...) e
 * consegna la riga al client solo su Invio. È la stessa semantica
 * "cooked" che il TTY in-kernel implementava da solo, spostata di lato
 * senza cambiarla — vedi drivers/tty/tty.c per il perché l'eco e il
 * Backspace vanno gestiti PRIMA della consegna e non dopo.
 * ============================================================================= */

#include "libc.h"
#include "kbd_proto.h"

/* =============================================================================
 * Porte KBC (Keyboard Controller 8042)
 *
 * Range rivendicato con ioport_bind(): 0x60..0x64. Il kernel rifiuta con
 * -EPERM qualunque ioport_in/out fuori da qui, quindi un bug in questo
 * file non può toccare il PIC, il PIT o il floppy.
 * ============================================================================= */
#define KBC_DATA    0x60    /* Data port (R/W) */
#define KBC_STATUS  0x64    /* Status register (R) */
#define KBC_CMD     0x64    /* Command register (W) */
#define KBC_PORT_BASE   KBC_DATA
#define KBC_PORT_COUNT  5   /* 0x60,0x61,0x62,0x63,0x64 */

/* Bit Status Register */
#define KBC_OBF     0x01    /* Output Buffer Full — dato disponibile in 0x60 */
#define KBC_IBF     0x02    /* Input Buffer Full — controller occupato */
#define KBC_AUX     0x20    /* Il byte in 0x60 viene dalla seconda porta (mouse) */

/* Comandi KBC */
#define KBC_CMD_SELF_TEST   0xAA    /* Self test */
#define KBC_CMD_KBD_ENABLE  0xAE    /* Abilita interfaccia tastiera */
#define KBC_CMD_SET_LEDS    0xED    /* Imposta LED (inviato alla tastiera via 0x60) */
#define KBC_CMD_ENABLE_SCAN 0xF4    /* Abilita scansione */

/* IRQ della tastiera PS/2 */
#define KBD_IRQ     1

/* Numero massimo di iterazioni nei poll sullo status register.
 *
 * ATTENZIONE: qui ogni lettura è una syscall (int 0x80), non una `in`
 * da 1 microsecondo. I valori del vecchio driver kernel-space (100000)
 * qui significherebbero secondi di CPU bruciati. 2000 iterazioni sono
 * ampiamente sufficienti: il KBC risponde in decine di microsecondi, e
 * se non risponde affatto è rotto — meglio proseguire con un warning
 * che restare appesi impedendo l'avvio della console. */
#define KBC_POLL_MAX    2000

/* =============================================================================
 * Mappa scancode set 1 → ASCII (US QWERTY)
 * ============================================================================= */
static const unsigned char sc_normal[128] = {
    0,   27,  '1','2','3','4','5','6','7','8',
    '9','0', '-','=','\b','\t','q','w','e','r',
    't', 'y','u','i','o','p','[',']','\n', 0,
    'a', 's','d','f','g','h','j','k','l',';',
    '\'','`', 0, '\\','z','x','c','v','b','n',
    'm', ',','.','/', 0, '*', 0, ' ', 0,  0,
    0,   0,  0,  0,  0,  0,  0,  0,  0,  0,
    0,   0,  0,  0,  0,  0,  '-',0,  0,  0,
    '+', 0,  0,  0,  0,  0,  0,  0,  0,  0,
    0,   0,  0,  0,  0,  0,  0,  0,  0,  0,
    0,   0,  0,  0,  0,  0,  0,  0,  0,  0,
    0,   0,  0,  0,  0,  0,  0,  0,  0,  0,
    0,   0,  0,  0,  0,  0,  0,  0
};

static const unsigned char sc_shift[128] = {
    0,   27,  '!','@','#','$','%','^','&','*',
    '(',')', '_','+','\b','\t','Q','W','E','R',
    'T', 'Y','U','I','O','P','{','}','\n', 0,
    'A', 'S','D','F','G','H','J','K','L',':',
    '"', '~', 0, '|','Z','X','C','V','B','N',
    'M', '<','>','?', 0, '*', 0, ' ', 0,  0,
    0,   0,  0,  0,  0,  0,  0,  0,  0,  0,
    0,   0,  0,  0,  0,  0,  '-',0,  0,  0,
    '+', 0,  0,  0,  0,  0,  0,  0,  0,  0,
    0,   0,  0,  0,  0,  0,  0,  0,  0,  0,
    0,   0,  0,  0,  0,  0,  0,  0,  0,  0,
    0,   0,  0,  0,  0,  0,  0,  0,  0,  0,
    0,   0,  0,  0,  0,  0,  0,  0
};

/* =============================================================================
 * Stato del driver
 *
 * Niente `volatile` e niente sezioni critiche: a differenza del vecchio
 * driver (e del TTY in-kernel) qui non esiste un handler di interrupt.
 * Ogni riga di questo file gira nell'unico thread di main().
 * ============================================================================= */

/* Modificatori */
static unsigned char g_shift = 0;
static unsigned char g_ctrl  = 0;
static unsigned char g_alt   = 0;
static unsigned char g_caps  = 0;
static unsigned char g_e0    = 0;   /* prefisso tasto esteso 0xE0 */
static unsigned char g_leds  = 0;   /* bit0=Scroll, bit1=Num, bit2=Caps */

/* Buffer di riga in costruzione (line discipline "cooked") */
static char     g_line[KBD_LINE_MAX];
static unsigned g_line_len = 0;

/* Ring buffer delle righe già completate ma non ancora richieste da
 * nessuno (type-ahead: l'utente digita mentre il client sta ancora
 * eseguendo il comando precedente). Contiene i byte delle righe, '\n'
 * incluso; g_rlines conta quanti '\n' ci sono, cioè quante righe
 * complete sono disponibili. */
#define KBD_RING_SIZE   1024
static char     g_ring[KBD_RING_SIZE];
static unsigned g_rhead = 0, g_rtail = 0, g_rcount = 0, g_rlines = 0;

/* Client attualmente in attesa di una riga (0 = nessuno) */
static unsigned g_reader_pid = 0;
static unsigned g_reader_max = KBD_LINE_MAX;

/* =============================================================================
 * Eco a video — passa dal TTY del kernel via fd 1, non da accessi
 * diretti alla memoria VGA (che in ring3 non è mappata).
 * ============================================================================= */
static void echo(const char *s, unsigned n)
{
    write(1, s, n);
}

static void echo_char(char c)
{
    echo(&c, 1);
}

/* =============================================================================
 * Ring buffer delle righe complete
 * ============================================================================= */
static void ring_put_line(const char *s, unsigned len)
{
    unsigned i;

    /* O entra tutta la riga (terminatore compreso) o non entra affatto:
     * una riga troncata a metà resterebbe senza '\n' e g_rlines
     * mentirebbe a ring_take_line, che consumerebbe anche la riga
     * successiva credendola la stessa. Meglio perdere la riga in
     * overflow che disallineare il buffer. */
    if (len + 1 > KBD_RING_SIZE - g_rcount) return;

    for (i = 0; i < len; i++) {
        g_ring[g_rtail] = s[i];
        g_rtail = (g_rtail + 1) % KBD_RING_SIZE;
        g_rcount++;
    }
    g_ring[g_rtail] = '\n';
    g_rtail = (g_rtail + 1) % KBD_RING_SIZE;
    g_rcount++;
    g_rlines++;
}

/* Estrae la prossima riga completa. Copia al più 'max' byte in out; i
 * byte eccedenti vengono comunque consumati dal ring (la riga non resta
 * a metà). Ritorna il numero di byte copiati. */
static unsigned ring_take_line(char *out, unsigned max)
{
    unsigned n = 0;

    if (g_rlines == 0) return 0;

    while (g_rcount > 0) {
        char c = g_ring[g_rhead];
        g_rhead = (g_rhead + 1) % KBD_RING_SIZE;
        g_rcount--;
        if (n < max) out[n++] = c;
        if (c == '\n') break;
    }
    g_rlines--;
    return n;
}

/* =============================================================================
 * try_serve_reader — consegna una riga al client in attesa, se ce n'è
 * una pronta. Chiamata sia quando arriva una richiesta (potrebbe esserci
 * già type-ahead in coda) sia quando una riga si completa (il client
 * potrebbe essere già in attesa da prima).
 * ============================================================================= */
static void try_serve_reader(void)
{
    char     out[KBD_LINE_MAX];
    unsigned max = g_reader_max;
    unsigned len;

    if (g_reader_pid == 0 || g_rlines == 0) return;

    if (max > sizeof(out)) max = sizeof(out);
    len = ring_take_line(out, max);

    if (ipc_send(g_reader_pid, KBD_MSG_LINE, out, len) < 0) {
        /* Client sparito fra la richiesta e la risposta (terminato, o
         * ucciso da un fault): la riga è persa, ma il driver resta vivo
         * e pronto per il prossimo. */
        printf("kbd: consegna a PID %u fallita, client sparito\n", g_reader_pid);
    }
    g_reader_pid = 0;
}

/* =============================================================================
 * Attesa che il KBC accetti un comando (Input Buffer vuoto)
 * ============================================================================= */
static void kbc_wait_write(void)
{
    int poll;
    for (poll = 0; poll < KBC_POLL_MAX; poll++) {
        int st = ioport_in(KBC_STATUS);
        if (st < 0 || !(st & KBC_IBF)) return;
    }
}

/* Attende un byte in uscita dal KBC. Ritorna il byte, o -1 su timeout. */
static int kbc_wait_read(void)
{
    int poll;
    for (poll = 0; poll < KBC_POLL_MAX; poll++) {
        int st = ioport_in(KBC_STATUS);
        if (st < 0) return -1;
        if (st & KBC_OBF) return ioport_in(KBC_DATA);
    }
    return -1;
}

/* =============================================================================
 * LED tastiera
 * ============================================================================= */
static void kbd_set_leds(unsigned char leds)
{
    kbc_wait_write();
    ioport_out(KBC_DATA, KBC_CMD_SET_LEDS);
    kbc_wait_write();
    ioport_out(KBC_DATA, leds & 0x07);
    g_leds = leds;
}

/* =============================================================================
 * kbd_process_scancode — traduzione + line discipline
 *
 * Stessa semantica del vecchio handler IRQ1, ma senza contesto
 * interrupt: qui possiamo tranquillamente fare syscall (l'eco è una
 * write) perché siamo in un normale flusso di processo.
 * ============================================================================= */
static void kbd_process_scancode(unsigned char sc)
{
    char ascii;

    /* Prefisso tasto esteso */
    if (sc == 0xE0) {
        g_e0 = 1;
        return;
    }

    /* Key release (bit 7) */
    if (sc & 0x80) {
        unsigned char key = (unsigned char)(sc & 0x7F);
        g_e0 = 0;
        if (key == 0x2A || key == 0x36) g_shift = 0;
        if (key == 0x1D)                g_ctrl  = 0;
        if (key == 0x38)                g_alt   = 0;
        return;
    }

    /* Tasti estesi: consegnati come sequenze ANSI, esattamente come
     * faceva il TTY in-kernel. Non passano dal buffer di riga: un
     * cursore non è testo editabile. */
    if (g_e0) {
        char seq[3];
        g_e0 = 0;
        seq[0] = '\x1B';
        seq[1] = '[';
        switch (sc) {
            case 0x48: seq[2] = 'A'; break;   /* Up */
            case 0x50: seq[2] = 'B'; break;   /* Down */
            case 0x4D: seq[2] = 'C'; break;   /* Right */
            case 0x4B: seq[2] = 'D'; break;   /* Left */
            case 0x47: seq[2] = 'H'; break;   /* Home */
            case 0x4F: seq[2] = 'F'; break;   /* End */
            default:   return;                /* tasto esteso non mappato */
        }
        if (g_line_len + 3 < KBD_LINE_MAX) {
            g_line[g_line_len++] = seq[0];
            g_line[g_line_len++] = seq[1];
            g_line[g_line_len++] = seq[2];
        }
        return;
    }

    /* Modificatori */
    if (sc == 0x2A || sc == 0x36) { g_shift = 1; return; }
    if (sc == 0x1D)               { g_ctrl  = 1; return; }
    if (sc == 0x38)               { g_alt   = 1; return; }
    if (sc == 0x3A) {
        g_caps = (unsigned char)(g_caps ^ 1);
        g_leds = (unsigned char)((g_leds & ~0x04) | (g_caps ? 0x04 : 0));
        kbd_set_leds(g_leds);
        return;
    }

    if (sc >= 128) return;

    ascii = (char)(g_shift ? sc_shift[sc] : sc_normal[sc]);

    /* CapsLock inverte il caso delle sole lettere */
    if (g_caps && ascii >= 'a' && ascii <= 'z') ascii = (char)(ascii - 32);
    else if (g_caps && ascii >= 'A' && ascii <= 'Z') ascii = (char)(ascii + 32);

    /* Ctrl+lettera → codice di controllo */
    if (g_ctrl && ascii >= 'a' && ascii <= 'z') ascii = (char)(ascii - 'a' + 1);
    else if (g_ctrl && ascii >= 'A' && ascii <= 'Z') ascii = (char)(ascii - 'A' + 1);

    if (ascii == 0) return;

    /* Backspace: agisce sul buffer di riga, che è ancora tutto qui — è
     * proprio per questo che la riga non viene consegnata carattere per
     * carattere (vedi il commento sulla line discipline in tty.c). */
    if (ascii == '\b') {
        if (g_line_len > 0) {
            g_line_len--;
            echo("\b \b", 3);
        }
        return;
    }

    if (ascii == '\n' || ascii == '\r') {
        echo_char('\n');
        ring_put_line(g_line, g_line_len);
        g_line_len = 0;
        return;
    }

    /* Eco solo dei caratteri stampabili.
     *
     * I caratteri di controllo (ESC, Ctrl+lettera, ...) finiscono
     * regolarmente nel buffer di riga — un programma che li aspetta deve
     * riceverli — ma NON vengono ecoati: la VGA li renderebbe come glifi
     * casuali della code page 437, sporcando lo schermo. Il caso concreto
     * è ESC, che /bin/textline usa per annullare una riga: senza questo
     * filtro l'utente vedrebbe comparire una freccia al posto di niente.
     * Il tab resta ecoato perché a video ha un effetto sensato. */
    if ((unsigned char)ascii >= 32 || ascii == '\t') {
        echo_char(ascii);
    }

    if (g_line_len < KBD_LINE_MAX - 1) {
        g_line[g_line_len++] = ascii;
    }
    /* Riga piena: il carattere è già stato ecoato ma non viene
     * accumulato. Limite ereditato dal TTY in-kernel, non una
     * regressione di questa migrazione. */
}

/* =============================================================================
 * kbd_drain — svuota l'output buffer del KBC
 *
 * Chiamata a ogni notifica IRQ. È un LOOP, non una singola lettura: fra
 * l'istante in cui il kernel consegna la notifica IPC e quello in cui
 * questo processo viene schedulato passa tempo indefinito, e nel
 * frattempo possono essersi accumulati altri scancode. Il modello IPC
 * garantisce "c'è lavoro da fare", non "c'è esattamente un byte" — se
 * leggessimo un solo byte per notifica, e una notifica venisse scartata
 * perché la mailbox era piena (vedi ipc_notify_irq in kernel/ipc/ipc.c),
 * quel byte resterebbe in 0x60 per sempre: con OBF alto il KBC non
 * genera più fronti su IRQ1 e la tastiera si bloccherebbe del tutto.
 * ============================================================================= */
static void kbd_drain(void)
{
    int guard;

    for (guard = 0; guard < KBD_RING_SIZE; guard++) {
        int st = ioport_in(KBC_STATUS);
        if (st < 0 || !(st & KBC_OBF)) break;

        int data = ioport_in(KBC_DATA);
        if (data < 0) break;

        /* Byte proveniente dalla seconda porta PS/2 (mouse): non è
         * roba nostra, ma va comunque letto — l'abbiamo appena fatto —
         * altrimenti resterebbe a tenere alto OBF. Scartato. */
        if (st & KBC_AUX) continue;

        kbd_process_scancode((unsigned char)data);
    }
}

/* =============================================================================
 * kbd_hw_init — inizializzazione del controller
 * ============================================================================= */
static void kbd_hw_init(void)
{
    int drain;
    int result;

    /* Svuota qualunque byte residuo lasciato dal BIOS */
    for (drain = 0; drain < 32; drain++) {
        int st = ioport_in(KBC_STATUS);
        if (st < 0 || !(st & KBC_OBF)) break;
        ioport_in(KBC_DATA);
    }

    /* Self-test del controller */
    kbc_wait_write();
    ioport_out(KBC_CMD, KBC_CMD_SELF_TEST);
    result = kbc_wait_read();
    if (result != 0x55) {
        printf("kbd: self-test KBC fallito (0x%x), continuo\n", result);
    }

    /* Abilita l'interfaccia tastiera */
    kbc_wait_write();
    ioport_out(KBC_CMD, KBC_CMD_KBD_ENABLE);

    /* Abilita la scansione (comando alla tastiera, non al controller) */
    kbc_wait_write();
    ioport_out(KBC_DATA, KBC_CMD_ENABLE_SCAN);
    result = kbc_wait_read();
    if (result != 0xFA) {
        printf("kbd: ACK enable-scan non ricevuto (0x%x)\n", result);
    }

    kbd_set_leds(0x00);
}

/* =============================================================================
 * main — loop di servizio
 *
 * Un solo punto di attesa per tutto il driver: ipc_recv(). Ci arrivano
 * due cose diverse, distinguibili dal mittente:
 *   - sender_pid == IPC_SENDER_KERNEL (0) e type == IPC_TYPE_IRQ_NOTIFY
 *     → notifica hardware: c'è (probabilmente) roba da leggere in 0x60
 *   - qualunque altro mittente → richiesta di un client
 *
 * argc/argv sono ignorati: kernel_main carica i driver con elf_load
 * diretto, non via sys_spawn, quindi lo stack iniziale non contiene un
 * vero vettore di argomenti.
 * ============================================================================= */
int main(int argc, char **argv)
{
    IpcMessage    meta;
    unsigned char payload[64];
    int           rc;

    (void)argc;
    (void)argv;

    rc = ipc_register(KBD_SERVICE_NAME);
    if (rc < 0) {
        printf("kbd: ipc_register('%s') fallita (%d) — esco\n",
               KBD_SERVICE_NAME, rc);
        return 1;
    }

    rc = ioport_bind(KBC_PORT_BASE, KBC_PORT_COUNT);
    if (rc < 0) {
        printf("kbd: ioport_bind(0x%x,%u) fallita (%d) — esco\n",
               KBC_PORT_BASE, KBC_PORT_COUNT, rc);
        return 1;
    }

    kbd_hw_init();

    /* irq_bind() smaschera l'IRQ nel PIC: da qui in poi gli IRQ1
     * arrivano. Va fatto DOPO kbd_hw_init(), che genera traffico sul
     * KBC (ACK del self-test, ACK di enable-scan) che non vogliamo
     * scambiare per input dell'utente. */
    rc = irq_bind(KBD_IRQ);
    if (rc < 0) {
        printf("kbd: irq_bind(%u) fallita (%d) — esco\n", KBD_IRQ, rc);
        return 1;
    }

    /* Un tasto premuto fra kbd_hw_init() e irq_bind() lascia OBF alto
     * senza aver prodotto un fronte utile: senza questa drenata iniziale
     * il KBC resterebbe zittito per sempre. */
    kbd_drain();

    /* Messaggio di avvio solo se il boot è verboso: con verboseboot=0
     * questa riga sarebbe l'unica a sfuggire al silenzio, perché non
     * passa da klog() del kernel ma è una write() di un processo ring3 —
     * il filtro di livello del kernel non la vede nemmeno. I messaggi di
     * errore qui sopra restano invece sempre stampati. */
    if (verboseboot()) {
        printf("kbd: servizio '%s' pronto (IRQ%u, porte 0x%x-0x%x, PID %d)\n",
               KBD_SERVICE_NAME, KBD_IRQ, KBC_PORT_BASE,
               KBC_PORT_BASE + KBC_PORT_COUNT - 1, getpid());
    }

    for (;;) {
        if (ipc_recv(&meta, payload, sizeof(payload)) < 0) continue;

        if (meta.sender_pid == IPC_SENDER_KERNEL &&
            meta.type == IPC_TYPE_IRQ_NOTIFY) {
            kbd_drain();
            try_serve_reader();
            continue;
        }

        if (meta.type == KBD_MSG_READLINE) {
            unsigned max = KBD_LINE_MAX;
            if (meta.len >= sizeof(unsigned)) {
                memcpy(&max, payload, sizeof(unsigned));
            }
            if (max == 0 || max > KBD_LINE_MAX) max = KBD_LINE_MAX;

            /* Un solo lettore alla volta: la console è una sola. Se
             * arriva una richiesta mentre un'altra è pendente, la nuova
             * sostituisce la vecchia — il client precedente resterebbe
             * comunque bloccato in ipc_recv, ma è una situazione che
             * oggi non si verifica (solo il TTY del kernel chiede righe,
             * e lo fa in modo sincrono per conto di un processo alla
             * volta). Segnalata perché diventerà reale il giorno in cui
             * ci saranno più terminali. */
            if (g_reader_pid != 0 && g_reader_pid != meta.sender_pid) {
                printf("kbd: richiesta da PID %u sostituisce quella di PID %u\n",
                       meta.sender_pid, g_reader_pid);
            }
            g_reader_pid = meta.sender_pid;
            g_reader_max = max;

            /* Potrebbe esserci già type-ahead pronto: non aspettare un
             * altro tasto per consegnarlo. */
            try_serve_reader();
            continue;
        }

        printf("kbd: messaggio ignoto type=%u da PID %u\n",
               meta.type, meta.sender_pid);
    }

    /* non raggiunto */
}
