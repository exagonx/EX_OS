/* =============================================================================
 * kernel/syscall/syscall_impl.c
 * EX-OS -- Extensible Operating System
 *
 * Copyright (C) 2025 Graziano Falcone <exagonx@hotmail.com>
 *
 * SPDX-License-Identifier: GPL-2.0-or-later
 * This file is part of EX-OS, distributed under the GNU GPL v2.
 * See the LICENSE file in the project root for the full license text.
 * ============================================================================= */

#include "kernel.h"
#include "idt.h"
#include "syscall.h"
#include "sched.h"
#include "pmm.h"
#include "paging.h"
#include "kmalloc.h"
#include "ipc.h"
#include "isr.h"

/* Forward: funzioni VGA per sys_write su fd=1/2 */
extern void vga_puts(const char *s);
extern void vga_putchar(char c);

/* Forward: ELF loader (Fase 3b/4a) */
#include "elf.h"
#include "cfg.h"       /* cfg_getenv: sezione [env] di /boot/kernel.cfg */
#include "version.h"   /* g_os_version: identità del sistema (SYS_VERSION) */
#include "power.h"     /* power_off/reboot/halt (SYS_REBOOT) */
#include "fat12.h"
extern Process g_process_pool[MAX_PROCESSES];

/* Directory di lavoro corrente (globale, semplificazione per ora) */
static char g_cwd[256] = "/";

/* =============================================================================
 * Helper: trova un fd libero nel processo corrente
 * ============================================================================= */
static int find_free_fd(Process *proc)
{
    int i;
    for (i = 0; i < MAX_FD; i++) {
        if (proc->fds[i].type == FD_UNUSED) return i;
    }
    return -1;
}

/* =============================================================================
 * Helper: copia stringa sicura (no libc)
 * ============================================================================= */
static uint32_t kstrlen(const char *s)
{
    uint32_t n = 0;
    while (s && *s++) n++;
    return n;
}

static void kstrcpy(char *dst, const char *src, uint32_t max)
{
    uint32_t i = 0;
    while (i < max - 1 && src[i]) { dst[i] = src[i]; i++; }
    dst[i] = '\0';
}

/* =============================================================================
 * resolve_path — trasforma un percorso relativo in assoluto usando g_cwd
 *
 * BUG CORRETTO (luglio 2026): NESSUNA syscall risolveva i percorsi
 * relativi. g_cwd veniva impostata da chdir() e letta da getcwd(), ma
 * open/stat/exec/spawn passavano la stringa ricevuta direttamente a
 * fat12_*, che la interpreta sempre a partire dalla root.
 *
 * Conseguenza concreta, segnalata dall'utente: dopo `cd /boot`, il
 * comando `textline kernel.cfg` cercava "/kernel.cfg" nella root, non lo
 * trovava, e l'editor apriva un documento nuovo e vuoto. Lo stesso valeva
 * per cat, per l'esecuzione di un programma nella directory corrente e
 * per qualunque altro percorso non assoluto. La shell offre `cd` e `pwd`,
 * quindi era lecito aspettarsi che i percorsi relativi funzionassero.
 *
 * Gestisce anche "." e "..", perché `cd ..` è la prima cosa che si prova.
 * Il ".." risale di un solo livello ed è sufficiente: FAT12 qui supporta
 * un solo livello di sottodirectory (vedi fat12_find_path).
 *
 * Ritorna 0, o <0 se il risultato non entra nel buffer.
 * ============================================================================= */
static int32_t resolve_path(const char *in, char *out, uint32_t max)
{
    uint32_t i = 0, j = 0;

    if (in == NULL || out == NULL || max < 2) return ERR(EINVAL);

    /* Percorso assoluto: si usa così com'è */
    if (in[0] == '/') {
        kstrcpy(out, in, max);
        return 0;
    }

    /* Relativo: parte dalla directory corrente */
    while (g_cwd[j] && i < max - 1) out[i++] = g_cwd[j++];

    /* "." = la directory corrente stessa */
    if (in[0] == '.' && in[1] == '\0') {
        out[i] = '\0';
        return 0;
    }

    /* ".." = risale di un livello, tagliando l'ultima componente */
    if (in[0] == '.' && in[1] == '.' && (in[2] == '\0' || in[2] == '/')) {
        while (i > 1 && out[i - 1] != '/') i--;   /* togli il nome */
        if (i > 1) i--;                            /* togli lo slash */
        out[i] = '\0';
        if (out[0] == '\0') kstrcpy(out, "/", max);

        if (in[2] == '\0') return 0;
        /* "../qualcosa": prosegui con il resto */
        in += 3;
        j = i;
        if (j > 0 && out[j - 1] != '/' && j < max - 1) out[j++] = '/';
        i = j;
        while (*in && i < max - 1) out[i++] = *in++;
        out[i] = '\0';
        return 0;
    }

    /* Aggiungi lo slash separatore solo se non c'è già: con cwd "/" ce
     * l'abbiamo, con "/boot" no. Senza questo controllo si otterrebbe
     * "//kernel.cfg" oppure "/bootkernel.cfg". */
    if (i > 0 && out[i - 1] != '/' && i < max - 1) out[i++] = '/';

    while (*in && i < max - 1) out[i++] = *in++;
    out[i] = '\0';

    if (*in != '\0') return ERR(EINVAL);   /* percorso troppo lungo */
    return 0;
}

/* =============================================================================
 * SYS_EXIT (1) -- Termina il processo corrente
 *
 * ebx = exit_code
 * ============================================================================= */
int32_t sys_exit(InterruptFrame *frame)
{
    int32_t code = (int32_t)frame->ebx;
    klog(LOG_INFO, "SYSCALL exit(%d) PID=%u", code,
         proc_get_current()->pid);

    /* Riversa su disco quello che il processo ha modificato.
     *
     * PERCHÉ QUI (luglio 2026): dopo il passaggio della cache a
     * write-back, le operazioni sul filesystem restano in RAM finché
     * qualcuno non le riversa. Sincronizzare dentro ogni singola
     * operazione (fat12_delete lo faceva) costa 32 settori per file e
     * rende inutilizzabile qualunque comando che ne tocchi molti:
     * /bin/delete con un modello jolly cancellava 10 file in 60 secondi.
     *
     * L'uscita del processo è il punto giusto: un comando qualsiasi
     * finisce, e a quel punto tutto il suo lavoro va su disco in una
     * volta sola. Se non ha modificato nulla, fat12_sync() non fa niente
     * — controlla i flag e i settori sporchi — quindi `ls` non paga
     * alcun costo.
     *
     * Va PRIMA di proc_exit(), che non ritorna e fa il cambio di
     * contesto: qui siamo ancora in un normale contesto di processo con
     * gli interrupt abilitati, che è ciò che il driver FDC richiede per
     * le sue attese su g_ticks e IRQ6.
     *
     * Nota: un processo terminato da un fault non passa di qui, quindi le
     * sue modifiche possono andare perse. È il comportamento atteso — un
     * programma che si schianta non ha garantito nulla. */
    fat12_sync();

    proc_exit(code);
    /* Non ritorna */
    return 0;
}

/* =============================================================================
 * SYS_READ (3) -- Legge da un file descriptor
 *
 * ebx = fd
 * ecx = buf*  (indirizzo buffer utente)
 * edx = count (byte da leggere)
 *
 * Ritorna: byte letti, o errore negativo
 * ============================================================================= */
int32_t sys_read(InterruptFrame *frame)
{
    int32_t   fd    = (int32_t)frame->ebx;
    char     *buf   = (char *)frame->ecx;
    uint32_t  count = frame->edx;
    Process  *proc  = proc_get_current();

    if (fd < 0 || fd >= MAX_FD)                         return ERR(EBADF);
    if (!syscall_verify_ptr(buf, count))                 return ERR(EFAULT);
    if (proc->fds[fd].type == FD_UNUSED)                return ERR(EBADF);

    /* stdin: tastiera, tramite il driver TTY compilato staticamente nel
     * kernel (drivers/tty/tty.c, inizializzato al PASSO 14 con
     * extern drv_init() -- non e' un modulo dinamico nel driver manager,
     * quindi le sue funzioni sono simboli globali del kernel). */
    if (proc->fds[fd].type == FD_STDIN) {
        extern int drv_read(void *buf, size_t n);
        int32_t n = drv_read(buf, count);
        return n;
    }

    /* file FAT12 */
    if (proc->fds[fd].type == FD_FILE) {
        int32_t n = fat12_read((int)proc->fds[fd].inode, buf, count, proc->fds[fd].offset);
        if (n >= 0) proc->fds[fd].offset += (uint32_t)n;
        return n;
    }

    return ERR(EBADF);
}

/* =============================================================================
 * SYS_WRITE (4) -- Scrive su un file descriptor
 *
 * ebx = fd
 * ecx = buf*  (indirizzo buffer utente)
 * edx = count (byte da scrivere)
 *
 * Ritorna: byte scritti, o errore negativo
 * ============================================================================= */
int32_t sys_write(InterruptFrame *frame)
{
    int32_t        fd    = (int32_t)frame->ebx;
    const char    *buf   = (const char *)frame->ecx;
    uint32_t       count = frame->edx;
    Process       *proc  = proc_get_current();
    uint32_t       i;

    if (fd < 0 || fd >= MAX_FD)              return ERR(EBADF);
    if (!syscall_verify_ptr(buf, count))      return ERR(EFAULT);
    if (proc->fds[fd].type == FD_UNUSED)     return ERR(EBADF);

    /* stdout / stderr: scrivi su VGA */
    if (proc->fds[fd].type == FD_STDOUT ||
        proc->fds[fd].type == FD_STDERR) {
        for (i = 0; i < count; i++) {
            vga_putchar(buf[i]);
        }
        return (int32_t)count;
    }

    /* file FAT12 */
    if (proc->fds[fd].type == FD_FILE) {
        int32_t n = fat12_write((int)proc->fds[fd].inode, buf, count);
        if (n >= 0) proc->fds[fd].offset += (uint32_t)n;
        return n;
    }

    return ERR(EBADF);
}

/* =============================================================================
 * SYS_OPEN (5) -- Apre/crea un file
 *
 * ebx = path*  (stringa percorso, null-terminated)
 * ecx = flags  (O_RDONLY, O_WRONLY, O_RDWR, O_CREAT, ...)
 * edx = mode   (permessi, non usati per ora)
 *
 * Ritorna: fd >= 0 successo, errore negativo
 * ============================================================================= */
int32_t sys_open(InterruptFrame *frame)
{
    const char *path  = (const char *)frame->ebx;
    uint32_t    flags = frame->ecx;
    Process    *proc  = proc_get_current();
    int         free_fd;
    int         inode;

    if (!syscall_verify_str(path, 256)) return ERR(EFAULT);

    free_fd = find_free_fd(proc);
    if (free_fd < 0) return ERR(EMFILE);

    /* Risolvi eventuali percorsi relativi contro la directory corrente */
    {
        char abs[256];
        if (resolve_path(path, abs, sizeof(abs)) != 0) return ERR(EINVAL);
        inode = fat12_open(abs, (uint32_t)flags);
    }
    if (inode < 0) return (int32_t)inode;  /* Propaga errore */

    proc->fds[free_fd].type   = FD_FILE;
    proc->fds[free_fd].flags  = flags;
    proc->fds[free_fd].offset = 0;
    proc->fds[free_fd].inode  = (uint32_t)inode;

    klog(LOG_DEBUG, "SYSCALL open('%s') → fd=%d", path, free_fd);
    return free_fd;
}

/* =============================================================================
 * SYS_CLOSE (6) -- Chiude un file descriptor
 *
 * ebx = fd
 * ============================================================================= */
int32_t sys_close(InterruptFrame *frame)
{
    int32_t  fd   = (int32_t)frame->ebx;
    Process *proc = proc_get_current();

    if (fd < 0 || fd >= MAX_FD)          return ERR(EBADF);
    if (proc->fds[fd].type == FD_UNUSED) return ERR(EBADF);
    /* Non chiudere stdin/stdout/stderr */
    if (fd <= 2)                          return ERR(EBADF);

    if (proc->fds[fd].type == FD_FILE) {
        fat12_close((int)proc->fds[fd].inode);
    }

    proc->fds[fd].type        = FD_UNUSED;
    proc->fds[fd].flags       = 0;
    proc->fds[fd].offset      = 0;
    proc->fds[fd].inode       = 0;
    proc->fds[fd].driver_data = NULL;

    return 0;
}

/* proc_reap_zombie e' definita in kernel/sched/sched.c (accede al pool PCB
 * e ai moduli paging/kmalloc); sched.h la dichiara, qui usiamo solo il
 * prototipo gia' incluso via sched.h. */

/* =============================================================================
 * SYS_WAITPID (7) -- Attende terminazione di un processo figlio
 *
 * ebx = pid  (-1 = qualsiasi figlio)
 * ecx = status* (puntatore dove scrivere exit code, può essere NULL)
 * edx = options (non usate per ora)
 *
 * Ritorna: pid del figlio terminato, o errore
 * ============================================================================= */
int32_t sys_waitpid(InterruptFrame *frame)
{
    int32_t   pid_wait = (int32_t)frame->ebx;
    int32_t  *status   = (int32_t *)frame->ecx;
    Process  *current  = proc_get_current();
    uint32_t  i;

    if (status && !syscall_verify_ptr(status, sizeof(int32_t)))
        return ERR(EFAULT);

    /* Cerca un figlio ZOMBIE */
    for (;;) {
        for (i = 0; i < MAX_PROCESSES; i++) {
            Process *p = &g_process_pool[i];
            if (p->state != PROC_ZOMBIE)              continue;
            if (p->ppid  != current->pid)             continue;
            if (pid_wait != -1 && (int32_t)p->pid != pid_wait) continue;

            int32_t  child_exit = p->exit_code;
            uint32_t child_pid  = p->pid;
            if (status) *status = child_exit;

            proc_reap_zombie(p);

            klog(LOG_DEBUG, "SYSCALL waitpid: raccolto PID %u, code=%d",
                 child_pid, child_exit);
            return (int32_t)child_pid;
        }

        /* Nessun figlio zombie: blocca il processo e riprova */
        sched_block(PROC_BLOCKED);
        /* Svegliato da proc_exit di un figlio → riprova */
    }
}

/* Riferimento al pool PCB globale (definito in sched.c) */

/* =============================================================================
 * SYS_GETPID (20) -- Ritorna il PID del processo corrente
 * ============================================================================= */
int32_t sys_getpid(InterruptFrame *frame)
{
    (void)frame;
    return (int32_t)proc_get_current()->pid;
}

/* =============================================================================
 * SYS_GETPPID (64) -- Ritorna il PPID del processo corrente
 * ============================================================================= */
int32_t sys_getppid(InterruptFrame *frame)
{
    (void)frame;
    return (int32_t)proc_get_current()->ppid;
}

/* =============================================================================
 * SYS_MMAP (90) -- Mappa memoria virtuale nel processo
 *
 * ebx = puntatore a struct MmapParams
 *
 * Gestisce:
 *   MAP_ANONYMOUS: alloca pagine fisiche nuove
 *   MAP_FIXED:     mappa a indirizzo esatto richiesto
 *   (MAP_FILE non implementato -- richiede Fase 3)
 *
 * Ritorna: indirizzo virtuale mappato, o errore negativo
 * ============================================================================= */
int32_t sys_mmap(InterruptFrame *frame)
{
    MmapParams *p    = (MmapParams *)frame->ebx;
    Process    *proc = proc_get_current();
    uint32_t    pages;
    uint32_t    vaddr;
    uint32_t    i;
    uint32_t    pg_flags;

    if (!syscall_verify_ptr(p, sizeof(MmapParams))) return ERR(EFAULT);

    if (p->length == 0) return ERR(EINVAL);

    pages = ALIGN_UP(p->length, PAGE_SIZE) / PAGE_SIZE;

    /* Determina indirizzo virtuale */
    if (p->flags & MAP_FIXED) {
        vaddr = p->addr & 0xFFFFF000;
        if (vaddr < USER_SPACE_BASE || vaddr >= USER_SPACE_END)
            return ERR(EINVAL);
    } else {
        /* Alloca nel heap utente (cresce verso l'alto) */
        vaddr = ALIGN_UP(proc->heap_end, PAGE_SIZE);
        if (vaddr < USER_SPACE_BASE) vaddr = USER_SPACE_BASE;
    }

    /* Flag pagine */
    pg_flags = PG_PRESENT | PG_USER;
    if (p->prot & PROT_WRITE) pg_flags |= PG_WRITABLE;

    /* Alloca e mappa le pagine */
    for (i = 0; i < pages; i++) {
        uint32_t phys = pmm_alloc_page();
        if (phys == 0) {
            /* OOM: libera le pagine già allocate */
            uint32_t j;
            for (j = 0; j < i; j++) {
                uint32_t va = vaddr + j * PAGE_SIZE;
                uint32_t pa = paging_get_physical(proc->page_directory, va);
                if (pa) pmm_free_page(pa);
                paging_unmap_page(proc->page_directory, va);
            }
            return ERR(ENOMEM);
        }

        /* Azzera la pagina appena allocata */
        {
            uint8_t *pg = (uint8_t *)phys;
            uint32_t n  = PAGE_SIZE;
            while (n--) *pg++ = 0;
        }

        if (paging_map_page(proc->page_directory,
                             vaddr + i * PAGE_SIZE,
                             phys, pg_flags) != 0) {
            pmm_free_page(phys);
            return ERR(ENOMEM);
        }
    }

    /* Aggiorna heap_end del processo */
    uint32_t mapped_end = vaddr + pages * PAGE_SIZE;
    if (mapped_end > proc->heap_end) proc->heap_end = mapped_end;

    klog(LOG_DEBUG, "SYSCALL mmap: %u pagine a 0x%08x (prot=0x%x)",
         pages, vaddr, p->prot);

    return (int32_t)vaddr;
}

/* =============================================================================
 * SYS_MUNMAP (91) -- Rimuove un mapping
 *
 * ebx = addr
 * ecx = length
 * ============================================================================= */
int32_t sys_munmap(InterruptFrame *frame)
{
    uint32_t  addr   = frame->ebx & 0xFFFFF000;
    uint32_t  length = frame->ecx;
    Process  *proc   = proc_get_current();
    uint32_t  pages  = ALIGN_UP(length, PAGE_SIZE) / PAGE_SIZE;
    uint32_t  i;

    if (addr < USER_SPACE_BASE || addr >= USER_SPACE_END) return ERR(EINVAL);
    if (length == 0) return ERR(EINVAL);

    for (i = 0; i < pages; i++) {
        uint32_t va   = addr + i * PAGE_SIZE;
        uint32_t phys = paging_get_physical(proc->page_directory, va);
        if (phys) pmm_free_page(phys);
        paging_unmap_page(proc->page_directory, va);
    }

    klog(LOG_DEBUG, "SYSCALL munmap: %u pagine da 0x%08x", pages, addr);
    return 0;
}

/* =============================================================================
 * SYS_IOCTL (54) -- Controllo device
 *
 * ebx = fd
 * ecx = request
 * edx = arg
 * ============================================================================= */
int32_t sys_ioctl(InterruptFrame *frame)
{
    int32_t  fd      = (int32_t)frame->ebx;
    uint32_t request = frame->ecx;
    uint32_t arg     = frame->edx;
    Process *proc    = proc_get_current();

    if (fd < 0 || fd >= MAX_FD)          return ERR(EBADF);
    if (proc->fds[fd].type == FD_UNUSED) return ERR(EBADF);

    /* Per ora: solo stdout/stderr supportano TIOCGWINSZ (dimensioni terminale) */
    if ((proc->fds[fd].type == FD_STDOUT ||
         proc->fds[fd].type == FD_STDERR) && request == 0x5413) {
        /* TIOCGWINSZ: ritorna 25 righe, 80 colonne */
        uint16_t *winsize = (uint16_t *)arg;
        if (syscall_verify_ptr(winsize, 8)) {
            winsize[0] = 25;   /* ws_row */
            winsize[1] = 80;   /* ws_col */
            winsize[2] = 640;  /* ws_xpixel */
            winsize[3] = 400;  /* ws_ypixel */
            return 0;
        }
    }

    klog(LOG_DEBUG, "SYSCALL ioctl(fd=%d, req=0x%x, arg=0x%x) non implementato",
         fd, request, arg);
    return ERR(ENOSYS);
}

/* =============================================================================
 * SYS_EXEC (11) -- Esegue un programma ELF
 *
 * ebx = path*  (percorso del file ELF in /bin o /dev)
 * ecx = argv** (array argomenti, NULL-terminated)
 * edx = envp** (array environment, NULL-terminated)
 *
 * Sostituisce il processo corrente con il nuovo programma.
 * (Fase 4: ELF loader -- per ora placeholder funzionale)
 * ============================================================================= */
int32_t sys_exec(InterruptFrame *frame)
{
    const char  *path = (const char *)frame->ebx;
    Process     *proc = proc_get_current();
    ElfLoadResult res;
    char         kpath[256];

    if (!syscall_verify_str(path, 256)) return ERR(EFAULT);

    /* Copia il path in un buffer kernel PRIMA di cambiare CR3: il
     * puntatore originale vive nello user stack del chiamante (vecchia
     * PD), che la nuova PD (quasi vuota) non mappa. Senza questa copia,
     * qualunque dereferenziazione successiva di 'path' (incluso il klog
     * di errore in elf_load se il file non esiste) causa un page fault. */
    {
        uint32_t pi;
        for (pi = 0; pi < sizeof(kpath) - 1 && path[pi]; pi++) kpath[pi] = path[pi];
        kpath[pi] = '\0';
    }

    /* Risolvi contro la directory corrente: `exec prog` dentro /bin deve
     * funzionare come `exec /bin/prog`. */
    {
        char abs[256];
        if (resolve_path(kpath, abs, sizeof(abs)) != 0) return ERR(EINVAL);
        kstrcpy(kpath, abs, sizeof(kpath));
    }

    klog(LOG_INFO, "SYSCALL exec('%s') PID=%u", kpath, proc->pid);

    /* Crea una nuova Page Directory per il processo */
    PDE *new_pd = paging_create_directory();
    if (!new_pd) return ERR(ENOMEM);

    /* Salva la vecchia PD per eventuale rollback */
    PDE *old_pd = proc->page_directory;

    /* Imposta la nuova PD e attiva il mapping */
    proc->page_directory = new_pd;
    paging_switch(new_pd);

    /* Carica il binario ELF (usa kpath, valido in qualunque PD perché
     * vive nello stack della funzione kernel, mappato identicamente da
     * tutte le page directory). */
    if (elf_load(kpath, proc, &res) != 0) {
        /* Errore: ripristina vecchia PD */
        paging_destroy_directory(new_pd);
        proc->page_directory = old_pd;
        paging_switch(old_pd);
        klog(LOG_ERROR, "SYSCALL exec: ELF load fallito per '%s'", kpath);
        return ERR(ENOENT);
    }

    /* Libera la vecchia PD (non serve più) */
    if (old_pd != paging_get_kernel_directory()) {
        paging_destroy_directory(old_pd);
    }

    klog(LOG_INFO, "SYSCALL exec: salto a entry=0x%08x stack=0x%08x",
         res.entry_point, res.user_stack_top);

    /* Salta al nuovo programma in ring3 -- non ritorna */
    sched_enter_usermode(res.entry_point, res.user_stack_top);

    /* Non raggiunto */
    return 0;
}

/* =============================================================================
 * SYS_SPAWN (2) -- Crea un processo figlio autonomo che esegue un programma
 *
 * ebx = path*   (percorso ELF, stringa in user space)
 * ecx = argc    (numero argomenti, incluso argv[0])
 * edx = argv*   (char** in user space, NULL-terminato; NULL = usa solo path)
 *
 * Stack utente iniziale del figlio (visto da _start in lib/start.S):
 *   [esp+0]  = 0        (fake return address -- _start non ritorna)
 *   [esp+4]  = argc
 *   [esp+8]  = argv_ptr (char** verso array subito sopra, stessa pagina stack)
 *   [argc+1 puntatori argv[], NULL-terminati]
 *   [stringhe argv null-terminated, empilate dal top dello stack verso il basso]
 *
 * Scrittura sullo stack del figlio senza switch di CR3:
 *   paging_get_physical(child->pd, virt) restituisce l'indirizzo fisico
 *   corrispondente all'indirizzo virtuale virt nella PD del figlio.
 *   Poiche' il kernel usa identity mapping (fisico == virtuale per la memoria
 *   del kernel e per i frame utente prima che vengano rimappati), possiamo
 *   scrivere a quell'indirizzo fisico direttamente, senza mai cambiare CR3.
 *   Questo e' sicuro, non richiede cli, e funziona correttamente attraverso
 *   i confini di pagina.
 *
 * Ritorna: PID del figlio (>0), errno negativo in caso di errore
 * ============================================================================= */
#define MAX_SPAWN_ARGS  16
#define MAX_ARG_LEN    128

/* Scrive `len` byte da `src` all'indirizzo virtuale `user_virt` nella PD `pd`,
 * usando l'indirizzo fisico (identity-mapped) per ogni pagina — nessun switch CR3.
 * Ritorna 0 se ok, -1 se una pagina non e' mappata. */
static int spawn_write_user(PDE *pd, uint32_t user_virt,
                             const void *src, uint32_t len)
{
    const uint8_t *s = (const uint8_t *)src;
    while (len > 0) {
        uint32_t phys = paging_get_physical(pd, user_virt);
        if (!phys) return -1;
        uint32_t off   = user_virt & 0xFFF;
        uint32_t avail = PAGE_SIZE - off;
        uint32_t chunk = (len < avail) ? len : avail;
        uint8_t *dst = (uint8_t *)phys;
        uint32_t k;
        for (k = 0; k < chunk; k++) dst[k] = s[k];
        s        += chunk;
        user_virt += chunk;
        len      -= chunk;
    }
    return 0;
}

int32_t sys_spawn(InterruptFrame *frame)
{
    const char  *path   = (const char *)frame->ebx;
    uint32_t     argc   = frame->ecx;
    char       **uargv  = (char **)frame->edx;
    Process     *parent = proc_get_current();
    ElfLoadResult res;
    char kpath[256];

    if (!syscall_verify_str(path, 256)) return ERR(EFAULT);
    { uint32_t pi; for (pi = 0; pi < 255 && path[pi]; pi++) kpath[pi] = path[pi]; kpath[pi] = '\0'; }

    /* Percorso relativo -> assoluto usando la directory corrente. */
    { char abs[256];
      if (resolve_path(kpath, abs, sizeof(abs)) != 0) return ERR(EINVAL);
      kstrcpy(kpath, abs, sizeof(kpath)); }

    /* --- Copia argv in kernel space ---------------------------------------- */
    char  kbufs[MAX_SPAWN_ARGS][MAX_ARG_LEN];
    char *kargv[MAX_SPAWN_ARGS + 1];
    uint32_t i, real_argc = 0;

    if (uargv && argc > 0) {
        if (argc > MAX_SPAWN_ARGS) argc = MAX_SPAWN_ARGS;
        for (i = 0; i < argc; i++) {
            if (!syscall_verify_ptr(&uargv[i], sizeof(char*))) break;
            const char *ua = uargv[i];
            if (!ua || !syscall_verify_str(ua, MAX_ARG_LEN)) break;
            uint32_t ai;
            for (ai = 0; ai < MAX_ARG_LEN-1 && ua[ai]; ai++) kbufs[i][ai] = ua[ai];
            kbufs[i][ai] = '\0';
            kargv[i] = kbufs[i];
            real_argc++;
        }
    }
    if (real_argc == 0) {
        /* argv[0] = basename del path */
        const char *bn = kpath;
        for (const char *p = kpath; *p; p++) if (*p == '/') bn = p+1;
        uint32_t ai;
        for (ai = 0; ai < MAX_ARG_LEN-1 && bn[ai]; ai++) kbufs[0][ai] = bn[ai];
        kbufs[0][ai] = '\0';
        kargv[0] = kbufs[0];
        real_argc = 1;
    }
    kargv[real_argc] = NULL;

    klog(LOG_INFO, "SYSCALL spawn('%s') argc=%u PID_parent=%u",
         kpath, real_argc, parent->pid);

    /* --- Crea figlio in stato BLOCKED, carica ELF -------------------------- */

Process *child = proc_create(kpath, 0, PRIO_NORMAL, 0);

if (!child) {
return ERR(ENOMEM); }

if (elf_load(kpath, child, &res) != 0) {

/* FIX BUG #5 (path ELF fail): proc_kill sposta in ZOMBIE e rimuove
         * dalla runq; proc_reap_zombie libera immediatamente le risorse.
         * Chiamarli in sequenza senza cedere la CPU è sicuro: il reaper di
         * init non ha modo di intervenire tra i due perché non c'è switch di
         * contesto (siamo in syscall con interrupt abilitati ma senza yield). */
        proc_kill(child->pid);
        proc_reap_zombie(child);
        klog(LOG_ERROR, "SYSCALL spawn: ELF load fallito per '%s'", kpath);
        return ERR(ENOENT);
    }

    /* --- Costruisci argc/argv sullo stack del figlio ----------------------- */
    /* Scriviamo sullo stack del figlio tramite paging_get_physical: otteniamo
     * l'indirizzo fisico di ogni pagina dello stack (gia' allocata e mappata
     * da elf_load) e ci scriviamo direttamente. Il kernel usa identity mapping
     * per la memoria fisica: indirizzo fisico == indirizzo virtuale in kernel
     * space, quindi il puntatore fisico e' accessibile da qui senza cambiare
     * CR3. Nessun rischio di interrupt nel mezzo di un cambio di PD. */

uint32_t usp       = res.user_stack_top;
    uint32_t arg_ptrs[MAX_SPAWN_ARGS + 1];
    PDE     *cpd       = child->page_directory;

    /* 1. Stringhe argv (partendo dal top e scendendo) */
    for (i = 0; i < real_argc; i++) {
        uint32_t len = 0;
        while (kargv[i][len]) len++;
        len++;          /* include il NUL */
        usp -= len;
        if (spawn_write_user(cpd, usp, kargv[i], len) != 0) {
            klog(LOG_ERROR, "SYSCALL spawn: stack non mappato per argv[%u]", i);
            goto spawn_fail;
        }
        arg_ptrs[i] = usp;
    }
    arg_ptrs[real_argc] = 0;

    /* 2. Allineamento a 4 byte */
    usp &= ~3u;

    /* 3. Array di puntatori argv[] (NULL-terminato) */
    usp -= (real_argc + 1) * sizeof(uint32_t);
    uint32_t argv_uptr = usp;
    for (i = 0; i <= real_argc; i++) {
        if (spawn_write_user(cpd, usp + i*4, &arg_ptrs[i], 4) != 0)
            goto spawn_fail;
    }

    /* 4. Frame C: [fake_ret=0, argc, argv_ptr] */
    usp -= 12;
    { uint32_t z = 0;
      spawn_write_user(cpd, usp+0,  &z,          4);
      spawn_write_user(cpd, usp+4,  &real_argc,  4);
      spawn_write_user(cpd, usp+8,  &argv_uptr,  4); }

proc_set_entry(child, res.entry_point, usp);

proc_set_ready(child);

klog(LOG_INFO, "SYSCALL spawn: PID %u (entry=0x%08x usp=0x%08x) parent=%u",
         child->pid, res.entry_point, usp, parent->pid);
    return (int32_t)child->pid;

spawn_fail:
    /* FIX BUG #5: rendiamo il cleanup atomico disabilitando gli interrupt
     * per tutta la durata. proc_kill → ZOMBIE, proc_reap_zombie → UNUSED.
     * Nessun IRQ0 può far scansionare il reaper di init tra i due passi,
     * eliminando la race condition di doppia free sulla page directory. */
    interrupts_disable();
    proc_kill(child->pid);
    proc_reap_zombie(child);
    interrupts_enable();
    return ERR(ENOMEM);
}

/* =============================================================================
 * SYS_SCHED_YIELD (158) -- Cede volontariamente la CPU
 * ============================================================================= */
int32_t sys_sched_yield(InterruptFrame *frame)
{
    (void)frame;
    sched_yield();
    return 0;
}

/* =============================================================================
 * SYS_SLEEP (162) -- Dorme per N millisecondi
 *
 * ebx = millisecondi
 * ============================================================================= */
int32_t sys_sleep(InterruptFrame *frame)
{
    uint32_t ms = frame->ebx;
    sched_sleep(ms);
    return 0;
}

/* =============================================================================
 * SYS_SBRK (45) -- Espande/riduce lo heap del processo
 *
 * ebx = increment (signed, può essere negativo)
 *
 * Ritorna: indirizzo vecchio heap_end, o errore
 * ============================================================================= */
int32_t sys_sbrk(InterruptFrame *frame)
{
    int32_t   incr = (int32_t)frame->ebx;
    Process  *proc = proc_get_current();
    uint32_t  old_end;
    uint32_t  pages, i, pg_flags;

    /* Inizializza heap utente se non ancora fatto */
    if (proc->heap_start == 0) {
        proc->heap_start = USER_SPACE_BASE;
        proc->heap_end   = USER_SPACE_BASE;
    }

    old_end = proc->heap_end;

    if (incr == 0) return (int32_t)old_end;

    if (incr > 0) {
        /* FIX BUG #4: non riusare il frame (corromperebbe EBX/ECX del
         * processo utente al ritorno via popad in syscall_stub).
         * Espandiamo l'heap allocando e mappando le pagine direttamente,
         * senza passare per sys_mmap che richiederebbe un frame valido. */
        pages    = ALIGN_UP((uint32_t)incr, PAGE_SIZE) / PAGE_SIZE;
        pg_flags = PG_PRESENT | PG_WRITABLE | PG_USER;

        for (i = 0; i < pages; i++) {
            uint32_t vaddr = proc->heap_end + i * PAGE_SIZE;
            uint32_t phys  = pmm_alloc_page();
            if (phys == 0) {
                /* OOM: rilascia le pagine già allocate in questo ciclo */
                uint32_t j;
                for (j = 0; j < i; j++) {
                    uint32_t va = proc->heap_end + j * PAGE_SIZE;
                    uint32_t pa = paging_get_physical(proc->page_directory, va);
                    if (pa) pmm_free_page(pa);
                    paging_unmap_page(proc->page_directory, va);
                }
                return ERR(ENOMEM);
            }
            /* Azzera la pagina */
            { uint8_t *p = (uint8_t *)phys; uint32_t n = PAGE_SIZE; while (n--) *p++ = 0; }

            if (paging_map_page(proc->page_directory, vaddr, phys, pg_flags) != 0) {
                pmm_free_page(phys);
                /* Rilascia le precedenti */
                uint32_t j;
                for (j = 0; j < i; j++) {
                    uint32_t va = proc->heap_end + j * PAGE_SIZE;
                    uint32_t pa = paging_get_physical(proc->page_directory, va);
                    if (pa) pmm_free_page(pa);
                    paging_unmap_page(proc->page_directory, va);
                }
                return ERR(ENOMEM);
            }
        }
        proc->heap_end += pages * PAGE_SIZE;

    } else {
        /* Riduzione: libera pagine direttamente (stessa ragione: no frame mutation) */
        uint32_t shrink = (uint32_t)(-incr);
        uint32_t new_end = proc->heap_end - shrink;
        if (new_end < proc->heap_start) return ERR(EINVAL);

        pages = ALIGN_UP(shrink, PAGE_SIZE) / PAGE_SIZE;
        for (i = 0; i < pages; i++) {
            uint32_t va   = new_end + i * PAGE_SIZE;
            uint32_t phys = paging_get_physical(proc->page_directory, va);
            if (phys) pmm_free_page(phys);
            paging_unmap_page(proc->page_directory, va);
        }
        proc->heap_end = new_end;
    }

    klog(LOG_DEBUG, "SYSCALL sbrk(%d): heap 0x%08x -> 0x%08x",
         incr, old_end, proc->heap_end);

    return (int32_t)old_end;
}

/* =============================================================================
 * SYS_GETCWD (183) -- Ritorna la directory di lavoro corrente
 *
 * ebx = buf*   (buffer utente)
 * ecx = size   (dimensione buffer)
 * ============================================================================= */
int32_t sys_getcwd(InterruptFrame *frame)
{
    char    *buf  = (char *)frame->ebx;
    uint32_t size = frame->ecx;
    uint32_t len;

    if (!syscall_verify_ptr(buf, size)) return ERR(EFAULT);
    if (size == 0)                       return ERR(EINVAL);

    len = kstrlen(g_cwd);
    if (len + 1 > size) return ERR(EINVAL);

    kstrcpy(buf, g_cwd, size);
    return (int32_t)len;
}

/* =============================================================================
 * SYS_CHDIR (12) -- Cambia directory di lavoro
 *
 * ebx = path*
 * ============================================================================= */
int32_t sys_chdir(InterruptFrame *frame)
{
    const char *path = (const char *)frame->ebx;

    if (!syscall_verify_str(path, 256)) return ERR(EFAULT);

    {
        char       abs[256];
        Fat12Stat  st;

        if (resolve_path(path, abs, sizeof(abs)) != 0) return ERR(EINVAL);

        /* La root esiste sempre e non ha una entry di directory da
         * interrogare: fat12_stat("/") fallirebbe. */
        if (!(abs[0] == '/' && abs[1] == '\0')) {
            /* VERIFICA AGGIUNTA (luglio 2026): prima chdir() accettava
             * qualunque stringa senza controllare nulla — `cd /inesistente`
             * "riusciva" e da quel momento ogni percorso relativo puntava
             * in un posto che non c'è. Ora si conferma che la
             * destinazione esista e sia davvero una directory. */
            if (fat12_stat(abs, &st) != 0) {
                klog(LOG_DEBUG, "SYSCALL chdir('%s'): non trovato", abs);
                return ERR(ENOENT);
            }
            /* Bit 4 dell'attributo FAT = ATTR_DIRECTORY */
            if (!(st.attr & 0x10)) {
                klog(LOG_DEBUG, "SYSCALL chdir('%s'): non e' una directory", abs);
                return ERR(EINVAL);
            }
        }

        kstrcpy(g_cwd, abs, sizeof(g_cwd));
    }

    klog(LOG_DEBUG, "SYSCALL chdir('%s')", g_cwd);
    return 0;
}

/* =============================================================================
 * SYS_STAT (106) -- Informazioni su un file
 *
 * ebx = path*
 * ecx = stat*  (buffer Stat utente)
 * ============================================================================= */
int32_t sys_stat(InterruptFrame *frame)
{
    const char *path = (const char *)frame->ebx;
    Stat       *st   = (Stat *)frame->ecx;

    if (!syscall_verify_str(path, 256))      return ERR(EFAULT);
    if (!syscall_verify_ptr(st, sizeof(Stat))) return ERR(EFAULT);

    /* TODO Fase 3: cerccare file nel FAT12 e riempire Stat */
    klog(LOG_DEBUG, "SYSCALL stat('%s') -- FAT12 non ancora implementato", path);
    return ERR(ENOSYS);
}

/* =============================================================================
 * SYS_LSEEK (19) -- Sposta la posizione in un file
 *
 * ebx = fd
 * ecx = offset
 * edx = whence (0=SEEK_SET, 1=SEEK_CUR, 2=SEEK_END)
 * ============================================================================= */
int32_t sys_lseek(InterruptFrame *frame)
{
    int32_t  fd     = (int32_t)frame->ebx;
    int32_t  offset = (int32_t)frame->ecx;
    uint32_t whence = frame->edx;
    Process *proc   = proc_get_current();
    uint32_t new_off;

    if (fd < 0 || fd >= MAX_FD)          return ERR(EBADF);
    if (proc->fds[fd].type == FD_UNUSED) return ERR(EBADF);
    if (proc->fds[fd].type != FD_FILE)   return ERR(EBADF);

    switch (whence) {
        case 0: /* SEEK_SET */
            if (offset < 0) return ERR(EINVAL);
            new_off = (uint32_t)offset;
            break;
        case 1: /* SEEK_CUR */
            new_off = proc->fds[fd].offset + (uint32_t)offset;
            break;
        case 2: /* SEEK_END */
            /* TODO Fase 3: serve dimensione file dal FAT12 */
            return ERR(ENOSYS);
        default:
            return ERR(EINVAL);
    }

    proc->fds[fd].offset = new_off;
    return (int32_t)new_off;
}

/* =============================================================================
 * SYS_READDIR (141) -- Elenca il contenuto di una directory
 *
 * ebx = path*        (NULL, "" o "/" per la root; "/NOME" per una
 *                      subdirectory di un livello, es. "/bin")
 * ecx = DirEntry* buf (buffer utente, gia' allocato dal chiamante)
 * edx = max_entries  (capacita' del buffer, in numero di DirEntry)
 * esi = start        (indice della prima voce da restituire: permette di
 *                      percorrere a blocchi una directory piu' grande del
 *                      buffer)
 *
 * PAGINAZIONE AGGIUNTA (luglio 2026). Prima la syscall restituiva sempre
 * e solo le PRIME voci, con un tetto interno di 64 indipendente da quanto
 * chiedeva il chiamante. Il troncamento era SILENZIOSO: /bin/ls mostrava
 * una directory incompleta senza dirlo, e /bin/delete cancellava solo i
 * file corrispondenti fra i primi 64 lasciando gli altri, facendo credere
 * di aver finito. Il tetto resta (protegge lo stack del kernel), ma ora il
 * chiamante puo' continuare da dove era arrivato.
 *
 * Ritorna il numero di entry scritte in buf (>= 0), o errno negativo.
 * Wrapper sottile su fat12_readdir_path(): legge in un buffer kernel
 * intermedio (mai esporre puntatori interni allo userspace), converte il
 * nome 8.3 raw in stringa leggibile, poi copia nel buffer utente gia'
 * verificato.
 * ============================================================================= */
#define READDIR_MAX_BATCH 64   /* limite di sicurezza, indipendente da
                                   quanto richiesto dal chiamante */

int32_t sys_readdir(InterruptFrame *frame)
{
    const char *path        = (const char *)frame->ebx;
    DirEntry   *user_buf    = (DirEntry *)frame->ecx;
    uint32_t    max_entries = frame->edx;
    uint32_t    start       = frame->esi;
    char        kpath[256];
    Fat12DirEntry fentries[READDIR_MAX_BATCH];
    uint32_t    fcount, cap, i;

    if (path && !syscall_verify_str(path, 256)) return ERR(EFAULT);
    if (max_entries == 0) return ERR(EINVAL);

    cap = max_entries;
    if (cap > READDIR_MAX_BATCH) cap = READDIR_MAX_BATCH;

    if (!syscall_verify_ptr(user_buf, sizeof(DirEntry) * cap)) return ERR(EFAULT);

    if (path) {
        if (resolve_path(path, kpath, sizeof(kpath)) != 0) return ERR(EINVAL);
    } else {
        kpath[0] = '\0';
    }

    if (fat12_readdir_path(kpath[0] ? kpath : NULL, fentries, cap, &fcount,
                            start) != 0) {
        klog(LOG_DEBUG, "SYSCALL readdir('%s'): non trovata o non e' una directory", kpath);
        return ERR(ENOENT);
    }

    for (i = 0; i < fcount; i++) {
        DirEntry de;
        fat12_format_name(&fentries[i], de.name);
        de.size   = fentries[i].file_size;
        de.is_dir = (fentries[i].attr & FAT12_ATTR_DIRECTORY) ? 1 : 0;
        user_buf[i] = de;
    }

    klog(LOG_DEBUG, "SYSCALL readdir('%s', da %u): %u entry",
         kpath, start, fcount);
    return (int32_t)fcount;
}

/* =============================================================================
 * SYS_GETENV (184) -- Legge una variabile della sezione [env] di kernel.cfg
 *
 * ebx = key*   (nome della variabile, stringa null-terminated)
 * ecx = buf*   (buffer utente dove copiare il valore)
 * edx = size   (dimensione del buffer)
 *
 * Ritorna la lunghezza del valore copiato (>=0), -ENOENT se la variabile
 * non esiste, -EINVAL se il buffer è troppo piccolo.
 *
 * PERCHÉ ESISTE (luglio 2026): la sezione [env] di /boot/kernel.cfg
 * veniva letta, memorizzata e perfino stampata nel log di boot, ma
 * cfg_getenv() non aveva UN SOLO chiamante in tutto il progetto. I
 * processi utente non avevano alcun modo di raggiungere quei valori, e
 * la shell si limitava a ri-hardcodare le stesse coppie chiave/valore in
 * env_init() — due copie della stessa verità, destinate a divergere al
 * primo che avesse modificato kernel.cfg aspettandosi un effetto.
 *
 * Il valore viene copiato in un buffer utente, mai esposto come
 * puntatore interno: stessa regola già seguita da sys_getcwd e
 * sys_readdir.
 * ============================================================================= */
int32_t sys_getenv(InterruptFrame *frame)
{
    const char *key  = (const char *)frame->ebx;
    char       *buf  = (char *)frame->ecx;
    uint32_t    size = frame->edx;
    const char *val;
    uint32_t    len;

    if (!syscall_verify_str(key, CFG_NAME_LEN)) return ERR(EFAULT);
    if (!syscall_verify_ptr(buf, size))          return ERR(EFAULT);
    if (size == 0)                                return ERR(EINVAL);

    val = cfg_getenv(key);
    if (val == NULL) val = cfg_get_option(key);   /* opzioni fuori da [env] */
    if (val == NULL) return ERR(ENOENT);

    len = kstrlen(val);
    if (len + 1 > size) return ERR(EINVAL);

    kstrcpy(buf, val, size);
    return (int32_t)len;
}

/* =============================================================================
 * SYS_MKDIR (39) -- Crea una directory
 *
 * ebx = path*  (assoluto o relativo alla directory corrente)
 *
 * Ritorna 0, -EEXIST se esiste già, -ENOSYS se il percorso richiederebbe
 * più di un livello di annidamento (limite del driver FAT12, vedi
 * fat12_mkdir), o un altro errore negativo.
 *
 * Il secondo argomento POSIX (mode) non esiste: FAT12 non ha permessi.
 * ============================================================================= */
int32_t sys_mkdir(InterruptFrame *frame)
{
    const char *path = (const char *)frame->ebx;
    char        abs[256];
    int         r;

    if (!syscall_verify_str(path, 256)) return ERR(EFAULT);
    if (resolve_path(path, abs, sizeof(abs)) != 0) return ERR(EINVAL);

    r = fat12_mkdir(abs);
    klog(LOG_INFO, "SYSCALL mkdir('%s') -> %d", abs, r);

    /* fat12_mkdir usa già la convenzione degli errno negativi. */
    return (int32_t)r;
}

/* =============================================================================
 * SYS_RMDIR (40) -- Cancella una directory vuota
 *
 * ebx = path*  (assoluto o relativo alla directory corrente)
 *
 * Ritorna 0, oppure: -ENOENT non trovata, -ENOTDIR non è una directory,
 * -ENOTEMPTY se contiene qualcosa, -ENOSYS per percorsi annidati.
 * ============================================================================= */
int32_t sys_rmdir(InterruptFrame *frame)
{
    const char *path = (const char *)frame->ebx;
    char        abs[256];
    int         r;

    if (!syscall_verify_str(path, 256)) return ERR(EFAULT);
    if (resolve_path(path, abs, sizeof(abs)) != 0) return ERR(EINVAL);

    r = fat12_rmdir(abs);
    klog(LOG_INFO, "SYSCALL rmdir('%s') -> %d", abs, r);
    return (int32_t)r;
}

/* =============================================================================
 * SYS_UNLINK (10) -- Cancella un file
 *
 * ebx = path*  (assoluto o relativo alla directory corrente)
 *
 * Ritorna 0, -ENOENT se non esiste, -EISDIR se è una directory (per
 * quelle c'è rmdir). Nessuna espansione di caratteri jolly qui: il
 * kernel cancella un nome preciso, l'espansione la fa /bin/delete
 * elencando la directory — così il programma può anche dire all'utente
 * quali file sta per togliere.
 * ============================================================================= */
int32_t sys_unlink(InterruptFrame *frame)
{
    const char *path = (const char *)frame->ebx;
    char        abs[256];
    int         r;

    if (!syscall_verify_str(path, 256)) return ERR(EFAULT);
    if (resolve_path(path, abs, sizeof(abs)) != 0) return ERR(EINVAL);

    r = fat12_delete(abs);
    klog(LOG_INFO, "SYSCALL unlink('%s') -> %d", abs, r);
    return (int32_t)r;
}

/* =============================================================================
 * SYS_VERSION (185) -- Copia l'identità del sistema in un buffer utente
 *
 * ebx = buf*   (buffer utente)
 * ecx = size   (dimensione del buffer)
 *
 * Ritorna la lunghezza della stringa copiata (>=0), -EINVAL se il buffer
 * è troppo piccolo (nessuna copia parziale: o tutto o niente, così il
 * chiamante non stampa mai un'identità troncata a metà frase).
 *
 * La sorgente è `g_os_version`, la variabile globale definita in
 * kernel/version.c — unica fonte di verità per nome, versione, autore e
 * licenza. La shell la espone con i comandi `ver` e `version`.
 * ============================================================================= */
int32_t sys_version(InterruptFrame *frame)
{
    char    *buf  = (char *)frame->ebx;
    uint32_t size = frame->ecx;
    uint32_t len;

    if (!syscall_verify_ptr(buf, size)) return ERR(EFAULT);
    if (size == 0)                       return ERR(EINVAL);

    len = kstrlen(g_os_version);
    if (len + 1 > size) return ERR(EINVAL);

    kstrcpy(buf, g_os_version, size);
    return (int32_t)len;
}

/* =============================================================================
 * SYS_REBOOT (88) -- Spegne, riavvia o ferma il sistema
 *
 * ebx = comando: EXOS_RB_POWEROFF / EXOS_RB_RESTART / EXOS_RB_HALT
 *
 * Non ritorna mai (se non con errore su comando non valido).
 *
 * PERCHÉ SERVE UNA SYSCALL: prima la shell eseguiva `cli; hlt` per halt e
 * `inb`/`outb` sulla porta 0x64 per reboot, direttamente nel proprio
 * codice ring3. Sono istruzioni PRIVILEGIATE: in ring3 sollevano #GP, e
 * il #GP finiva nel ramo di default di isr_handler() producendo un
 * KERNEL PANIC. Entrambi i comandi erano quindi rotti allo stesso modo.
 * La sequenza di arresto ora sta nel kernel (kernel/arch/x86/power.c),
 * dove quelle istruzioni sono legali, e include la sincronizzazione del
 * filesystem — che dalla shell non era comunque possibile fare.
 *
 * NOTA sui permessi: qualunque processo può chiamarla. Non c'è ancora un
 * concetto di utente o privilegio in EX-OS, quindi non c'è nulla su cui
 * basare un controllo. Da rivedere quando esisteranno gli UID.
 * ============================================================================= */
int32_t sys_reboot(InterruptFrame *frame)
{
    uint32_t cmd  = frame->ebx;
    Process *self = proc_get_current();

    klog(LOG_INFO, "SYSCALL reboot(cmd=%u) richiesta da PID %u '%s'",
         cmd, self ? self->pid : 0, self ? self->name : "?");

    switch (cmd) {
        case EXOS_RB_POWEROFF: power_off();    /* non ritorna */
        case EXOS_RB_RESTART:  power_reboot(); /* non ritorna */
        case EXOS_RB_HALT:     power_halt();   /* non ritorna */
        default:
            return ERR(EINVAL);
    }
}

/* =============================================================================
 * SYS_IPC_SEND (220) -- Invia un messaggio a un altro processo
 *
 * ebx = dest_pid
 * ecx = type      (tipo applicativo del messaggio, libero per il chiamante)
 * edx = data*     (puntatore ai dati in userspace, può essere NULL se len=0)
 * esi = len       (byte da inviare, troncati a IPC_MSG_MAX_DATA)
 *
 * Il kernel copia i dati dal buffer utente a un buffer kernel prima di
 * qualunque operazione — mai un puntatore utente attraversa il confine
 * di processo. Ritorna 0 su successo, <0 su errore.
 * ============================================================================= */
int32_t sys_ipc_send(InterruptFrame *frame)
{
    uint32_t    dest_pid = frame->ebx;
    uint32_t    type     = frame->ecx;
    const void *data     = (const void *)frame->edx;
    uint32_t    len       = frame->esi;

    if (len > IPC_MSG_MAX_DATA) len = IPC_MSG_MAX_DATA;

    if (data != NULL && len > 0 && !syscall_verify_ptr(data, len)) {
        return ERR(EFAULT);
    }

    int32_t ret = ipc_send(dest_pid, type, data, len);
    klog(LOG_DEBUG, "SYSCALL ipc_send(dest=%u, type=%u, len=%u) -> %d",
         dest_pid, type, len, ret);
    return ret;
}

/* =============================================================================
 * SYS_IPC_RECV (221) -- Riceve il prossimo messaggio dalla propria mailbox
 *
 * ebx = out_meta*  (IpcMessage*: sender_pid/type/len — solo header, opzionale)
 * ecx = buf*       (buffer utente dove copiare il payload, opzionale)
 * edx = buf_len    (dimensione del buffer utente)
 *
 * Blocca finché non arriva un messaggio. Ritorna 0 su successo (mai <0
 * in questa implementazione, dato che il processo chiamante esiste per
 * definizione mentre esegue la propria syscall).
 * ============================================================================= */
int32_t sys_ipc_recv(InterruptFrame *frame)
{
    IpcMessage *out_meta = (IpcMessage *)frame->ebx;
    void       *buf      = (void *)frame->ecx;
    uint32_t    buf_len  = frame->edx;

    if (out_meta != NULL && !syscall_verify_ptr(out_meta, sizeof(IpcMessage))) {
        return ERR(EFAULT);
    }
    if (buf != NULL && buf_len > 0 && !syscall_verify_ptr(buf, buf_len)) {
        return ERR(EFAULT);
    }

    IpcMessage kmeta;
    int32_t ret = ipc_recv(&kmeta, buf, buf_len);
    if (ret == 0 && out_meta != NULL) {
        *out_meta = kmeta;
    }
    return ret;
}

/* =============================================================================
 * SYS_IPC_REGISTER (222) -- Registra il processo chiamante come servizio
 *
 * ebx = name*   (stringa null-terminated, max IPC_NAME_LEN-1 caratteri)
 *
 * Usata da driver e servizi all'avvio per farsi trovare dai client
 * tramite nome invece che PID (assegnato dinamicamente). Ritorna 0 su
 * successo, -EEXIST se il nome è già registrato da un processo vivo.
 * ============================================================================= */
int32_t sys_ipc_register(InterruptFrame *frame)
{
    const char *name = (const char *)frame->ebx;

    if (!syscall_verify_str(name, IPC_NAME_LEN)) return ERR(EFAULT);

    int32_t ret = ipc_register(name);
    klog(LOG_INFO, "SYSCALL ipc_register('%s') PID=%u -> %d",
         name, proc_get_current()->pid, ret);
    return ret;
}

/* =============================================================================
 * SYS_IPC_LOOKUP (223) -- Cerca il PID del servizio registrato con 'name'
 *
 * ebx = name*
 *
 * Ritorna il PID (>0) su successo, -ENOENT se nessun processo vivo ha
 * registrato quel nome.
 * ============================================================================= */
int32_t sys_ipc_lookup(InterruptFrame *frame)
{
    const char *name = (const char *)frame->ebx;

    if (!syscall_verify_str(name, IPC_NAME_LEN)) return ERR(EFAULT);

    return ipc_lookup(name);
}

/* =============================================================================
 * SYS_IRQ_BIND (224) -- Rivendica un IRQ hardware per il processo chiamante
 *
 * ebx = numero IRQ (0-15)
 *
 * Da questo momento, gli interrupt hardware su quell'IRQ arrivano come
 * messaggi IPC nella mailbox del chiamante (sender_pid=0, type=0xFFFFFFFF,
 * payload=uint32_t col numero IRQ) invece di essere ignorati dal kernel.
 * Un solo processo vivo alla volta può rivendicare un dato IRQ.
 * ============================================================================= */
int32_t sys_irq_bind(InterruptFrame *frame)
{
    uint8_t irq = (uint8_t)frame->ebx;
    uint32_t pid = proc_get_current()->pid;

    int32_t ret = irq_bind_process(irq, pid);
    klog(LOG_INFO, "SYSCALL irq_bind(irq=%u) PID=%u -> %d", irq, pid, ret);
    return ret;
}

/* =============================================================================
 * SYS_IOPORT_BIND (225) -- Richiede l'accesso a un range di porte I/O
 *
 * ebx = base (indirizzo porta iniziale)
 * ecx = count (numero di porte consecutive, es. 8 per 0x60-0x67)
 *
 * Un solo range contiguo per processo — chiamate successive sovrascrivono
 * il range precedente. Nessuna verifica di conflitto con altri processi:
 * a differenza degli IRQ, più driver che condividono un bus (es. master
 * e slave PIC) potrebbero legittimamente necessitare porte overlappanti;
 * l'isolamento reale è che un processo può toccare SOLO le porte per cui
 * ha chiamato questa bind, mai porte arbitrarie.
 * ============================================================================= */
int32_t sys_ioport_bind(InterruptFrame *frame)
{
    uint32_t base  = frame->ebx;
    uint32_t count = frame->ecx;

    if (base > 0xFFFF || count == 0 || base + count > 0x10000) {
        return ERR(EINVAL);
    }

    Process *self = proc_get_current();
    self->io_port_base  = base;
    self->io_port_count = count;

    klog(LOG_INFO, "SYSCALL ioport_bind(base=0x%x, count=%u) PID=%u",
         base, count, self->pid);
    return 0;
}

/* Verifica che 'port' sia dentro il range rivendicato dal chiamante */
static int ioport_allowed(Process *p, uint16_t port)
{
    if (p->io_port_count == 0) return 0;
    return (port >= p->io_port_base) &&
           (port < p->io_port_base + p->io_port_count);
}

/* =============================================================================
 * SYS_IOPORT_IN (226) -- Legge un byte da una porta I/O
 *
 * ebx = porta
 * Ritorna il byte letto (0-255) su successo, -EPERM se la porta non è
 * nel range rivendicato con SYS_IOPORT_BIND.
 * ============================================================================= */
int32_t sys_ioport_in(InterruptFrame *frame)
{
    uint16_t port = (uint16_t)frame->ebx;
    Process *self = proc_get_current();

    if (!ioport_allowed(self, port)) {
        klog(LOG_WARN, "SYSCALL ioport_in: PID %u nega'to accesso a porta 0x%x",
             self->pid, port);
        return ERR(EPERM);
    }

    return (int32_t)port_inb(port);
}

/* =============================================================================
 * SYS_IOPORT_OUT (227) -- Scrive un byte su una porta I/O
 *
 * ebx = porta
 * ecx = valore (0-255)
 * Ritorna 0 su successo, -EPERM se la porta non è in whitelist.
 * ============================================================================= */
int32_t sys_ioport_out(InterruptFrame *frame)
{
    uint16_t port  = (uint16_t)frame->ebx;
    uint8_t  value = (uint8_t)frame->ecx;
    Process *self  = proc_get_current();

    if (!ioport_allowed(self, port)) {
        klog(LOG_WARN, "SYSCALL ioport_out: PID %u negato accesso a porta 0x%x",
             self->pid, port);
        return ERR(EPERM);
    }

    port_outb(port, value);
    return 0;
}
