# EX-OS — Sottoinsieme "solo kernel"

Estratto da exa_os_2026_05_20_207.zip per lavorare sull'evoluzione verso
driver in userspace senza portarsi dietro l'intero progetto.

## Incluso
- `kernel/`               — tutto il kernel (arch, fs, include, loader, mm, sched, syscall)
- `drivers/tty/`           — compilato STATICAMENTE dentro il kernel (vedi Makefile,
                              target $(BUILD_KERNEL)/tty.o), quindi conta come kernel
- `drivers/floppy/`, `drivers/kbd/` — moduli .so caricati a runtime in ring0 da
                              kernel/loader/drvmgr.c. Non sono "kernel" in senso
                              stretto, ma sono il riferimento del contratto attuale
                              (drv_init/drv_read/drv_write/drv_ioctl/drv_exit) da
                              ridisegnare per farli girare in userspace (ring3)
- `bin/sh/`, `bin/hello/`, `bin/ls/` — shell.c usa SYS_SPAWN/SYS_WAITPID;
                              ls.c è il primo programma esterno che usa la
                              libc invece di reimplementare le syscall a mano
- `lib/`                   — libc.c/libc.h, ora necessari: ls.c ci è
                              compilato/linkato staticamente insieme (vedi
                              regola Makefile "ls", niente link dinamico
                              ancora supportato dal loader per programmi
                              normali)
- `boot/kernel.cfg`        — definisce shell= e modules= al boot
- `Makefile`                — completo (riferimento a bootloader esiste
                              ancora, ma non serve per leggere/modificare il kernel)
- `HANDOFF.md`, `README.md` — contesto di progetto

## Escluso (non necessario per il lavoro sul kernel)
- `bootloader/`  — stage1/stage2, FAT12 reader del bootloader (diverso da
                    kernel/fs/fat12.c, che è il filesystem driver del kernel)
- `tools/`       — script di build/test (install_apt, mkfloppy, test_vbox)

## Punti aperti identificati durante la review (giugno 2026)

### ✅ Risolti (in questo pacchetto)

1. **Mancava fork()/spawn()** → Aggiunta `SYS_SPAWN` (numero 2, syscall.h/
   syscall_impl.c/syscall.c). Crea un processo figlio con PID e page
   directory proprie, senza toccare il chiamante (a differenza di
   `sys_exec`, che resta una vera exec() POSIX — sostituisce il
   processo). Il chiamante riceve il PID del figlio e può attendere la
   sua conclusione con `SYS_WAITPID`.

2. **`SYS_WAITPID` esisteva ma non poteva mai svegliarsi**: `proc_exit()`
   non chiamava mai `sched_unblock()` sul genitore in attesa →
   aggiunto. Nota tecnica: non si poteva chiamare `sched_unblock()`
   "pubblica" da dentro `proc_exit()` perché entrambe fanno
   cli/sti grezzi non annidati — riattivare le interrupt a metà di
   `proc_exit()` (prima dello switch di contesto) sarebbe stato
   pericoloso. Aggiunta `sched_unblock_locked()` (variante senza
   cli/sti) usata da entrambi i punti.

3. **`proc_exit()` distruggeva la page directory ATTIVA in CR3** prima
   dello switch di contesto (stesso CR3 ancora in uso). Risolto
   spostando TUTTA la liberazione delle risorse del processo (page
   directory, stack utente, **e finalmente anche lo stack kernel, mai
   liberato in nessun punto prima d'ora — leak pre-esistente**) dentro
   `sys_waitpid()`, nel momento in cui il genitore raccoglie lo zombie:
   a quel punto il processo non è più "current" da un pezzo, quindi è
   sicuro.

4. **`page_fault_handler` chiamava `kpanic()` per QUALSIASI fault**,
   anche da ring3. Ora un fault da un processo utente termina solo
   quel processo (via `proc_exit(-11)`, stile SIGSEGV); `kpanic()`
   resta riservato ai fault originati in ring0 (bug reale del kernel).
   Step necessario prima di mettere driver in userspace: un driver
   buggy non deve poter affondare il kernel.

Tutti e 4 i file toccati (`kernel/sched/sched.c`,
`kernel/syscall/syscall_impl.c`, `kernel/syscall/syscall.c`,
`kernel/mm/paging.c`, più l'header `kernel/include/syscall.h`)
compilano senza warning con `-Wall -Wextra -m32`.

**Limite noto, volutamente fuori scope per questo batch**: se un
processo termina e il suo genitore non chiama mai `waitpid()` (es. un
servizio/driver in background mai atteso esplicitamente, o un genitore
che muore prima), le sue risorse restano "zombie" non riOccupate
per sempre — manca ancora un reaper/init che adotti gli orfani. Da
affrontare quando si arriverà alla supervisione dei driver/servizi
userspace.

**Risolto anche `bin/sh/shell.c`**: `run_program()` (usata per ogni comando
non built-in digitato) ora chiama `sh_spawn()`+`sh_waitpid()` invece di
`sh_exec()` — la shell lancia un task autonomo e attende la sua fine,
restando viva. Il built-in esplicito `exec` mantiene invece la vecchia
semantica di sostituzione vera (nuova funzione `run_program_replace()`,
via `sh_exec`/`SYS_EXEC`) — comportamento intenzionale, come l'`exec`
builtin di bash: chi lo digita sa che la shell corrente finisce lì.
Compilato e verificato con i flag utente del progetto (`-m32
-ffreestanding ... -Wall -O2`), zero warning. File incluso ora in
`bin/sh/shell.c` in questo pacchetto, insieme a `bin/hello/hello.c` come
riferimento (hello.c non ha richiesto modifiche: il bug era tutto nella
shell/scheduler, non nel programma).

### 🐛 Regressione introdotta dal fix sopra, trovata testando e corretta

Il primo giro di fix (punti 1-4) ha introdotto un bug nuovo, scoperto
provando `hello` su build reale: **KERNEL PANIC, page fault in ring0 a
un indirizzo 16 byte sotto l'inizio dello stack utente del processo**.

Causa: sia `sys_waitpid()` sia il percorso di fallimento di `sys_spawn()`
chiamavano `kfree((void*)p->user_stack_base)`. Ma `user_stack_base` **non
è un puntatore kmalloc** — è un indirizzo virtuale fisso
(`USER_SPACE_END - PAGE_SIZE - USER_STACK_SIZE`) mappato da `elf_load()`
con `pmm_alloc_page()`+`paging_map_page()` nella PD del FIGLIO, valido
solo quando quella PD è attiva in CR3 (qui non lo è mai: il genitore
gira con la propria PD). `kfree()` ci legge/scrive sopra metadati
dell'heap a un indirizzo che lì non significa nulla → fault.

Fix, alla radice invece che solo togliere la kfree sbagliata:
- `paging_destroy_directory()` ora libera anche le pagine fisiche di
  DATI mappate da ogni page table dello spazio utente (codice, dati,
  heap, stack), non solo le page table stesse — prima il commento nel
  codice diceva esplicitamente che questo "lo fa il VMM/exec", ma in
  pratica non lo faceva **nessuno**, leak pre-esistente più ampio,
  risolto come effetto collaterale.
- Rimosse le `kfree(user_stack_base)` ora superflue da `sys_waitpid()` e
  `sys_spawn()`.
- Trovato e corretto un leak collegato in `proc_create()`: allocava uno
  stack utente "placeholder" da 64KB via `kmalloc()` che `elf_load()`
  sovrascriveva sempre subito dopo — 64KB persi a ogni processo creato.
  Rimossa l'allocazione inutile (`user_stack_base`/`top` partono a 0,
  `elf_load()` li imposta sempre prima che il processo possa girare).

Ricompila pulito con `-Wall -Wextra -m32`.

### ✅ SYS_READDIR + /bin/ls (giugno 2026)

- `kernel/fs/fat12.c`/`.h`: sostituita `fat12_readdir()` (solo root,
  restituiva un puntatore interno) con `fat12_readdir_path()` — elenca
  root O una subdirectory di un livello (stessa limitazione di
  `fat12_find_path()` già esistente), **copia** sempre in un buffer
  fornito dal chiamante invece di esporre `g_root_dir` direttamente.
  Aggiunta `fat12_format_name()` per convertire il nome 8.3 raw in
  stringa leggibile.
- `kernel/include/syscall.h` / `syscall_impl.c` / `syscall.c`: nuova
  `SYS_READDIR` (141). Copia sempre attraverso un buffer kernel
  intermedio (mai esporre puntatori interni allo userspace), limite di
  sicurezza a 64 entry per chiamata indipendente da quanto richiesto.
  Struct `DirEntry` (name/size/is_dir) condivisa "a mano" fra kernel e
  libc (stessa convenzione di duplicazione già in uso nel progetto per i
  numeri di syscall fra kernel e bin/sh/shell.c).
- `lib/libc.c`/`.h`: aggiunta `listdir()` (non è la tripletta POSIX
  opendir/readdir/closedir — un'unica chiamata, niente handle).
- `bin/ls/ls.c` + `bin/ls/ls.ld`: primo programma esterno che usa la
  libc invece di reimplementare le syscall a mano (come hello/shell
  fanno). **Linkato staticamente** con `lib/libc.c` (vedi nuova regola
  Makefile "ls") — il loader ELF non supporta ancora link dinamico
  runtime per programmi normali (`PT_DYNAMIC` definito in `elf.c` ma mai
  elaborato; quel meccanismo esiste solo per i driver via
  `kernel/loader/dynlink.c`). Aggiunto anche a `make all`.
- ~~**Limite noto**: niente argv ancora — `ls` elenca sempre `getcwd()`.~~
  **SUPERATO**: `sys_spawn` costruisce lo stack iniziale con argc/argv
  (vedi il commento sul layout in `syscall_impl.c`), `run_program()` in
  shell.c passa gli argomenti, `lib/start.S` li legge e `ls.c` usa
  `argv[1]`. Verificato il 2026-07-30: `ls /bin` elenca `/bin`.
- Compilato/linkato e verificato (gcc -m32 -Wall -Wextra per il kernel,
  link ELF32 statico riuscito per ls — stesso warning RWX benigno che ha
  già anche `shell`, non specifico di ls).

### ✅ Fix hardware reale: timing FDC (giugno 2026)

Bug riportato dall'utente su Pentium II MMX reale (192MB RAM): boot
funzionante in QEMU/VirtualBox, ma `[FAULT] PID 1 'shell': page fault a
0x00000000 (protezione, lettura, EIP=0x00000000)` su hardware reale —
**non un vero kernel panic**: il nostro gestore fault-da-ring3 ha isolato
correttamente il problema (la shell e' stata terminata invece di far
cadere tutto il kernel — conferma che quel fix precedente funziona).

Causa reale: `kernel/fs/fat12.c`, i comandi FDC (motor on, seek,
recalibrate) usavano **loop di NOP a conteggio fisso** invece di attese
basate sul tempo reale:
```c
for (d = 0; d < 5000000; d++) __asm__ volatile("nop");  // "seek settling"
for (i = 0; i < 10000000; i++) __asm__ volatile("nop"); // "~300ms" motor
```
Il numero di iterazioni necessario dipende dalla velocita' della CPU —
tarato (implicitamente) sulla CPU virtuale di QEMU/VirtualBox. Su un
Pentium II reale, con timing completamente diverso, il floppy reale
(motore meccanico, testina) puo' non essere ancora pronto quando parte
il comando, e l'FDC puo' restituire dati sbagliati **senza segnalare un
errore I/O** — compatibile al 100% con: ELF della shell letto come
tutto-zero, entry_point=0, fault a EIP=0x00000000 appena lo scheduler ci
salta dentro.

Fix:
- Nuova `fdc_delay_ms()` basata su `g_ticks` (PIT a 100Hz, kernel/sched/
  sched.c — tempo reale, indipendente dalla CPU; richiede interrupt
  abilitati, sempre vero per fat12_init()/letture, che girano dopo
  [PASSO 12] in kernel_main.c). Sostituisce i tre loop NOP in
  `fdc_recalibrate`, `fdc_seek`, `fdc_motor_on`.
- Bug collegato in `fat12_read_sector()`: se la lettura dei byte di
  stato post-comando falliva (`fdc_recv_byte` in timeout), `st0`
  restava **non inizializzato** ma veniva comunque controllato
  (`if (st0 & 0xC0)`) — innocuo per coincidenza quando lo stack e'
  zero-ish (frequente in emulazione), indeterministico su hardware
  reale. Fix: su fallimento della status phase si esce subito con
  errore, senza usare `st0` non garantito.
- ~~**Non ancora fatto**: il driver FDC non si sincronizza mai su IRQ6.~~
  **FATTO il 2026-07-30**, vedi la sezione dedicata più sotto — e ha
  scoperto altri tre difetti della stessa famiglia.
- Compilato pulito (`-Wall -Wextra -m32`), zero warning nuovi (resta
  solo `fdc_seek` "defined but not used", preesistente, non collegato).
- **Non testato su hardware reale da me** (nessun Pentium II/QEMU/VBox
  disponibile in questo ambiente) — da verificare alla prossima build.

### ✅ Deadlock PIC — EOI dopo il context switch (luglio 2026)

**Il bug per cui "le applicazioni lanciate dalla shell si bloccavano".**

`irq_handler()` (`kernel/arch/x86/isr.c`) inviava `pic_send_eoi(irq)` come
ultima istruzione, dopo l'handler. Ma `sched_irq0_handler()` può chiamare
`sched_switch_to()` → `context_switch()`, che **cambia lo stack kernel e non
ritorna**: l'EOI restava non eseguito fino al riscaldulo del processo
preemptato. Con IRQ0 marcato In-Service il PIC non consegna più né IRQ0 né gli
IRQ di priorità inferiore, quindi `g_ticks` non avanza più e qualunque attesa
basata sui tick si blocca per sempre.

Percorso completo: `IRQ0` → switch alla shell (EOI perso) → `spawn()` →
`elf_load()` → `fat12_read_sector()` → `fdc_motor_on()` → `fdc_delay_ms(300)` →
`hlt` in attesa di `g_ticks` → congelamento. Firma diagnostica al monitor QEMU:
`pic0: irr=03 imr=bc isr=01`.

Fix: EOI **prima** del dispatch dell'handler. Sicuro perché gli IRQ entrano da
interrupt gate (IF=0 per tutto l'handler), quindi nessun rientro prima
dell'`iret`.

> **Invariante da rispettare in tutto il kernel**: qualunque handler di
> interrupt può non ritornare, perché il context switch è uno stack switch
> cooperativo. Tutto ciò che deve accadere "a fine interrupt" (EOI, rilascio
> lock, ripristino di stato hardware) va eseguito **prima** di chiamare codice
> che possa schedulare.

### ✅ Race "lost wakeup" nel TTY (luglio 2026)

`drv_read()` in `drivers/tty/tty.c` faceva `g_waiting_pid = pid;` e
`sched_block(PROC_BLOCKED);` **a interrupt abilitati**. Se IRQ1 cadeva nella
finestra fra le due, l'handler chiamava `sched_unblock()` su un processo ancora
RUNNING (no-op) e azzerava `g_waiting_pid`; subito dopo `sched_block()`
addormentava il processo con la sveglia già consumata → shell bloccata al
prompt per sempre, con la riga già nel ring buffer.

Fix: test-and-block atomico rispetto all'IRQ (`cli` + ri-controllo del buffer
prima di bloccare). Inoltre `g_input_buf` è ora `volatile` — scritto
dall'handler IRQ1 e letto in contesto processo, con `-O2` il compilatore poteva
tenere `count` in un registro attraverso il loop di attesa.

Lo stesso schema difettoso è presente in `drivers/kbd/kbd.c` (che però usa
busy-wait, non `sched_block`): da rivedere quando quel driver verrà migrato.

### ✅ Leak di PCB/page directory/stack kernel sui driver non caricati (luglio 2026)

In `kernel_main.c` (PASSO 14b e 15), sul fallimento di `elf_load()` si chiamava
solo `proc_kill()` → stato ZOMBIE. `init_reaper_task()` raccoglie però solo gli
zombie con `ppid == PID di init`, e questi hanno `ppid` = task attivo durante il
boot (idle), che non chiama mai `waitpid()`. Ogni driver mancante lasciava per
sempre uno slot PCB, una page directory e le pagine dello stack kernel.

Fix: `proc_kill()` + `proc_reap_zombie()` al chiamante. **Non** è stato
modificato `proc_kill()` per ri-genitorializzare a init: `sys_waitpid()` si
ri-blocca in loop, quindi se init raccogliesse lo zombie prima del genitore in
attesa, quel genitore resterebbe bloccato per sempre.

### ✅ Bug minori di supporto (luglio 2026)

- **`kprintf("%s", NULL)` → #PF nel kernel**: in `print_str()`
  (`kernel/arch/x86/kprintf.c`) `const char *p = s;` precedeva
  `if (!s) s = "(null)";`, quindi il conteggio della lunghezza dereferenziava
  il puntatore nullo. Risolto invertendo l'ordine.
- **`printf()` di libc ignorava flag e larghezza**: su `"%-12s"` il `-` cadeva
  nel `default` che stampava `%-` **senza consumare l'argomento**, sfasando
  tutti gli specificatori successivi (`ls` stampava `%-12s 3221219808`, dove il
  numero era il puntatore al nome letto da `%u`). Riscritta con supporto a
  `-`/`0`/larghezza e aggiunti `%o` e `%p`.
- **Makefile: `/bin/ls` non si ricompilava al cambiare di `libc.c`**.
  `LIBC_SRC` era definita *dopo* la regola `$(LS_BIN)` che la usa come
  prerequisito; make espande i prerequisiti alla lettura della regola, quindi
  `$(LIBC_SRC)` era stringa vuota. Sintomo ingannevole: i fix a `libc.c`
  sembravano "non avere effetto". Le definizioni sono ora prima della regola.
  **Regola generale: in questo Makefile ogni variabile usata come prerequisito
  deve essere definita più in alto del punto d'uso.**

### 🔧 Console seriale di debug (luglio 2026) — da riusare

`kernel/arch/x86/vga.c` ora specchia su COM1 (38400 8N1) tutto ciò che passa da
`vga_putchar()`: `kprintf`, `klog`, eco tastiera e output dei processi. Serve
perché lo schermo VGA è 80x25 e i log di boot scorrono via. Ha una guardia di
spin per non bloccare il kernel su hardware senza COM1.

```bash
qemu-system-i386 -drive file=dist/floppy.img,format=raw,if=floppy \
  -m 32M -boot a -display none -serial file:/tmp/serial.txt -no-reboot
```

Per la diagnosi di blocchi: QEMU monitor su socket unix, `info pic` (mostra
`irr`/`imr`/`isr` — è così che si è trovato il deadlock EOI), `info registers`
(EIP + flag HLT, campionato più volte per distinguere blocco da idle loop),
`screendump` per lo schermo. Da `EIP` al simbolo: `nm build/kernel.elf | sort`.

### ✅ Primo driver in ring3: la tastiera (luglio 2026)

**Il punto 5 qui sotto è risolto per la tastiera.** `/dev/kbd.drv` è un
processo ring3 con la propria page directory, che non esegue nessuna
istruzione privilegiata e non chiama un solo simbolo del kernel:

| Prima (ET_DYN, kernel space) | Ora (ET_EXEC, ring3) |
|---|---|
| `port_inb`/`port_outb` diretti | `ioport_in`/`ioport_out` (SYS_IOPORT_IN/OUT), limitate al range `0x60..0x64` dichiarato con `ioport_bind` |
| `irq_register_handler(1, h)` | `irq_bind(1)` (SYS_IRQ_BIND): gli IRQ1 arrivano come messaggi IPC |
| `sched_unblock(pid)` | `ipc_send(pid, KBD_MSG_LINE, riga)` |
| `klog()` | `printf()` su fd 1 |
| `ENTRY(drv_init)`, chiamate dirette `drv_*` | `ENTRY(_start)`, `main()` con loop di servizio `ipc_recv` |

Il TTY resta nel kernel (possiede la VGA, implementa `drv_write`) ma per
l'input diventa un **client** del servizio kbd. Il dettaglio che rende
tutto semplice: `drv_read()` è chiamata da `sys_read()`, quindi gira già
nel contesto del processo che legge — le sue `ipc_send`/`ipc_recv`
operano sulla mailbox della shell, non su una del kernel.

Punti da NON rompere (dettagli completi in `HANDOFF.md`):

- **`drv_init()` del TTY non deve registrare l'handler IRQ1.**
  `irq_handler()` (isr.c) dà la precedenza agli handler kernel rispetto al
  proprietario ring3: un handler registrato "per sicurezza" affamerebbe
  completamente il driver ring3. La scelta è fatta al PASSO 14c di
  `kernel_main`, quando l'esito del caricamento è noto.
- **Il driver deve drenare il KBC in loop**, non leggere un byte per
  notifica: `ipc_notify_irq()` scarta le notifiche se la mailbox è piena,
  e un byte non letto tiene OBF alto bloccando ogni fronte IRQ1
  successivo.
- **I timeout di polling in ring3 sono ~50x più corti** di quelli
  kernel-space: lì erano `in`/`out`, qui ogni lettura è una syscall.
- **I processi driver sono adottati da init alla creazione**
  (`drv_proc->ppid = g_init_task->pid` in `kernel_main`): con idle come
  padre nessuno li raccoglierebbe mai, e `proc_reap_zombie()` è ciò che
  rilascia il claim sull'IRQ e il nome IPC registrato. Senza, un driver
  crashato non sarebbe mai riavviabile.

Il percorso in-kernel storico è conservato in `tty.c` sotto
`TTY_INPUT_INTERNAL` come fallback, ed è **testato**: senza
`/dev/kbd.drv` sul floppy la console resta pienamente usabile.

### ✅ FDC sincronizzato su IRQ6 + tre bug latenti da hardware reale (30 luglio 2026)

Dettagli completi in `HANDOFF.md`. In sintesi, quattro difetti che in
QEMU non si vedono e su un drive vero darebbero letture sbagliate
**senza errore I/O segnalato** — stessa firma del bug del Pentium II:

1. **Attesa di 15ms dopo RECALIBRATE/SEEK.** Su drive reale un
   recalibrate a stroke pieno richiede centinaia di ms: SENSE INTERRUPT
   veniva letto a seek ancora in corso e, dopo 3 tentativi, la funzione
   usciva in silenzio con la testina dove capitava. Ora si attende
   davvero l'IRQ6 (`fdc_wait_irq`, timeout 1000ms/500ms non fatale) e si
   controllano ST0 bit 5 (SE) e bit 4 (EC), non il solo `pcn == 0` — che
   è 0 anche se il comando non è mai partito.
2. **READ non faceva SEEK.** `fdc_seek()` esisteva ma non la chiamava
   nessuno (da mesi era la causa del warning `defined but not used`).
   Senza implicit seek (`CONFIGURE`/EIS mai inviato) il comando READ non
   muove la testina: un controller reale legge la traccia su cui si trova
   *fisicamente*. Funzionava solo perché QEMU fa il seek per conto suo.
   Ora `fdc_seek_if_needed()` prima di ogni READ/WRITE, con `g_fdc_cyl` a
   ricordare il cilindro corrente (36 settori per cilindro → una lettura
   sequenziale sposta la testina una volta ogni 36 settori). Misurato:
   boot 19,7s con la cache, 20,9s senza.
3. **`fat12_write_sector` non aveva il `cli`** che la lettura ha da
   sempre, commento incluso. Un IRQ0 fra due `fdc_send_byte()` fa
   abbandonare il comando al controller e i 512 byte vengono scartati
   silenziosamente: la scrittura "riesce" senza scrivere nulla.
4. **Due loop di NOP sopravvissuti** alla bonifica di giugno, nel reset
   del controller in `fat12_init`.

> **Da non "correggere"**: IRQ6 NON è usato per READ/WRITE, ed è giusto
> così. In PIO (SPECIFY con NDMA=1) il controller alza INT a *ogni byte*,
> non a fine comando: aspettarlo lì non significherebbe "settore
> trasferito" ma "c'è un byte", informazione già disponibile da MSR/RQM.
> Il polling di MSR è il modello corretto per il PIO.

**Non verificato su hardware reale** — ed è il punto: sono proprio i bug
che l'emulazione non mostra. In caso di problemi sul Pentium II, i log da
guardare sono i nuovi warning `timeout IRQ6 su ...` e
`SEEK non confermato`, che distinguono un problema di timing da uno di
posizionamento.

### ✅ FDC in DMA + scrittura su file mai funzionante (30 luglio 2026)

`/bin/textline` è il primo programma che scrive su disco, e ha fatto emergere
**tre difetti indipendenti** in codice mai esercitato. Dettagli in `HANDOFF.md`.

1. **Comando FDC di scrittura sbagliato**: `0xC5` (bit 7 = MT, Multi-Track) con
   `EOT=18` faceva attendere al controller un'intera traccia invece di un
   settore. Il commento diceva già "MT=0", era il valore a non corrispondere.
2. **QEMU non completa le scritture non-DMA.** Misurato: accetta esattamente
   512 byte, li scrive davvero sul supporto, poi resta in `MSR=0x30` per sempre
   senza mai entrare in fase di risultato. → **passaggio al DMA (canale 2)** per
   lettura e scrittura.
3. **`fat12_write` sovrascriveva invece di accodare**: partiva sempre
   dall'inizio dell'ultimo cluster ignorando `file_size`. Quattro `write()`
   consecutive producevano `\neconda riga` con dimensione 24.

> Il DMA **apre la strada al driver floppy in ring3**: era l'ostacolo
> principale documentato nel punto 5 qui sotto (un processo utente non può
> fare `cli` e verrebbe preemptato in mezzo a un trasferimento PIO). Ora il
> trasferimento non passa dalla CPU e la fine comando arriva via IRQ6.

Lettura e scrittura sono ora un solo `fdc_rw_sector()`: erano due copie quasi
identiche, ed è il motivo per cui il baco è sopravvissuto — la correzione della
lettura non si era propagata all'altra copia. La fase di risultato legge i
**sette** byte previsti, non tre.

### ✅ Percorsi relativi e scrittura in sottodirectory (30 luglio 2026)

Segnalazione "premendo l mi dice documento vuoto" aprendo `/boot/kernel.cfg`
con textline. Dietro un solo sintomo c'erano **sei difetti**, dettagli in
`HANDOFF.md`:

1. **Nessuna syscall risolveva i percorsi relativi.** `g_cwd` era scritta da
   `chdir()` e letta solo da `getcwd()`; open/exec/spawn/readdir passavano la
   stringa tale e quale a `fat12_*`, che parte sempre dalla root. Nuova
   `resolve_path()` (gestisce anche `.` e `..`). `chdir()` ora verifica pure
   che la destinazione esista e sia una directory — prima accettava qualunque
   stringa.
2. **`root_index` dedotto da un puntatore allo stack**: per un file esistente
   nella root, `fat12_write` scriveva `g_root_dir[indice_fuori_scala]` — una
   scrittura fuori dai limiti nella memoria del kernel. Nascosto dal fatto che
   solo il percorso di *creazione* era mai stato esercitato.
3. **Scrivere in sottodirectory non lasciava traccia**: la creazione finiva
   sempre in root e la entry non veniva mai riscritta.
4. **`O_TRUNC` non implementato da nessuno**: salvare su un file esistente
   appendeva al vecchio contenuto invece di sostituirlo.
5. **Salvare richiedeva minuti**: `fat12_write` riversava FAT e root a ogni
   chiamata (5000+ scritture di settore per 3,6KB) e la cache era
   write-through. Ora flush in `fat12_close`/`fat12_sync` e cache
   **write-back** a 16 slot.
6. **Il Makefile non ricompilava al cambiare di un header** — stessa classe di
   trappola di `LIBC_SRC`. Aggiunti `-MMD -MP`.

> **Conseguenza del write-back da tenere presente**: i dati non sono sul
> supporto finché non si chiude il file o non si chiama `fat12_sync()`. È il
> motivo per cui la procedura di arresto (`halt`/`poweroff`) sincronizza prima
> di fermare il sistema: le due cose si tengono, non toccarne una sola.

### ❌ Link dinamico ring3 — fattibilità verificata, non implementato

Requisito esplicito dell'utente ("le librerie devono essere tutte dinamiche"),
non ancora soddisfatto: i programmi di `/bin` restano statici. Verificato però
sperimentalmente che la strada è percorribile — il toolchain produce già un
ET_EXEC dinamico con `.rel.plt`/`R_386_JUMP_SLOT` e `DT_NEEDED [libc.so]`
(`-soname` già aggiunto al Makefile), e il kernel ha già il meccanismo per
scrivere nello spazio di un altro processo (`paging_get_physical`, usato da
`elf_load`). Passi concreti elencati in `HANDOFF.md`.

### Da fare (prossimi step verso driver in userspace)

5. **Il driver floppy gira ancora in ring0**: `kernel/loader/dynlink.c`
   risolve i simboli e mappa i moduli .so (floppy, kbd) nello stesso
   spazio del kernel. Per l'evoluzione a userspace serve: eseguire il
   binario driver come processo ring3 reale (ora possibile via
   `SYS_SPAWN`), una syscall/IPC per registrare/esporre le operazioni
   drv_*, e instradamento degli IRQ verso quel processo invece che
   verso una chiamata diretta C.

   **Stato aggiornato al 2026-07-30** — la tastiera è migrata, il floppy no:

   | Cosa | Stato reale |
   |---|---|
   | `boot/kernel.cfg` | dichiara `modules = kbd` |
   | `/dev/kbd.drv` | ✅ **ET_EXEC statico, processo ring3**, caricato al PASSO 14b e funzionante |
   | `/dev/tty.drv` | non è mai esistito: `drivers/tty/tty.c` è linkato *dentro* il kernel (`$(BUILD_KERNEL)/tty.o` in `KERNEL_OBJS`), usato al PASSO 14 via `drv_init()`. La voce è stata **rimossa** da `kernel.cfg`: produceva un `[WARN]` fuorviante a ogni boot |
   | `/dev/floppy.drv` | ancora **ET_DYN** (`-shared -fPIC`) per `drvmgr.c`/`dynlink.c`. `elf_load()` accetta solo ET_EXEC → sarebbe rifiutato con `tipo non supportato (type=3)`. **Rimosso** da `kernel.cfg` finché non è riscritto; viene ancora compilato e copiato sul floppy come promemoria |
   | accesso al floppy | fatto dal FAT12/FDC **interno al kernel** (`kernel/fs/fat12.c`) |

   Il floppy non è incompatibile solo per il tipo ELF: **anche accettando
   ET_DYN non potrebbe girare in ring3 così com'è scritto** — usa
   `port_inb`/`port_outb` diretti (#GP in ring3) e chiama simboli del
   kernel per linkage diretto (`klog`, `irq_register_handler`,
   `pic_unmask_irq`, `sched_unblock`), risolti da `drvmgr.c` solo perché
   mappati nello spazio del kernel.

   L'API syscall giusta **esiste già** ed è quella usata da kbd:
   `SYS_IRQ_BIND` (224), `SYS_IOPORT_BIND` (225), `SYS_IOPORT_IN` (226),
   `SYS_IOPORT_OUT` (227), `SYS_IPC_*` (220–223), con
   `irq_bind_process()` e `ipc_notify_irq()` in `kernel/arch/x86/isr.c`.

   Per completare il floppy: (a) riscriverlo contro l'API syscall;
   (b) aggiungere `_start` e linkarlo **ET_EXEC** statico come `/bin/*`,
   non `-shared` (copiare la regola Makefile di `kbd.drv`); (c) loop di
   servizio IPC (`ipc_register(nome)` + `ipc_recv`) al posto delle `drv_*`
   chiamate direttamente; (d) risolvere il **bootstrap** — il driver del
   floppy va letto *dal* floppy, quindi il kernel deve conservare il
   proprio FAT12/FDC minimo almeno per caricarlo: questa migrazione non
   toglie codice dal kernel, lo affianca.

   ⚠️ **OSTACOLO PRINCIPALE, scoperto il 2026-07-30**: `fat12_read_sector`
   fa il trasferimento PIO byte-per-byte con `interrupts_disable()`
   attorno al loop, e **un processo ring3 non può fare `cli`**. Verrebbe
   preempato da IRQ0 in mezzo al settore. In QEMU passerebbe; su hardware
   vero a 500 kbit/s il FIFO va servito entro microsecondi e un tick da
   10 ms è tre ordini di grandezza oltre il margine → **overrun**
   (ST1 bit 4). Tre strade possibili, nessuna ancora imboccata:

   1. **DMA** — la CPU non serve il trasferimento, la preemption diventa
      innocua. Richiede però lavoro nel kernel: `sys_ioport_bind` accetta
      **un solo range contiguo** e servirebbero anche le porte del
      controller DMA (0x00–0x0F, 0x81), più una syscall per ottenere un
      buffer fisicamente contiguo sotto i 16MB di cui il driver conosca
      l'indirizzo **fisico**. Architettura corretta, lavoro più lungo.
   2. **PIO + sezione non-preemptible** — flag nel PCB che
      `sched_irq0_handler` controlla per saltare il context switch, con
      timeout a tick. Più corta, ma concede a un processo utente di
      bloccare lo scheduler: compromesso sull'isolamento.
   3. **Lasciare il floppy in-kernel.** Legittima: il kernel deve
      comunque conservare FAT12/FDC per il bootstrap.

   Differenza rispetto a kbd da valutare prima di partire: il TTY può fare
   da client IPC perché `drv_read()` gira **nel contesto del processo che
   legge**. `elf_load()` no — è chiamato anche da `kernel_main` al boot,
   quando `proc_get_current()` è il task idle. Va deciso se il client del
   servizio floppy sarà il kernel o un vero VFS in userspace.

